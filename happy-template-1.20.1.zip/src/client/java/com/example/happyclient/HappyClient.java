package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    private long lastGroundAttackTime = 0L;
    private long lastAirAttackTime = 0L;
    private long lastTargetChangeTime = 0L;
    private long scheduledPostEatAttackTime = 0L;

    private boolean wasEatingOffhand = false;
    private boolean postEatDelayActive = false;

    private int lastTargetId = -1;
    private boolean targetPreviouslyInCrosshair = false;

    private static final Random random = new Random();

    private static final float COOLDOWN_THRESHOLD = 0.86f;

    private static int logNormalTickFraction0to5ms() {
        double mean = Math.log(2.5);
        double stddev = 0.4;
        double value = Math.exp(mean + stddev * random.nextGaussian());
        int ms = (int)Math.round(value);
        if (ms < 0) ms = 0;
        if (ms > 5) ms = 5;
        return ms;
    }

    private static int logNormalGaussianTickFraction0to49ms() {
        double mean = Math.log(25);
        double stddevLog = 0.5;
        double value = Math.exp(mean + stddevLog * random.nextGaussian());
        value += random.nextGaussian() * 10.0;
        int ms = (int)Math.round(value);
        if (ms < 0) ms = 0;
        if (ms > 49) ms = 49;
        return ms;
    }

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long now = System.currentTimeMillis();
            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                lastGroundAttackTime = 0L;
                lastAirAttackTime = 0L;
                scheduledPostEatAttackTime = 0L;
                wasEatingOffhand = false;
                postEatDelayActive = false;
                lastTargetId = -1;
                targetPreviouslyInCrosshair = false;
                lastTargetChangeTime = 0L;
                return;
            }

            ClientPlayerEntity player = client.player;
            ItemStack main = player.getMainHandStack();
            ItemStack off = player.getOffHandStack();

            boolean isUsingItem = player.isUsingItem();
            boolean isEatingOffhand = off.isFood() && player.isUsingItem() && player.getActiveHand() == net.minecraft.util.Hand.OFF_HAND;

            if (isEatingOffhand) {
                wasEatingOffhand = true;
                postEatDelayActive = false;
                scheduledPostEatAttackTime = 0L;
                return;
            }
            if (wasEatingOffhand) {
                wasEatingOffhand = false;
                postEatDelayActive = true;
                int postEat = 65 + random.nextInt(6);
                scheduledPostEatAttackTime = now + postEat;
                return;
            }
            if (postEatDelayActive) {
                if (now < scheduledPostEatAttackTime) {
                    return;
                } else {
                    postEatDelayActive = false;
                    scheduledPostEatAttackTime = 0L;
                }
            }

            if (isUsingItem) return;

            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                lastGroundAttackTime = 0L;
                lastAirAttackTime = 0L;
                lastTargetId = -1;
                targetPreviouslyInCrosshair = false;
                lastTargetChangeTime = 0L;
                return;
            }

            Entity target = client.targetedEntity;
            float cooldown = player.getAttackCooldownProgress(0.0f);

            boolean targetValid = target != null && target != player && target instanceof PlayerEntity;
            boolean isNewTarget = targetValid && ((target.getId() != lastTargetId) || !targetPreviouslyInCrosshair);

            if (isNewTarget) {
                lastTargetChangeTime = now;
            }

            if (targetValid) {
                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                if (isFalling) {
                    if (isNewTarget) {
                        if (now - lastTargetChangeTime >= logNormalTickFraction0to5ms() && cooldown >= COOLDOWN_THRESHOLD) {
                            AttackAtSubTickHelper.triggerAttack(client);
                            lastAirAttackTime = now;
                            lastTargetChangeTime = 0L;
                        }
                    } else {
                        boolean enemyEating = false;
                        if (target instanceof PlayerEntity) {
                            PlayerEntity t = (PlayerEntity) target;
                            ItemStack mainHand = t.getMainHandStack();
                            ItemStack offHand = t.getOffHandStack();
                            boolean mainEating = mainHand.isFood() && t.isUsingItem() && t.getActiveHand() == net.minecraft.util.Hand.MAIN_HAND;
                            boolean offEating = offHand.isFood() && t.isUsingItem() && t.getActiveHand() == net.minecraft.util.Hand.OFF_HAND;
                            enemyEating = mainEating || offEating;
                        }
                        long airDelay = enemyEating ? 370 : 320;
                        int tickFraction = logNormalGaussianTickFraction0to49ms();
                        if (lastAirAttackTime == 0L || now - lastAirAttackTime >= airDelay + tickFraction) {
                            if (cooldown >= COOLDOWN_THRESHOLD) {
                                AttackAtSubTickHelper.triggerAttack(client);
                                lastAirAttackTime = now;
                            }
                        }
                    }
                }
                else if (onGround) {
                    if (isNewTarget) {
                        if (now - lastTargetChangeTime >= logNormalTickFraction0to5ms() && cooldown >= COOLDOWN_THRESHOLD) {
                            AttackAtSubTickHelper.triggerAttack(client);
                            lastGroundAttackTime = now;
                            lastTargetChangeTime = 0L;
                        }
                    } else {
                        int roll = random.nextInt(1000);
                        long groundDelay;
                        if (roll < 5) groundDelay = 540;
                        else if (roll > 994) groundDelay = 641;
                        else groundDelay = 580;
                        int tickFraction = logNormalGaussianTickFraction0to49ms();
                        if (lastGroundAttackTime == 0L || now - lastGroundAttackTime >= groundDelay + tickFraction) {
                            if (cooldown >= COOLDOWN_THRESHOLD) {
                                AttackAtSubTickHelper.triggerAttack(client);
                                lastGroundAttackTime = now;
                            }
                        }
                    }
                }
            } else {
                lastGroundAttackTime = 0L;
                lastAirAttackTime = 0L;
                lastTargetChangeTime = 0L;
            }

            if (targetValid) {
                lastTargetId = target.getId();
                targetPreviouslyInCrosshair = true;
            } else {
                lastTargetId = -1;
                targetPreviouslyInCrosshair = false;
            }
        });
    }
}