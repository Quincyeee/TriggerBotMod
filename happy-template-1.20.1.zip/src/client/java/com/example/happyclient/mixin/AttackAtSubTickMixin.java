package com.example.happyclient.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class AttackAtSubTickMixin {

    private long lastAttackTime = 0L;
    private static final long ATTACK_INTERVAL_MS = 600; // Tune as needed

    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void onDoAttack(CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        Entity target = client.targetedEntity;
        ClientPlayerEntity player = client.player;

        if (target != null && target != player) {
            long now = System.currentTimeMillis();
            if (now - lastAttackTime >= ATTACK_INTERVAL_MS) {
                PlayerInteractEntityC2SPacket attackPacket =
                        PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
                player.networkHandler.sendPacket(attackPacket);

                HandSwingC2SPacket swingPacket = new HandSwingC2SPacket(Hand.MAIN_HAND);
                player.networkHandler.sendPacket(swingPacket);

                lastAttackTime = now;
                ci.cancel(); // Prevent vanilla logic if using custom packet
            }
        }
    }
}