package com.example.happyclient.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.Hand;

public class AttackAtSubTickMixin {
    public static void triggerAttack(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        Entity target = client.targetedEntity;
        ClientPlayerEntity player = client.player;

        if (target != null && target != player) {
            PlayerInteractEntityC2SPacket attackPacket =
                    PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
            player.networkHandler.sendPacket(attackPacket);

            player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        }
    }
}