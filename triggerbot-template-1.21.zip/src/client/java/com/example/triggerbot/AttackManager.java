
package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;

import java.util.HashMap;
import java.util.Random;

public class AttackManager {
    private final Random random = new Random();
    private long lastGroundAttack = 0;
    private long lastFallingAttack = 0;
    private long lastEatEndTime = 0;
    private final HashMap<Integer, Long> lastSeen = new HashMap<>();
    private final HashMap<Integer, Boolean> wasRecentlyVisible = new HashMap<>();

    private int randomBetween(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    public void tryAttack(ClientPlayerEntity player, PlayerEntity target) {
        long now = System.currentTimeMillis();

        // Eating check and delay after
        if (player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND) {
            lastEatEndTime = now;
            return;
        }
        if (now - lastEatEndTime < randomBetween(150, 200)) return;
        float lastYaw = player.prevYaw;
        float yawNow = player.getYaw();
        if (Math.abs(yawNow - lastYaw) > 8.0f) {
            try { Thread.sleep(randomBetween(30, 50)); } catch (InterruptedException ignored) {}
        }


        // Target reappearance delay
        int id = target.getId();
        boolean visible = player.canSee(target);

        if (visible) {
            if (!wasRecentlyVisible.getOrDefault(id, false)) {
                Long last = lastSeen.getOrDefault(id, 0L);
                if (now - last > 300) {
                    lastSeen.put(id, now);
                    wasRecentlyVisible.put(id, true);
                    return; // skip frame on first reappearance
                }
                if (now - last < randomBetween(80, 120)) return;
            }
        } else {
            wasRecentlyVisible.put(id, false);
            lastSeen.put(id, now);
            return;
        }

        
        // Aim jitter simulation
        float jitterYaw = (random.nextFloat() - 0.5f) * 0.6f; // ±0.3 degrees
        player.setYaw(player.getYaw() + jitterYaw);
    
        double dist = player.distanceTo(target);
        float yawDiff = Math.abs(player.getYaw() - target.getYaw()) % 360f;
        if (yawDiff > 180) yawDiff = 360 - yawDiff;

        boolean aimSlightlyOff = yawDiff > 8f;
        boolean allowMiss = dist > 2.95 || aimSlightlyOff;
        int missChance = 15 + random.nextInt(6);

        if (allowMiss && (random.nextInt(missChance) == 0)) {
    float cooldownThreshold = 0.88f + random.nextFloat() * 0.07f;

            if (player.getAttackCooldownProgress(0.5f) >= cooldownThreshold) {
                player.swingHand(Hand.MAIN_HAND);
                try { Thread.sleep(150); } catch (InterruptedException ignored) {}
            }

            if (player.getAttackCooldownProgress(0.5f) >= 0.9f) {
                player.swingHand(Hand.MAIN_HAND);
            }
            return;
        }

        boolean isFalling = !player.isOnGround() && player.getVelocity().y < 0;
        boolean isGrounded = player.isOnGround() && player.getVelocity().y <= 0.003f;

        if (!(isFalling || isGrounded)) return;

        if (isFalling) {
            
                long baseDelay = random.nextFloat() < 0.2f
                    ? randomBetween(450, 525)
                    : randomBetween(375, 450);
                long jitter = randomBetween(-20, 20);
                long delay = baseDelay + jitter;
    
            if (now - lastFallingAttack < delay) return;
            float cooldownThreshold = 0.88f + random.nextFloat() * 0.07f;
        if (player.getAttackCooldownProgress(0.5f) < cooldownThreshold) return;
            if (!player.canSee(target) || dist > 3.0f || target.isDead()) return;

                        player.swingHand(Hand.MAIN_HAND);
            try { Thread.sleep(40 + randomBetween(5, 15)); } catch (InterruptedException ignored) {}
            PlayerInteractEntityC2SPacket packet = PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
            MinecraftClient.getInstance().getNetworkHandler().sendPacket(packet);
            MinecraftClient.getInstance().interactionManager.attackEntity(player, target);
            lastFallingAttack = now;
            return;
        }

        if (isGrounded) {
            long delay = random.nextFloat() < 0.2f
                ? randomBetween(545, 565)
                : randomBetween(565, 630);
            if (now - lastGroundAttack < delay) return;
            float cooldownThreshold = 0.88f + random.nextFloat() * 0.07f;
        if (player.getAttackCooldownProgress(0.5f) < cooldownThreshold) return;
            if (!player.canSee(target) || dist > 3.0f || target.isDead()) return;

                        player.swingHand(Hand.MAIN_HAND);
            try { Thread.sleep(40 + randomBetween(5, 15)); } catch (InterruptedException ignored) {}
            PlayerInteractEntityC2SPacket packet = PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
            MinecraftClient.getInstance().getNetworkHandler().sendPacket(packet);
            MinecraftClient.getInstance().interactionManager.attackEntity(player, target);
            lastGroundAttack = now;
        }
    }
}