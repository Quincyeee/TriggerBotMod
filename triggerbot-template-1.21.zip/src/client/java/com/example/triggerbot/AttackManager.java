
package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;

import java.util.Random;

public class AttackManager {
    private final Random random = new Random();
    private long lastAttack = 0;

    private int randomBetween(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    public void tryAttack(ClientPlayerEntity player, PlayerEntity target) {
        long now = System.currentTimeMillis();

        if (player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND) return;

        double dist = player.distanceTo(target);
        float yawDiff = Math.abs(player.getYaw() - target.getYaw()) % 360f;
        if (yawDiff > 180) yawDiff = 360 - yawDiff;

        boolean aimSlightlyOff = yawDiff > 8f;
        boolean allowMiss = dist > 2.95 || aimSlightlyOff;
        int missChance = 15 + random.nextInt(6);

        if (allowMiss && (random.nextInt(missChance) == 0)) {
            player.swingHand(Hand.MAIN_HAND);
            TriggerBotClient.targetTracker.triggerMissedHit(); // Correct only here
            return;
        }

        boolean isFalling = !player.isOnGround() && player.getVelocity().y < 0;
        boolean isGrounded = player.isOnGround() && Math.abs(player.getVelocity().y) < 0.003f;

        if (!(isFalling || isGrounded)) return;

        long delay = isFalling
            ? (random.nextFloat() < 0.2f
                ? randomBetween(450, 525)
                : randomBetween(375, 450))
            : (random.nextFloat() < 0.2f
                ? randomBetween(560, 570)
                : randomBetween(570, 630));

        if (now - lastAttack < delay) return;
        if (player.getAttackCooldownProgress(0.5f) < 0.9f) return;
        if (!player.canSee(target) || dist > 3.0f || target.isDead()) return;

        PlayerInteractEntityC2SPacket packet = PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
        MinecraftClient.getInstance().getNetworkHandler().sendPacket(packet);
        MinecraftClient.getInstance().interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        lastAttack = now;
    }
}
