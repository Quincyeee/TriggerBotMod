
package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.network.ClientPlayNetworking;

import java.util.Random;

public class AttackManager {
    private final Random random = new Random();
    private long lastAttack = 0;

    private int randomBetween(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    public void tryAttack(ClientPlayerEntity player, PlayerEntity target) {
        long now = System.currentTimeMillis();

        double dist = player.distanceTo(target);
        boolean allowMiss = dist >= 2.75 && dist <= 3.0;
        int missChance = 15 + random.nextInt(6); // 15–20
        boolean shouldMiss = allowMiss && (random.nextInt(missChance) == 0);

        if (shouldMiss) {
            float yawToTarget = player.getYaw();
            float missYaw = yawToTarget + (random.nextBoolean() ? 8 + random.nextFloat() * 5 : -8 - random.nextFloat() * 5); // ±8–13°
            float missPitch = player.getPitch() + (random.nextFloat() * 2f - 1f); // ±1°

            player.setYaw(missYaw);
            player.setPitch(missPitch);
            player.swingHand(Hand.MAIN_HAND);
            return;
        }

        boolean isFalling = !player.isOnGround() && player.getVelocity().y < 0;
        boolean isGrounded = player.isOnGround();

        if (!(isFalling || isGrounded)) return;

        long delay = isFalling
            ? (random.nextFloat() < 0.2f
                ? randomBetween(450, 525)
                : randomBetween(375, 450))
            : (random.nextFloat() < 0.2f
                ? randomBetween(540, 570)
                : randomBetween(570, 630));

        if (now - lastAttack < delay) return;
        if (player.getAttackCooldownProgress(0.5f) < 0.9f) return;
        if (!player.canSee(target) || dist > 3.0f || target.isDead()) return;

        PlayerInteractEntityC2SPacket packet = PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
        ClientPlayNetworking.send(packet);
        player.swingHand(Hand.MAIN_HAND);
        lastAttack = now;
    }
}
