package com.example.triggerbot;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

import java.util.Random;

public class AttackManager {
    private long lastAttack = 0;
    private final Random random = new Random();

    public void tryAttack(ClientPlayerEntity player, PlayerEntity target) {
        long now = System.currentTimeMillis();
        long delay = 550 + random.nextInt(90); // 550–640ms

        if (now - lastAttack < delay) return;

        boolean shouldMiss = random.nextInt(18) == 0;
        if (shouldMiss) {
            player.swingHand(Hand.MAIN_HAND);
            lastAttack = now;
            return;
        }

        player.swingHand(Hand.MAIN_HAND);
        player.attack(target);
        lastAttack = now;
    }
}