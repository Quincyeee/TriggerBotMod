package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    public static boolean enabled = false;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = new KeyBinding("key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.misc");
        KeyBindingHelper.registerKeyBinding(toggleKey);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                client.player.sendMessage(Text.of("TriggerBot " + (enabled ? "Enabled" : "Disabled")), false);
            }

            if (enabled && client.player != null && client.world != null) {
                TriggerBotLogic.tick(client);
            }
        });
    }
}