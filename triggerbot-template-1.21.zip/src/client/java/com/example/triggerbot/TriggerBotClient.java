package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Random random = new Random();

    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long lastTargetSwitchTime = 0;
    private static long lastEatTime = 0;
    private static Entity lastTarget = null;

    private static final KeyBinding toggleKey = new KeyBinding(
        "key.triggerbot.toggle",
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_R,
        "key.categories.misc"
    );

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                System.out.println("TriggerBot " + (enabled ? "Enabled" : "Disabled"));
            }

            if (!enabled || mc.player == null || mc.world == null || mc.crosshairTarget == null) return;

            if (!(mc.player.getMainHandStack().getItem() instanceof SwordItem)) return;
            if (mc.player.isUsingItem()) {
                lastEatTime = System.currentTimeMillis();
                return;
            }

            if (System.currentTimeMillis() - lastEatTime < 150) return;

            Entity target = getTarget();

            if (target == null) return;

            // FOV-based targeting
            if (!isInFOV(target, 35)) return;

            // Delay switching targets
            if (lastTarget != target) {
                if (System.currentTimeMillis() - lastTargetSwitchTime < 300) return;
                lastTargetSwitchTime = System.currentTimeMillis();
                lastTarget = target;
            }

            // Miss chance simulation
            double distance = mc.player.distanceTo(target);
            if (distance > 3.0 || random.nextDouble() < 0.05) return;

            // Cooldown
            if (mc.player.getAttackCooldownProgress(0) < 1.0f) return;

            // Critical or normal delay logic
            long now = System.currentTimeMillis();
            boolean isFalling = !mc.player.isOnGround() && mc.player.getVelocity().y < 0;
            long delay = isFalling ? 350 + random.nextInt(75) : 550 + random.nextInt(75);
            if (now - lastAttackTime < delay) return;

            if (target instanceof PlayerEntity playerTarget && playerTarget.isBlocking()) return;
            if (target.isInvisible()) return;
            if (!mc.player.canSee(target)) return;

            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
            lastAttackTime = now;
        });
    }

    private Entity getTarget() {
        Entity target = mc.targetedEntity;
        if (target instanceof PlayerEntity && target.isAlive()) {
            return target;
        }
        return null;
    }

    private boolean isInFOV(Entity target, float maxAngle) {
        if (mc.player == null || target == null) return false;
        double dx = target.getX() - mc.player.getX();
        double dz = target.getZ() - mc.player.getZ();
        double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90;
        double diff = Math.abs(MathHelper.wrapDegrees(mc.player.getYaw() - yaw));
        return diff <= maxAngle;
    }

    // You might need this import manually
    private static class MathHelper {
        public static float wrapDegrees(double value) {
            value %= 360.0;
            if (value >= 180.0) value -= 360.0;
            if (value < -180.0) value += 360.0;
            return (float) value;
        }
    }
}