package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TriggerbotClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("triggerbot");
    private boolean enabled = false;
    private KeyBinding toggleKey;
    private final Random random = new Random();

    // --- Customizable Parameters ---
    private int minAttackDelayMs = 560; // Default attack delay
    private int maxAttackDelayMs = 625; // Default attack delay
    private double triggerChance = 0.90;
    private long firstAttackDelayMs = 150; // Delay for the first attack

    private long nextAttackTime = 0;
    private long targetAcquiredTime = 0;
    private LivingEntity targetedEntity = null;
    private long lastEatEndTime = 0;
    private long eatCooldownMs = 150;
    private long nextCritAttackTime = 0;
    private boolean isFalling = false;
    private final long minCritReactionDelayMs = 50;
    private final long maxCritReactionDelayMs = 150;
    private boolean hasAttackedTarget = false; // Tracks if the current target has been attacked

    @Override
    public void onInitializeClient() {
        LOGGER.info("Advanced Player-Only Sword Triggerbot Initialized!");

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && client.world != null) {
                if (toggleKey.wasPressed()) {
                    enabled = !enabled;
                    client.player.sendMessage(net.minecraft.text.Text.literal("Advanced Player-Only Sword Triggerbot: " + (enabled ? "Enabled" : "Disabled")), true);
                }

                if (enabled) {
                    HitResult hitResult = client.crosshairTarget;
                    if (hitResult != null && hitResult.getType() == HitResult.Type.ENTITY) {
                        EntityHitResult entityHitResult = (EntityHitResult) hitResult;
                        Entity targetEntity = entityHitResult.getEntity();

                        if (targetEntity instanceof PlayerEntity targetPlayer && targetPlayer != client.player && targetPlayer.isAlive()) {
                            ItemStack mainHandStack = client.player.getMainHandStack();
                            ItemStack offHandStack = client.player.getOffHandStack();

                            boolean mainHandSword = mainHandStack.getItem() instanceof SwordItem;
                            boolean isEating = client.player.isUsingItem() && client.player.getActiveHand() == Hand.OFF_HAND && offHandStack.isFood();
                            boolean canAttackAfterEat = System.currentTimeMillis() - lastEatEndTime >= eatCooldownMs;
                            boolean canCritSpam = client.player.isOnGround() && !client.player.hasStatusEffect(StatusEffects.JUMPING) && client.player.isSprinting();

                            if (mainHandSword && !isEating && canAttackAfterEat) {
                                if (targetedEntity != targetPlayer) {
                                    targetedEntity = targetPlayer;
                                    targetAcquiredTime = System.currentTimeMillis() + firstAttackDelayMs; // Apply initial delay
                                    hasAttackedTarget = false; // Reset attack tracker for the new target
                                }

                                long timeSinceAcquired = System.currentTimeMillis() - (targetAcquiredTime - firstAttackDelayMs); // Adjust for initial delay
                                int attackDelay = random.nextInt(maxAttackDelayMs - minAttackDelayMs + 1) + minAttackDelayMs;

                                if (timeSinceAcquired >= (hasAttackedTarget ? 0 : firstAttackDelayMs) && System.currentTimeMillis() >= nextAttackTime) {
                                    boolean shouldAttack = false;

                                    if (canCritSpam && System.currentTimeMillis() >= nextCritAttackTime) {
                                        int critSpamDelay = random.nextInt(100) + 100;
                                        nextCritAttackTime = System.currentTimeMillis() + critSpamDelay;
                                        attackDelay = critSpamDelay;
                                        shouldAttack = true;
                                    } else if (client.player.getVelocity().getY() < -0.05) {
                                        isFalling = true;
                                        if (System.currentTimeMillis() >= nextCritAttackTime && targetedEntity != null) {
                                            long critReactionDelay = random.nextInt((int) (maxCritReactionDelayMs - minCritReactionDelayMs + 1)) + minCritReactionDelayMs;
                                            nextCritAttackTime = System.currentTimeMillis() + critReactionDelay;
                                            attackDelay = (int) critReactionDelay;
                                            shouldAttack = true;
                                            isFalling = false;
                                        }
                                    } else if (random.nextDouble() < triggerChance) {
                                        shouldAttack = true;
                                    }

                                    if (shouldAttack) {
                                        nextAttackTime = System.currentTimeMillis() + attackDelay;
                                        simulateLeftClick(client.getNetworkHandler());
                                        client.interactionManager.attackEntity(client.player, targetPlayer);
                                        client.player.swingHand(Hand.MAIN_HAND);
                                        hasAttackedTarget = true; // Mark that the current target has been attacked
                                    }
                                }
                            } else {
                                targetedEntity = null;
                                targetAcquiredTime = 0;
                                hasAttackedTarget = false; // Reset when no longer targeting or conditions aren't met
                                client.player.setYaw(client.player.prevYaw);
                                client.player.setPitch(client.player.prevPitch);
                            }
                        } else {
                            targetedEntity = null;
                            targetAcquiredTime = 0;
                            hasAttackedTarget = false; // Reset when no longer targeting
                            client.player.setYaw(client.player.prevYaw);
                            client.player.setPitch(client.player.prevPitch);
                        }
                    } else {
                        targetedEntity = null;
                        targetAcquiredTime = 0;
                        hasAttackedTarget = false; // Reset when triggerbot is disabled
                        client.player.setYaw(client.player.prevYaw);
                        client.player.setPitch(client.player.prevPitch);
                    }
                }
            }

            // Update lastEatEndTime when eating stops
            if (client.player != null && !client.player.isUsingItem() && System.currentTimeMillis() - lastEatEndTime > eatCooldownMs) {
                ItemStack offHandStack = client.player.getOffHandStack();
                if (offHandStack.isFood()) {
                    lastEatEndTime = System.currentTimeMillis();
                }
            }
        });
    }

    private void simulateLeftClick(net.minecraft.client.network.ClientPlayNetworkHandler networkHandler) {
        networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket(net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, net.minecraft.util.math.BlockPos.ORIGIN, net.minecraft.util.math.Direction.DOWN));
        networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket(net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, net.minecraft.util.math.BlockPos.ORIGIN, net.minecraft.util.math.Direction.DOWN));
    }
}
