package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;
import java.util.UUID;

public class TriggerBotClient implements ClientModInitializer {

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Random random = new Random();

    private KeyBinding toggleKey;
    private boolean enabled = false;

    private long lastAttackTime = 0;
    private long lastSwitchTime = 0;
    private long lastJumpTime = 0;

    private UUID lastTargetUUID = null;

    @Override
    public void onInitializeClient() {
        toggleKey = new KeyBinding("key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.triggerbot");
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
            }
            if (enabled) tick();
        });
    }

    private void tick() {
        if (mc.player == null || mc.world == null || mc.crosshairTarget == null) return;

        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof PlayerEntity target)) return;
        if (target.isInvisible() || !target.isAlive()) return;

        if (!canAttackTarget(target)) return;

        double distance = mc.player.squaredDistanceTo(target);
        if (distance > 9.0) return; // 3 blocks squared = 9

        if (isMissDueToFOV(target)) return;

        long now = System.currentTimeMillis();

        // Handle switching targets with a delay
        if (!target.getUuid().equals(lastTargetUUID)) {
            if (now - lastSwitchTime < 300) return;
            lastTargetUUID = target.getUuid();
            lastSwitchTime = now;
        }

        // Handle jump tracking
        boolean isJumpingUp = !mc.player.isOnGround() && mc.player.getVelocity().y > 0;
        boolean isFalling = mc.player.fallDistance > 0 && !mc.player.isOnGround();

        if (isJumpingUp) {
            lastJumpTime = now;
        }

        if (isJumpingUp && now - lastJumpTime < 100) return;

        long delay = isFalling
                ? 350 + random.nextInt(75)  // Crit timing
                : 550 + random.nextInt(75); // Normal hit timing

        if (now - lastAttackTime < delay) return;

        // Swing + Attack
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.attackEntity(mc.player, target);
        lastAttackTime = now;
    }

    private boolean canAttackTarget(PlayerEntity target) {
        ItemStack mainHand = mc.player.getMainHandStack();
        ItemStack offHand = mc.player.getOffHandStack();

        if (!isSword(mainHand)) return;

        // Don't attack if player is eating
        if (mc.player.isUsingItem() && offHand.getItem().isFood()) return false;

        // Don't attack if shield is blocking
        if (target.isUsingItem() && target.getActiveItem().isOf(Items.SHIELD)) return false;

        // Don't attack through walls
        Vec3d eyePos = mc.player.getCameraPosVec(1.0F);
        Vec3d lookVec = mc.player.getRotationVec(1.0F);
        Vec3d reach = eyePos.add(lookVec.multiply(3.0));

        HitResult ray = mc.world.raycast(new net.minecraft.util.math.RayTraceContext(
                eyePos, reach,
                net.minecraft.util.math.RayTraceContext.ShapeType.OUTLINE,
                net.minecraft.util.math.RayTraceContext.FluidHandling.NONE,
                mc.player
        ));

        return ray.getType() != HitResult.Type.BLOCK;
    }

    private boolean isSword(ItemStack stack) {
        return stack.isOf(Items.WOODEN_SWORD) || stack.isOf(Items.STONE_SWORD)
                || stack.isOf(Items.IRON_SWORD) || stack.isOf(Items.GOLDEN_SWORD)
                || stack.isOf(Items.DIAMOND_SWORD) || stack.isOf(Items.NETHERITE_SWORD);
    }

    private boolean isMissDueToFOV(PlayerEntity target) {
        Vec3d playerVec = mc.player.getCameraPosVec(1.0F);
        Vec3d targetVec = target.getPos().add(0, target.getStandingEyeHeight(), 0);
        Vec3d diff = targetVec.subtract(playerVec).normalize();
        Vec3d look = mc.player.getRotationVec(1.0F);
        double dot = look.dotProduct(diff);

        return dot < 0.98 || mc.player.squaredDistanceTo(target) > 9.0;
    }
}