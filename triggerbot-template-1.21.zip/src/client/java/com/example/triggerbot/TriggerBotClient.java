package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Random random = new Random();
    private boolean triggerBotEnabled = false;
    private KeyBinding toggleKey;
    private long lastAttackTime = 0;
    private long lastEatTime = 0;

    @Override
    public void onInitializeClient() {
        toggleKey = new KeyBinding("key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.triggerbot");
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            toggleKey.setPressed(InputUtil.isKeyPressed(mc.getWindow().getHandle(), toggleKey.getDefaultKey().getCode()));
            if (toggleKey.wasPressed()) {
                triggerBotEnabled = !triggerBotEnabled;
            }

            if (!triggerBotEnabled || mc.player == null || mc.world == null || mc.crosshairTarget == null) return;

            if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof PlayerEntity target)) return;
            if (target == mc.player || target.isInvisible() || !target.isAlive()) return;
            if (!mc.player.getMainHandStack().getItem().isIn(Items.SWORDS)) return;
            if (!mc.player.canSee(target)) return;
            if (target.isUsingItem() && target.getActiveItem().getItem() == Items.SHIELD) return;

            boolean isFalling = mc.player.fallDistance > 0 && !mc.player.isOnGround();
            long now = System.currentTimeMillis();

            if (mc.player.isUsingItem() && mc.player.getOffHandStack().getItem().isFood()) {
                lastEatTime = now;
                return;
            }
            if (now - lastEatTime < 150) return;

            // FOV check
            Vec3d playerDir = mc.player.getRotationVec(1.0F);
            Vec3d toTarget = target.getPos().add(0, target.getHeight() / 2.0, 0).subtract(mc.player.getCameraPosVec(1.0F)).normalize();
            double dot = playerDir.dotProduct(toTarget);
            if (dot < Math.cos(Math.toRadians(35))) return; // ±35 degrees

            double distance = mc.player.squaredDistanceTo(target);
            if ((random.nextFloat() < 0.05f || (distance > 9.61 && distance < 10.24))) return; // Miss chance

            float attackCooldown = mc.player.getAttackCooldownProgress(0.0f);
            if (attackCooldown < 1.0f) return;

            long delay = isFalling
                ? 350 + random.nextInt(75)   // 350–425ms for crits
                : 550 + random.nextInt(75);  // 550–625ms normal

            if (now - lastAttackTime >= delay) {
                mc.player.swingHand(mc.player.getActiveHand());
                mc.interactionManager.attackEntity(mc.player, target);
                lastAttackTime = now;
            }
        });
    }
}