package com.example.triggerbot.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Random random = new Random();

    private static final int MIN_REACTION_DELAY = 150;
    private static final int MAX_REACTION_DELAY = 300;
    private static final int MIN_NEW_TARGET_DELAY = 400;
    private static final int MAX_NEW_TARGET_DELAY = 600;
    private static final int MIN_GROUND_COOLDOWN = 545;
    private static final int MAX_GROUND_COOLDOWN = 630;
    private static final boolean ENABLE_JITTER = true;

    private static Entity lastTarget = null;
    private static long lastAttackTime = 0;
    private static long attackReadyTime = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null || client.options.attackKey.isPressed()) {
                return;
            }

            AttackQueue.tick();

            Entity target = getCrosshairTarget();
            long now = System.currentTimeMillis();

            if (target != null && target != lastTarget) {
                attackReadyTime = now + randBetween(MIN_NEW_TARGET_DELAY, MAX_NEW_TARGET_DELAY);
                lastTarget = target;
            }

            if (target != null && now >= attackReadyTime && now - lastAttackTime >= getRandomCooldown()) {
                boolean shouldMiss = random.nextInt(randBetween(17, 20)) == 0;
                if (!shouldMiss) {
                    AttackQueue.queue(target, randBetween(MIN_REACTION_DELAY, MAX_REACTION_DELAY));
                } else {
                    // Miss: swing only
                    mc.player.swingHand(mc.player.getActiveHand());
                }
                lastAttackTime = now;

                if (ENABLE_JITTER) {
                    applyAimJitter();
                }
            }
        });
    }

    private Entity getCrosshairTarget() {
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != net.minecraft.util.hit.HitResult.Type.ENTITY) return null;
        Entity entity = ((net.minecraft.util.hit.EntityHitResult) mc.crosshairTarget).getEntity();

        if (!(entity instanceof LivingEntity) || entity.isInvisible() || !entity.isAlive()) return null;

        Vec3d lookVec = mc.player.getRotationVec(1.0F).normalize();
        Vec3d targetVec = entity.getPos().subtract(mc.player.getCameraPosVec(1.0F)).normalize();
        double dot = lookVec.dotProduct(targetVec);

        double threshold = 0.98 + (random.nextDouble() * 0.01); // dot between 0.98 and 0.99
        return dot >= threshold ? entity : null;
    }

    private int getRandomCooldown() {
        boolean onGround = mc.player.isOnGround();
        return onGround
                ? randBetween(MIN_GROUND_COOLDOWN, MAX_GROUND_COOLDOWN)
                : 0;
    }

    private static int randBetween(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    private void applyAimJitter() {
        float jitterYaw = (random.nextFloat() - 0.5f) * 0.5f;   // ±0.25°
        float jitterPitch = (random.nextFloat() - 0.5f) * 0.5f;
        mc.player.setYaw(mc.player.getYaw() + jitterYaw);
        mc.player.setPitch(mc.player.getPitch() + jitterPitch);
    }
}