package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Random random = new Random();

    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long lastTargetSwitchTime = 0;
    private static Entity lastTarget = null;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zoomfixer.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.video"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                System.out.println("ZoomFixer " + (enabled ? "enabled" : "disabled"));
            }

            if (!enabled || client.player == null || client.world == null || client.currentScreen != null)
                return;

            Entity target = getTarget();
            if (target instanceof PlayerEntity playerTarget) {
                if (mc.player.squaredDistanceTo(playerTarget) > 9.0) return; // 3.00 blocks

                long now = System.currentTimeMillis();

                if (lastTarget != target) {
                    if (now - lastTargetSwitchTime < 250 + random.nextInt(100)) return;
                    lastTargetSwitchTime = now;
                    lastTarget = target;
                }

                if (mc.player.isUsingItem() && mc.player.getOffHandStack().getItem().isFood()) return;

                ItemStack mainHand = mc.player.getMainHandStack();
                if (!isSword(mainHand)) return;

                if (!playerTarget.isInvisible() && isAttackable(playerTarget)) {
                    boolean isFalling = mc.player.getVelocity().y < -0.08;
                    boolean isGrounded = mc.player.isOnGround();
                    boolean isJumping = !isGrounded && mc.player.getVelocity().y > 0.08;

                    long pingScaled = Math.max(0, getPing() / 2);
                    long currentTime = System.currentTimeMillis();

                    if (isFalling) {
                        if (currentTime - lastAttackTime >= (350 + random.nextInt(75)) + pingScaled) {
                            attack(target);
                        }
                    } else if (!isJumping && isGrounded) {
                        if (currentTime - lastAttackTime >= (550 + random.nextInt(75)) + pingScaled) {
                            attack(target);
                        }
                    }
                }
            }
        });
    }

    private void attack(Entity target) {
        lastAttackTime = System.currentTimeMillis();

        if (mc.interactionManager != null) {
            mc.interactionManager.attackEntity(mc.player, target);
        }

        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private boolean isSword(ItemStack stack) {
        return stack.isOf(Items.WOODEN_SWORD) || stack.isOf(Items.STONE_SWORD)
                || stack.isOf(Items.IRON_SWORD) || stack.isOf(Items.GOLDEN_SWORD)
                || stack.isOf(Items.DIAMOND_SWORD) || stack.isOf(Items.NETHERITE_SWORD);
    }

    private boolean isAttackable(PlayerEntity target) {
        if (!hasLineOfSight(target)) return false;

        ItemStack offHand = target.getOffHandStack();
        return !(offHand.getItem() == Items.SHIELD && target.isBlocking());
    }

    private boolean hasLineOfSight(Entity target) {
        Vec3d start = mc.player.getCameraPosVec(1.0F);
        Vec3d end = target.getPos().add(0, target.getStandingEyeHeight(), 0);

        RaycastContext context = new RaycastContext(start, end,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                mc.player);

        HitResult result = mc.world.raycast(context);
        return result.getType() == HitResult.Type.MISS;
    }

    private Entity getTarget() {
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity entity = ((net.minecraft.util.hit.EntityHitResult) mc.crosshairTarget).getEntity();
            if (entity instanceof LivingEntity && entity != mc.player && mc.player.canSee(entity)) {
                return entity;
            }
        }
        return null;
    }

    private int getPing() {
        if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null) {
            return mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
        }
        return 0;
    }
}