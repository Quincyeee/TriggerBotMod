package com.example.triggerbot;

import net.minecraft.entity.Entity;

public class QueuedAttack {
    public final Entity target;
    public final long executeAt;

    public QueuedAttack(Entity target, long executeAt) {
        this.target = target;
        this.executeAt = executeAt;
    }
}