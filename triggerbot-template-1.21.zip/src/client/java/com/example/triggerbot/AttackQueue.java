package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.LinkedList;
import java.util.Queue;

public class AttackQueue {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Queue<QueuedAttack> attackQueue = new LinkedList<>();

    public static void queue(Entity target, long delayMs) {
        long executeAt = System.currentTimeMillis() + delayMs;
        attackQueue.add(new QueuedAttack(target, executeAt));
    }

    public static void tick() {
        if (mc.player == null || mc.world == null || attackQueue.isEmpty()) return;

        long now = System.currentTimeMillis();
        while (!attackQueue.isEmpty() && attackQueue.peek().executeAt <= now) {
            QueuedAttack queued = attackQueue.poll();
            if (queued == null || queued.target == null || !queued.target.isAlive()) continue;

            Vec3d eyes = mc.player.getCameraPosVec(1.0F);
            Vec3d targetPos = queued.target.getPos().add(0, queued.target.getHeight() / 2.0, 0);
            if (eyes.distanceTo(targetPos) > 6.0) continue;

            attackEntity(queued.target);
        }
    }

    private static void attackEntity(Entity target) {
        ClientPlayerEntity player = mc.player;
        ClientPlayerInteractionManager manager = mc.interactionManager;

        if (manager != null && player != null && target != null) {
            manager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
            mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(target, player.isSneaking()));
        }
    }
}
