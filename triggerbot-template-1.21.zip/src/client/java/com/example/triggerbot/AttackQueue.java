package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

import java.util.Iterator;
import java.util.LinkedList;

public class AttackQueue {
    private static final LinkedList<QueuedAttack> queue = new LinkedList<>();
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static void queue(Entity target, long delayMs) {
        queue.add(new QueuedAttack(target, System.currentTimeMillis() + delayMs));
    }

    public static void tick() {
        if (queue.isEmpty() || mc.player == null || mc.world == null) return;

        long now = System.currentTimeMillis();
        Iterator<QueuedAttack> iterator = queue.iterator();

        while (iterator.hasNext()) {
            QueuedAttack qa = iterator.next();
            if (now >= qa.executeAt && qa.target.isAlive() && mc.player.canSee(qa.target)) {
                if (qa.target instanceof LivingEntity) {
                    mc.interactionManager.attackEntity(mc.player, qa.target);
                    mc.player.swingHand(Hand.MAIN_HAND);
                }
                iterator.remove();
            }
        }
    }
}