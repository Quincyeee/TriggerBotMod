package com.example.triggerbot.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class AttackQueue {
    private static final Queue<QueuedAttack> attackQueue = new LinkedList<>();
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static void queue(Entity target, long delayMs) {
        long executeAt = System.currentTimeMillis() + delayMs;
        attackQueue.add(new QueuedAttack(target, executeAt));
    }

    public static void tick() {
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        long now = System.currentTimeMillis();
        Iterator<QueuedAttack> iterator = attackQueue.iterator();

        while (iterator.hasNext()) {
            QueuedAttack qa = iterator.next();
            if (now >= qa.executeAt && qa.target.isAlive()) {
                ClientPlayerEntity player = mc.player;
                ClientPlayerInteractionManager im = mc.interactionManager;

                if (im != null) {
                    im.attackEntity(player, qa.target);
                    mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(qa.target, player.isSneaking()));
                    player.swingHand(Hand.MAIN_HAND);
                }

                iterator.remove();
            }
        }
    }
}