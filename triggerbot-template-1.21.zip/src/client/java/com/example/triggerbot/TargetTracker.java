package com.example.triggerbot;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;

public class TargetTracker {
    private PlayerEntity lastTarget = null;
    private long lastSeen = 0;

    public boolean shouldAttack(ClientPlayerEntity player, PlayerEntity target) {
        long now = System.currentTimeMillis();
        if (target != lastTarget) {
            if (now - lastSeen < 800) return false;
            lastTarget = target;
            lastSeen = now;
            return false;
        }
        if (now - lastSeen > 1500) lastSeen = now;
        return true;
    }
}