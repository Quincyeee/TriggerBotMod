
package com.example.triggerbot;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;

public class TargetTracker {
    private PlayerEntity lastTarget = null;
    private boolean delayRequired = true;
    private long delayStartTime = 0;

    public boolean shouldAttack(ClientPlayerEntity player, PlayerEntity target) {
        if (target == lastTarget) {
            // If delay is pending, block until it's passed
            if (delayRequired) {
                if (delayStartTime == 0) {
                    delayStartTime = System.currentTimeMillis();
                    return false;
                }
                long now = System.currentTimeMillis();
                long delay = 80 + (long)(Math.random() * 70); // 80–150ms
                if (now - delayStartTime >= delay) {
                    delayRequired = false;
                    return true;
                }
                return false;
            }
            return true;
        }

        // Do not switch automatically to new targets
        return false;
    }

    public void setLastTarget(PlayerEntity target) {
        if (target != lastTarget) {
            delayRequired = true; // Force delay again after switching target manually
            delayStartTime = 0;
        }
        lastTarget = target;
    }

    public void triggerMissedHit() {
        // Called when a legit miss happens, resets delay
        delayRequired = true;
        delayStartTime = 0;
    }
}
