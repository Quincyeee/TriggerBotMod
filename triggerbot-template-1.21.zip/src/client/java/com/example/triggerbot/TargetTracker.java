
package com.example.triggerbot;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;

public class TargetTracker {
    private PlayerEntity lastTarget = null;

    public boolean shouldAttack(ClientPlayerEntity player, PlayerEntity target) {
        // Always allow attack if still looking at the same target
        return target == lastTarget;
    }

    public void setLastTarget(PlayerEntity target) {
        this.lastTarget = target;
    }

    public void triggerMissedHit() {
        // No delay needed anymore
    }
}
