package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class TriggerBotLogic {
        private static final AttackManager attackManager = new AttackManager();

    public static void tick(MinecraftClient client) {
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof PlayerEntity target)) return;

        ClientPlayerEntity player = client.player;
        if (player == null || !(player.getMainHandStack().getItem() instanceof SwordItem)) return;

        if (!TriggerBotClient.targetTracker.shouldAttack(player, target)) return;

        attackManager.tryAttack(player, target);
    }
}