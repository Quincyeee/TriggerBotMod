package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.EntityHitResult;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;

public class TriggerBotLogic {
    private static final TargetTracker tracker = new TargetTracker();
    private static final AttackManager attackManager = new AttackManager();

    public static void tick(MinecraftClient client) {
        if (!(client.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof PlayerEntity target)) return;
        ClientPlayerEntity player = client.player;

        if (!player.getMainHandStack().getItem().getClass().equals(SwordItem.class)) return;
        if (!tracker.shouldAttack(player, target)) return;

        attackManager.tryAttack(player, target);
    }
}