package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long reactionStartTime = -1;
    private static Entity lastTarget = null;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.of("TriggerBot " + (enabled ? "Enabled" : "Disabled")), false);
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) return;
            if (client.crosshairTarget.getType() != net.minecraft.util.hit.HitResult.Type.ENTITY) return;

            Entity target = ((net.minecraft.util.hit.EntityHitResult) client.crosshairTarget).getEntity();

            if (!(target instanceof PlayerEntity playerTarget)) return;
            if (!playerTarget.isAlive() || target == client.player) return;
            if (!client.player.canSee(target)) return;

            if (!client.player.getMainHandStack().getItem().toString().toLowerCase().contains("sword")) return;

            if (client.player.isUsingItem() &&
                client.player.getActiveHand() == Hand.OFF_HAND &&
                client.player.getOffHandStack().isFood()) return;

            double angle = getAngleToTarget(target);
            if (angle > 35) return;

            if (target != lastTarget) {
                lastTarget = target;
                reactionStartTime = System.currentTimeMillis();
                return;
            }

            if (reactionStartTime == -1) return;
            long reactionDelay = 100 + (long)(Math.random() * 150);
            if (System.currentTimeMillis() - reactionStartTime < reactionDelay) return;

            if (Math.random() < 0.04) return;
            if (Math.random() > 0.92) return;

            double dist = client.player.distanceTo(target);
            if ((angle > 20 && angle < 35 && Math.random() < 0.6) ||
                (dist > 3.1 && dist < 3.3 && Math.random() < 0.5)) return;

            long now = System.currentTimeMillis();
            boolean onGround = client.player.isOnGround();
            boolean falling = client.player.getVelocity().y < -0.08;

            long delay = onGround
                    ? 600 + (long) (Math.random() * 25)
                    : 625 + (long) (Math.random() * 15);

            if (now - lastAttackTime < delay) return;

            // Prevent attacking mid-air if still sprinting
            if (!onGround && client.options.sprintKey.isPressed()) return;

            if (!onGround && !falling) return;

            float yaw = client.player.getYaw();
            float jitter = (float) (Math.random() * 1.6 - 0.8);
            client.player.setYaw(yaw + jitter);

            if (client.interactionManager != null &&
                client.player.getAttackCooldownProgress(0.0f) >= 0.99f) {
                client.interactionManager.attackEntity(client.player, target);
                client.player.swingHand(Hand.MAIN_HAND);
                lastAttackTime = now;
                reactionStartTime = -1;
            }
        });
    }

    private static double getAngleToTarget(Entity entity) {
        double dx = entity.getX() - client.player.getX();
        double dz = entity.getZ() - client.player.getZ();
        float yawToTarget = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
        float deltaYaw = Math.abs(wrapAngle(yawToTarget - client.player.getYaw()));
        return deltaYaw;
    }

    private static float wrapAngle(float angle) {
        angle %= 360.0f;
        if (angle >= 180.0f) angle -= 360.0f;
        if (angle < -180.0f) angle += 360.0f;
        return angle;
    }
}
