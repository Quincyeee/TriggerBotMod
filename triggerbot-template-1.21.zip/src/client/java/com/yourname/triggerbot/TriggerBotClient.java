package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static long lastAttackTime = 0;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleKey.wasPressed()) {
                enabled = !enabled;
            }

            if (!enabled || client.player == null || client.world == null || client.isPaused()) return;

            if (isHoldingSword(client) && !client.player.isUsingItem()) {
                if (System.currentTimeMillis() - lastAttackTime >= getRandomDelay()) {
                    HitResult hit = client.crosshairTarget;
                    if (hit instanceof EntityHitResult) {
                        Entity target = ((EntityHitResult) hit).getEntity();
                        if (target instanceof PlayerEntity && target != client.player && isValidTarget(client.player, target)) {
                            attack(client, (LivingEntity) target);
                            lastAttackTime = System.currentTimeMillis();
                        } else if (shouldMiss(client, target)) {
                            swing(client);
                            lastAttackTime = System.currentTimeMillis();
                        }
                    }
                }
            }
        });
    }

    private boolean isHoldingSword(MinecraftClient client) {
        return client.player.getMainHandStack().getItem() instanceof SwordItem;
    }

    private boolean isValidTarget(PlayerEntity player, Entity target) {
        return player.squaredDistanceTo(target) <= 9.0 && player.canSee(target); // <= 3 blocks, not through walls
    }

    private long getRandomDelay() {
        return 500 + new Random().nextInt(151); // 500ms to 650ms
    }

    private boolean shouldMiss(MinecraftClient client, Entity target) {
        if (!(target instanceof PlayerEntity)) return false;
        double dist = client.player.squaredDistanceTo(target);
        return dist >= 9.5 && dist <= 11.0 && new Random().nextInt(100) < 4; // 4% miss
    }

    private void attack(MinecraftClient client, LivingEntity target) {
        client.interactionManager.attackEntity(client.player, target);
        swing(client);
    }

    private void swing(MinecraftClient client) {
        client.player.swingHand(Hand.MAIN_HAND);
    }
}
