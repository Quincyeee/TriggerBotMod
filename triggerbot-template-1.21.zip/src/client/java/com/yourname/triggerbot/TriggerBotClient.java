package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static final KeyBinding toggleKey = new KeyBinding(
        "key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "category.triggerbot");
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long lastEatTime = 0;
    private static boolean wasEating = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                System.out.println("TriggerBot: " + (enabled ? "Enabled" : "Disabled"));
            }

            if (!enabled || client.player == null || client.world == null || client.currentScreen != null) return;

            PlayerEntity player = client.player;
            long now = System.currentTimeMillis();

            // Check for offhand eating
            ItemStack offhand = player.getOffHandStack();
            boolean isEating = offhand.getItem().isFood() && player.isUsingItem();
            if (isEating) {
                wasEating = true;
                lastEatTime = now;
                return;
            }
            if (wasEating && now - lastEatTime < 150) return;
            wasEating = false;

            // Target under crosshair
            Entity target = client.targetedEntity;
            if (!(target instanceof PlayerEntity) || !target.isAlive()) return;

            double distance = player.squaredDistanceTo(target);
            if (distance > 9) return; // 3 blocks squared = 9

            if (!(target instanceof LivingEntity)) return;

            ItemStack mainHand = player.getMainHandStack();
            boolean isSword = mainHand.getItem() instanceof SwordItem;
            boolean isAxe = mainHand.getItem() instanceof AxeItem;
            if (!isSword && !isAxe) return;

            // Simulate high-tier human reaction time
            if (now - lastAttackTime < 30) return;

            // Check cooldowns
            float attackCooldown = player.getAttackCooldownProgress(0);
            boolean canAttack = false;

            if (isSword && attackCooldown >= 0.9f && now - lastAttackTime >= 550 && now - lastAttackTime <= 625) {
                canAttack = true;
            } else if (isAxe && attackCooldown >= 0.9f && now - lastAttackTime >= 850 && now - lastAttackTime <= 1000) {
                canAttack = true;
            }

            // Critical hit logic (falling after jump)
            if (player.fallDistance > 0.1f && !player.isOnGround()) {
                long jumpTime = now - player.age * 50L; // Approximate jump time
                if (jumpTime >= 400 && jumpTime <= 550) {
                    canAttack = true;
                }
            }

            if (canAttack) {
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                lastAttackTime = now;

                // Axe disables shield if blocking
                if (isAxe && target instanceof PlayerEntity targetPlayer && targetPlayer.isBlocking()) {
                    player.resetLastAttackedTicks();
                }
            }
        });
    }
}
