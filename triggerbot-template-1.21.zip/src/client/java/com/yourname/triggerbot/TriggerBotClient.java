package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static long lastAttackTime = 0;

    private static final long MIN_ATTACK_DELAY_MS = 615;
    private static final long MAX_ATTACK_DELAY_MS = 625;

    private static final KeyBinding toggleKey = new KeyBinding(
        "key.triggerbot.toggle",
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_V,
        "category.triggerbot"
    );

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            toggleKey.setPressed(InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_V));
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                System.out.println("TriggerBot: " + (enabled ? "Enabled" : "Disabled"));
            }

            if (enabled && client.player != null && client.crosshairTarget != null && client.currentScreen == null) {
                if (!(client.player.getMainHandStack().getItem() == Items.IRON_SWORD ||
                      client.player.getMainHandStack().getItem() == Items.DIAMOND_SWORD ||
                      client.player.getMainHandStack().getItem() == Items.NETHERITE_SWORD ||
                      client.player.getMainHandStack().getItem() == Items.STONE_SWORD ||
                      client.player.getMainHandStack().getItem() == Items.GOLDEN_SWORD ||
                      client.player.getMainHandStack().getItem() == Items.WOODEN_SWORD)) return;

                if (!client.player.getOffHandStack().isEmpty() &&
                    client.player.getOffHandStack().getItem().isFood()) return;

                if (client.crosshairTarget.getType().toString().equals("ENTITY")) {
                    if (client.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult entityHit) {
                        if (entityHit.getEntity() instanceof PlayerEntity target) {
                            if (client.player.squaredDistanceTo(target) <= 9.0) {
                                long now = System.currentTimeMillis();
                                long attackDelay = MIN_ATTACK_DELAY_MS +
                                        (long) (Math.random() * (MAX_ATTACK_DELAY_MS - MIN_ATTACK_DELAY_MS));

                                if (now - lastAttackTime >= attackDelay &&
                                    client.player.getAttackCooldownProgress(0.0f) >= 0.99f &&
                                    client.interactionManager != null &&
                                    client.player.canSee(target)) {
                                    client.interactionManager.attackEntity(client.player, target);
                                    client.player.swingHand(Hand.MAIN_HAND);
                                    lastAttackTime = now;
                                }
                            }
                        }
                    }
                }
            }
        });
    }
}
