package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static final KeyBinding toggleKey = new KeyBinding("key.triggerbot.toggle", GLFW.GLFW_KEY_V, "category.triggerbot");

    private static long lastAttackTime = 0;
    private static long lastEatTime = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                System.out.println("TriggerBot " + (enabled ? "enabled" : "disabled"));
            }

            if (!enabled || client.player == null || client.world == null) return;

            ClientPlayerEntity player = client.player;

            // Don't attack if eating from offhand
            ItemStack offhand = player.getStackInHand(Hand.OFF_HAND);
            if (offhand.isFood() && player.isUsingItem()) {
                lastEatTime = System.currentTimeMillis();
                return;
            }

            // Prevent attack if within 150ms after eating
            if (System.currentTimeMillis() - lastEatTime < 150) return;

            // Ensure player holds a sword
            ItemStack mainHand = player.getMainHandStack();
            if (!mainHand.isOf(Items.WOODEN_SWORD) && !mainHand.isOf(Items.STONE_SWORD) &&
                !mainHand.isOf(Items.IRON_SWORD) && !mainHand.isOf(Items.GOLDEN_SWORD) &&
                !mainHand.isOf(Items.DIAMOND_SWORD) && !mainHand.isOf(Items.NETHERITE_SWORD)) return;

            if (client.crosshairTarget == null || client.crosshairTarget.getType() != net.minecraft.util.hit.HitResult.Type.ENTITY)
                return;

            Entity target = ((net.minecraft.util.hit.EntityHitResult) client.crosshairTarget).getEntity();
            if (!(target instanceof PlayerEntity) || target == player || !target.isAlive()) return;

            double distance = player.squaredDistanceTo(target);
            if (distance > 9.0) return; // max reach ~= 3 blocks

            // Miss under human-like conditions
            if ((distance > 9.5 || !isCrosshairCloseTo(target))) {
                return;
            }

            boolean onGround = player.isOnGround();
            boolean falling = player.getVelocity().y < 0;

            long now = System.currentTimeMillis();
            long delay = onGround ? randomBetween(600, 625) : randomBetween(620, 635);

            if (!onGround && player.getVelocity().y > 0) return; // too early in jump

            if (now - lastAttackTime >= delay) {
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                lastAttackTime = now;
            }
        });
    }

    private static int randomBetween(int min, int max) {
        return min + (int)(Math.random() * (max - min + 1));
    }

    private static boolean isCrosshairCloseTo(Entity target) {
        return target != null && client.player != null && target.isAlive(); // Simple placeholder; can be improved
    }
}
