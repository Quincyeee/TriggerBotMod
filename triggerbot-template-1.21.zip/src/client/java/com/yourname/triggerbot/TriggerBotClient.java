package com.yourname.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;

import java.util.Random;

public class TriggerBot {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static long lastAttackTime = 0;
    private static long nextDelay = 550 + new Random().nextInt(41);  // 550–590ms for normal attack delay
    private static long lastKnockbackTime = 0;
    private static double lastVelocityY = 0;
    private static long lastHitTime = 0;
    private static PlayerEntity lastSeenTarget = null;
    private static long firstSeenTime = 0;
    private static final Random random = new Random();
    
    // Detects when the player is airborne after knockback and sets crit window (580-620ms)
    private static boolean isFalling(ClientPlayerEntity player) {
        return player.fallDistance > 0.0F;
    }

    // Get critical hit delay when falling
    private static long getCriticalHitDelay() {
        return 580 + random.nextInt(41); // 580-620ms
    }

    // Update attack logic based on timing and crits
    public static void attack() {
        ClientPlayerEntity player = mc.player;
        if (player == null) return;
        if (!(mc.crosshairTarget.getEntity() instanceof PlayerEntity target)) return;

        long now = System.currentTimeMillis();
        
        // Target tracking logic
        if (lastSeenTarget != target) {
            lastSeenTarget = target;
            firstSeenTime = now;
        }

        // Wait before attacking the new target (400-450ms after seeing a target)
        if (now - firstSeenTime < 400 + random.nextInt(51)) {
            return;
        }

        // Knockback detection
        double currentVelocityY = player.getVelocity().y;
        if (currentVelocityY - lastVelocityY > 0.2) {
            lastKnockbackTime = now;
        }
        lastVelocityY = currentVelocityY;

        // Check if knockback crit window is active (350ms after knockback)
        boolean inKnockbackCritWindow = now - lastKnockbackTime >= 340 && now - lastKnockbackTime <= 390;

        // Check if player is falling and can perform a critical hit
        boolean isFalling = player.fallDistance > 0.0F;
        boolean allowCrit = isFalling && inKnockbackCritWindow;

        // Apply attack delay logic
        long attackDelay = allowCrit ? getCriticalHitDelay() : nextDelay;

        // Miss chance to make it human-like (10% miss chance)
        if (random.nextDouble() < 0.10) return;

        // Timing check for attack
        if (now - lastAttackTime >= attackDelay) {
            long swingOffset = -30 + random.nextInt(61); // Offset for swing (±30ms)

            if (swingOffset < 0) {
                player.swingHand(Hand.MAIN_HAND); // Swing first
                try {
                    Thread.sleep(-swingOffset);
                } catch (InterruptedException ignored) {}
                mc.interactionManager.attackEntity(player, target);
            } else {
                mc.interactionManager.attackEntity(player, target); // Attack first
                try {
                    Thread.sleep(swingOffset);
                } catch (InterruptedException ignored) {}
                player.swingHand(Hand.MAIN_HAND);
            }

            lastAttackTime = now;
            nextDelay = getCriticalHitDelay();
            lastHitTime = now;
        }
    }

    // ClientTickEvents to trigger attack logic each tick
    public static void onTick() {
        if (mc.player == null || mc.world == null || mc.crosshairTarget == null) return;

        // Call attack method
        attack();
    }
}
