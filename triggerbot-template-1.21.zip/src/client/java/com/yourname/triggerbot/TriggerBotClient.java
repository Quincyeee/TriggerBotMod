package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Random random = new Random();
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long lastEatTime = 0;
    private static PlayerEntity currentTarget = null;
    private static long targetStartTime = 0;

    private static final KeyBinding toggleKey = new KeyBinding(
            "key.triggerbot.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_LEFT_ALT,
            "key.categories.misc"
    );

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                System.out.println("TriggerBot " + (enabled ? "Enabled" : "Disabled"));
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) return;

            if (!(client.crosshairTarget instanceof net.minecraft.client.network.AbstractClientPlayerEntity target)) return;
            if (!(target instanceof PlayerEntity)) return;

            if (shouldSkipAttack(target)) return;

            long now = System.currentTimeMillis();

            if (client.player.isUsingItem() && isEating(client.player.getMainHandStack())) {
                lastEatTime = now;
                return;
            }

            if (now - lastEatTime < 500) return; // Delay after eating

            // Persistent target logic
            if (currentTarget == null || currentTarget.isDead()) {
                currentTarget = target;
                targetStartTime = now;
            } else if (currentTarget != target) {
                if (now - targetStartTime < 1500) return;
                currentTarget = target;
                targetStartTime = now;
            }

            if (!canAttack(now)) return;

            // 10% miss chance for humanization
            if (random.nextInt(10) == 0) return;

            // Randomized delay
            boolean onGround = client.player.isOnGround();
            long delay = onGround ? randomBetween(550, 590) : randomBetween(580, 620);

            if (now - lastAttackTime >= delay) {
                client.interactionManager.attackEntity(client.player, target);
                client.player.swingHand(Hand.MAIN_HAND);
                lastAttackTime = now;
            }
        });
    }

    private boolean isEating(ItemStack stack) {
        FoodComponent food = stack.getItem().getFoodComponent();
        return food != null;
    }

    private boolean canAttack(long now) {
        return mc.player.getAttackCooldownProgress(0.5f) >= 1.0f;
    }

    private long randomBetween(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    private boolean shouldSkipAttack(PlayerEntity target) {
        return target == mc.player || target.isCreative() || target.isSpectator();
    }
}
