package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {
    private final MinecraftClient client = MinecraftClient.getInstance();
    private final Random random = new Random();
    private boolean enabled = false;
    private long lastAttackTime = 0;
    private long lastEatTime = 0;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        // Keybind (Left Alt)
        toggleKey = new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbot"
        );
        KeyBindingHelper.registerKeyBinding(toggleKey);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle activation with Left Alt
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "Enabled" : "Disabled")),
                        false
                );
            }

            if (!enabled || client.crosshairTarget == null || client.player == null || client.world == null)
                return;

            // Don't attack while eating food in the off-hand
            if (client.player.getOffHandStack().getItem().isFood() && client.player.isUsingItem()) {
                return; // Prevent attacking while eating
            }

            // Prevent attacking for 300ms after eating
            if (System.currentTimeMillis() - lastEatTime < 300) {
                return; // Wait for 300ms after eating before allowing another attack
            }

            // Get the current target (could be a block or entity)
            HitResult hitResult = client.crosshairTarget;

            // Only proceed if the target is an entity (not a block)
            if (hitResult instanceof EntityHitResult entityHitResult) {
                Entity target = entityHitResult.getEntity();

                // Only attack if the target is a player
                if (target instanceof PlayerEntity) {
                    // Ensure the target is alive and not the player itself
                    if (target.isAlive() && target != client.player) {

                        // Ensure the player is holding a sword
                        if (client.player.getMainHandStack().getItem() instanceof SwordItem) {
                            // Reaction time: 450–480ms before the first attack
                            long now = System.currentTimeMillis();
                            if (now - lastAttackTime >= 450 + random.nextInt(31)) { // 450–480ms
                                // 90% chance to hit the target
                                if (random.nextDouble() <= 0.9) {
                                    client.interactionManager.attackEntity(client.player, target);
                                    client.player.swingHand(Hand.MAIN_HAND); // Swing animation
                                    lastAttackTime = now;
                                    lastEatTime = 0; // Reset eat time after a successful attack
                                } else { // 10% chance to miss
                                    lastAttackTime = now;
                                    lastEatTime = 0; // Reset eat time after a failed attack
                                }
                            }
                        }
                    }
                }
            }

            // Attack delay for crit spam: 580–620ms
            long now = System.currentTimeMillis();
            if (now - lastAttackTime >= 580 + random.nextInt(41)) {
                // Attack with crit spam delay (if valid target)
                if (client.player.isOnGround()) {
                    if (random.nextDouble() <= 0.9) { // 90% hit chance
                        client.interactionManager.attackEntity(client.player, client.crosshairTarget.getEntity());
                        client.player.swingHand(Hand.MAIN_HAND);
                        lastAttackTime = now;
                        lastEatTime = 0; // Reset eat time after attack
                    } else {
                        lastAttackTime = now;
                        lastEatTime = 0; // Reset eat time after missed attack
                    }
                }
            }
        });
    }
}
