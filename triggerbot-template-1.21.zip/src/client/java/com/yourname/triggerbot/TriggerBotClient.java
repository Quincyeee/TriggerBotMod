package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static long lastAttackTime = 0;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot " + (enabled ? "Enabled" : "Disabled")), false
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) return;

            // Check crosshair is on an entity
            if (client.crosshairTarget.getType() != net.minecraft.util.hit.HitResult.Type.ENTITY) return;

            Entity target = ((net.minecraft.util.hit.EntityHitResult) client.crosshairTarget).getEntity();

            if (!(target instanceof LivingEntity livingTarget)) return;
            if (!target.isAlive() || target == client.player) return;
            if (!(target instanceof net.minecraft.entity.player.PlayerEntity)) return; // Only hit players
            if (!client.player.canSee(target)) return; // No hitting through walls

            // Only attack with a sword
            if (!client.player.getMainHandStack().isOf(Items.WOODEN_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.STONE_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.IRON_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.GOLDEN_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.DIAMOND_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.NETHERITE_SWORD)) return;

            // Don't attack while eating with offhand
            if (client.player.isUsingItem() &&
                client.player.getActiveHand() == Hand.OFF_HAND &&
                client.player.getOffHandStack().isFood()) return;

            // Simulate human accuracy: 96% hit chance
            if (Math.random() > 0.96) return;

            // Simulate range error occasionally (3.1–3.3 blocks)
            double distSq = client.player.squaredDistanceTo(target);
            if (distSq > 9.0 && distSq < 10.9 && Math.random() < 0.5) return;

            // Field of View (FOV) check
            double angle = getAngleToTarget(target);
            if (angle > 25) return;  // Don't attack outside a ~50° FOV cone

            // Delay between attacks (615–625ms)
            long now = System.currentTimeMillis();
            long delay = 615 + (long) (Math.random() * 10);
            if (now - lastAttackTime < delay) return;

            if (client.interactionManager != null &&
                client.player.getAttackCooldownProgress(0.0f) >= 0.99f) {
                client.interactionManager.attackEntity(client.player, target);
                client.player.swingHand(Hand.MAIN_HAND);
                lastAttackTime = now;
            }
        });
    }

    private static double getAngleToTarget(Entity entity) {
        double dx = entity.getX() - client.player.getX();
        double dz = entity.getZ() - client.player.getZ();
        float yawToTarget = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
        float deltaYaw = Math.abs(wrapAngle(yawToTarget - client.player.getYaw()));
        return deltaYaw;
    }

    private static float wrapAngle(float angle) {
        angle %= 360.0f;
        if (angle >= 180.0f) angle -= 360.0f;
        if (angle < -180.0f) angle += 360.0f;
        return angle;
    }
}
