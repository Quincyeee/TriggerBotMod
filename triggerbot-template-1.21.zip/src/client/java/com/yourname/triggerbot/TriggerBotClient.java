package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();

    // Changed toggle key to V
    private static final KeyBinding toggleKey = new KeyBinding(
        "key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.triggerbot");

    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long lastEatTime = 0;
    private static boolean wasEating = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                System.out.println("TriggerBot: " + (enabled ? "Enabled" : "Disabled"));
            }

            if (!enabled || client.player == null || client.world == null || client.currentScreen != null) return;

            PlayerEntity player = client.player;
            long now = System.currentTimeMillis();

            // Don't attack while eating
            ItemStack offhand = player.getOffHandStack();
            boolean isEating = offhand.getItem().isFood() && player.isUsingItem();
            if (isEating) {
                wasEating = true;
                lastEatTime = now;
                return;
            }
            if (wasEating && now - lastEatTime < 150) return;
            wasEating = false;

            // Get entity under crosshair
            if (client.crosshairTarget == null || client.crosshairTarget.getType() != HitResult.Type.ENTITY) return;
            Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();

            if (!(target instanceof PlayerEntity) || !target.isAlive()) return;
            if (player.squaredDistanceTo(target) > 9) return; // 3 blocks squared
            if (!(target instanceof LivingEntity livingTarget)) return;

            ItemStack mainHand = player.getMainHandStack();
            boolean isSword = mainHand.getItem() instanceof SwordItem;
            boolean isAxe = mainHand.getItem() instanceof AxeItem;
            if (!isSword && !isAxe) return;

            // Simulated reaction delay
            if (now - lastAttackTime < 30) return;

            float cooldown = player.getAttackCooldownProgress(0.0f);
            boolean canAttack = false;

            if (isSword && cooldown >= 0.9f && now - lastAttackTime >= 550) {
                canAttack = true;
            } else if (isAxe && cooldown >= 0.9f && now - lastAttackTime >= 850) {
                canAttack = true;
            }

            // Optional critical hit: falling = crit opportunity
            if (player.fallDistance > 0.1f && !player.isOnGround()) {
                canAttack = true;
            }

            if (canAttack) {
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                lastAttackTime = now;

                // Axe disables shields if blocking
                if (isAxe && target instanceof PlayerEntity targetPlayer && targetPlayer.isBlocking()) {
                    player.resetLastAttackedTicks();
                }
            }
        });
    }
}
