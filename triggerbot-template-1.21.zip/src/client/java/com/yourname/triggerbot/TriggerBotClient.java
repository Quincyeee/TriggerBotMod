package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolItem;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {
    private final MinecraftClient client = MinecraftClient.getInstance();
    private final Random random = new Random();
    private boolean enabled = false;
    private long lastAttackTime = 0;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        // Keybind (Left Alt)
        toggleKey = new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbot"
        );
        KeyBindingHelper.registerKeyBinding(toggleKey);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle activation with Left Alt
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "Enabled" : "Disabled")),
                        false
                );
            }

            if (!enabled || client.crosshairTarget == null || client.player == null || client.world == null)
                return;

            if (!(client.crosshairTarget.getEntity() instanceof LivingEntity target)) return;

            // Ensure target is a valid player, alive and within 3-block range
            if (!target.isAlive() || target == client.player || !(target instanceof LivingEntity)) return;

            // Check if player is holding a sword
            if (!(client.player.getMainHandStack().getItem() instanceof SwordItem) &&
                !(client.player.getMainHandStack().getItem() instanceof ToolItem)) return;

            // Calculate distance between player and target
            double distance = client.player.squaredDistanceTo(target);

            if (distance > 9.0) return; // Max reach 3 blocks

            // Ensure line-of-sight (no walls)
            if (!client.player.canSee(target)) return;

            // Reaction time (450–480ms)
            long now = System.currentTimeMillis();
            if (now - lastAttackTime >= 450 + random.nextInt(31)) {  // 450–480ms delay before the first attack
                // Attack
                if (random.nextDouble() <= 0.9) { // 90% hit chance
                    client.interactionManager.attackEntity(client.player, target);
                    client.player.swingHand(Hand.MAIN_HAND); // Swing animation
                    lastAttackTime = now;
                } else { // 10% chance to miss
                    lastAttackTime = now;
                }
            }

            // Attack delay based on strafing or critting
            if (now - lastAttackTime >= (client.player.isOnGround() ? 550 + random.nextInt(51) : 580 + random.nextInt(41))) {
                if (random.nextDouble() <= 0.9) {
                    client.interactionManager.attackEntity(client.player, target);
                    client.player.swingHand(Hand.MAIN_HAND); // Swing animation
                    lastAttackTime = now;
                }
            }
        });
    }
}
