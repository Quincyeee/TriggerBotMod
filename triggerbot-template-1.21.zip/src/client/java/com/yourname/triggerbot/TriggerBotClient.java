package com.yourname.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TriggerBotClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static long lastAttackTime = 0;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.of("TriggerBot " + (enabled ? "Enabled" : "Disabled")), false);
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) return;
            if (client.crosshairTarget.getType() != net.minecraft.util.hit.HitResult.Type.ENTITY) return;

            Entity target = ((net.minecraft.util.hit.EntityHitResult) client.crosshairTarget).getEntity();

            // Basic checks
            if (!(target instanceof PlayerEntity playerTarget)) return;
            if (!playerTarget.isAlive() || target == client.player) return;
            if (!client.player.canSee(target)) return; // No hitting through walls

            // Must hold a sword
            if (!client.player.getMainHandStack().isOf(Items.WOODEN_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.STONE_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.IRON_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.GOLDEN_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.DIAMOND_SWORD) &&
                !client.player.getMainHandStack().isOf(Items.NETHERITE_SWORD)) return;

            // No attacking while eating with offhand
            if (client.player.isUsingItem() &&
                client.player.getActiveHand() == Hand.OFF_HAND &&
                client.player.getOffHandStack().isFood()) return;

            // 96% hit accuracy
            if (Math.random() > 0.96) return;

            // Miss chance at long but "human" range
            double distSq = client.player.squaredDistanceTo(target);
            if (distSq > 9.0 && distSq < 10.9 && Math.random() < 0.5) return;

            // FOV check — only swing if crosshair is roughly on them
            double angle = getAngleToTarget(target);
            if (angle > 25) return;

            // Cooldown timer
            long now = System.currentTimeMillis();
            boolean onGround = client.player.isOnGround();
            long delay = onGround
                    ? 600 + (long) (Math.random() * 25)     // 600–625ms
                    : 625 + (long) (Math.random() * 15);    // 625–640ms for crits

            if (now - lastAttackTime < delay) return;

            if (client.interactionManager != null &&
                client.player.getAttackCooldownProgress(0.0f) >= 0.99f) {
                client.interactionManager.attackEntity(client.player, target);
                client.player.swingHand(Hand.MAIN_HAND);
                lastAttackTime = now;
            }
        });
    }

    private static double getAngleToTarget(Entity entity) {
        double dx = entity.getX() - client.player.getX();
        double dz = entity.getZ() - client.player.getZ();
        float yawToTarget = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
        float deltaYaw = Math.abs(wrapAngle(yawToTarget - client.player.getYaw()));
        return deltaYaw;
    }

    private static float wrapAngle(float angle) {
        angle %= 360.0f;
        if (angle >= 180.0f) angle -= 360.0f;
        if (angle < -180.0f) angle += 360.0f;
        return angle;
    }
}
