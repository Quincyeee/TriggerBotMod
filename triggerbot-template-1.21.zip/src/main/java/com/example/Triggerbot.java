package your.package;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

public class TriggerBotMod implements ModInitializer {
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static final Random random = Random.create();
    private static KeyBinding toggleKey;

    @Override
    public void onInitialize() {
        // Register toggle key (V)
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.triggerbot.toggle",
            GLFW.GLFW_KEY_V,
            "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle on key press
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
            }

            if (enabled && shouldAttack(client)) {
                performAttack(client);
            }
        });
    }

    private boolean shouldAttack(MinecraftClient client) {
        // Check cooldown (500-650ms)
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastAttackTime < (500 + random.nextInt(150))) return false;

        // Don't attack if eating
        if (client.player != null && client.player.isUsingItem()) return false;

        // Only attack players
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return false;
        Entity target = hit.getEntity();
        if (!(target instanceof PlayerEntity)) return false;

        // Distance check (3.1-3.3 blocks logic)
        double distance = client.player.getPos().distanceTo(target.getPos()); // Fixed method
        return distance <= 3.3 && !isObstructed(client, target);
    }

    private boolean isObstructed(MinecraftClient client, Entity target) {
        // Use RaycastContext for wall checks (critical fix)
        Vec3d start = client.player.getCameraPosVec(1.0f);
        Vec3d end = target.getPos().add(0, target.getHeight() / 2, 0); // Aim at center

        RaycastContext context = new RaycastContext(
            start,
            end,
            RaycastContext.ShapeType.COLLIDER,
            RaycastContext.FluidHandling.NONE,
            client.player
        );

        return client.world.raycast(context).getType() == HitResult.Type.BLOCK; // Fixed raycast
    }

    private void performAttack(MinecraftClient client) {
        // 96% accuracy check
        if (random.nextFloat() < 0.96) {
            // Sword swing animation + attack
            if (client.interactionManager != null && client.player != null) {
                Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();
                client.interactionManager.attackEntity(client.player, target); // Fixed method
                client.player.swingHand(Hand.MAIN_HAND); // Explicit hand
            }
            lastAttackTime = System.currentTimeMillis();
        }
    }
}