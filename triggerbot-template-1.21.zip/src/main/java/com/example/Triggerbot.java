package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBot implements ClientModInitializer {
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static long lastAttackTime = 0;
    private static final Random random = new Random();

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                client.player.sendMessage(
                    net.minecraft.text.Text.literal("TriggerBot " + (enabled ? "enabled" : "disabled")),
                    true
                );
            }

            if (!enabled || client.crosshairTarget == null || client.player == null || client.interactionManager == null)
                return;

            if (client.crosshairTarget.getType() != HitResult.Type.ENTITY)
                return;

            if (!(client.crosshairTarget instanceof EntityHitResult hitResult))
                return;

            if (!(hitResult.getEntity() instanceof PlayerEntity target))
                return;

            // No wall hits
            if (!client.world.raycast(new net.minecraft.util.math.RayTraceContext(
                    client.player.getCameraPosVec(1.0F),
                    target.getPos(),
                    net.minecraft.util.math.RayTraceContext.ShapeType.COLLIDER,
                    net.minecraft.util.math.RayTraceContext.FluidHandling.NONE,
                    client.player)).getType().equals(HitResult.Type.MISS)) {
                return;
            }

            double distance = client.player.squaredDistanceTo(target);
            if (distance > 9.0D) // 3 blocks squared
                return;

            long now = System.currentTimeMillis();
            int delay = 500 + random.nextInt(151); // 500-650ms
            if (now - lastAttackTime < delay)
                return;

            // 96% hit chance
            if (random.nextDouble() > 0.96) {
                double fakeDist = 9.61 + (random.nextDouble() * 0.64); // 3.1 to 3.3 blocks
                if (client.player.squaredDistanceTo(target) < fakeDist) {
                    client.player.swingHand(client.player.getActiveHand()); // Bluff attack animation
                }
                lastAttackTime = now;
                return;
            }

            // Attack
            client.interactionManager.attackEntity(client.player, target);
            client.player.swingHand(client.player.getActiveHand());
            lastAttackTime = now;
        });
    }
}
