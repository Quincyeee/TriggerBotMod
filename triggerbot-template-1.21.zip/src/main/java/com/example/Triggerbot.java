package your.package;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.random.Random;
import org.lwjgl.glfw.GLFW;

public class TriggerBotMod implements ModInitializer {
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static final Random random = Random.create();
    private static KeyBinding toggleKey;

    @Override
    public void onInitialize() {
        // Register toggle key (V)
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.triggerbot.toggle",
            GLFW.GLFW_KEY_V,
            "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle on key press
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
            }

            if (enabled && shouldAttack(client)) {
                performAttack(client);
            }
        });
    }

    private boolean shouldAttack(MinecraftClient client) {
        // Check cooldown (500-650ms)
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastAttackTime < (500 + random.nextInt(150))) return false;

        // Don't attack if eating
        if (client.player != null && client.player.isUsingItem()) return false;

        // Only attack players
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return false;
        if (!(hit.getEntity() instanceof PlayerEntity)) return false;

        // Distance check (3.1-3.3 blocks logic)
        double distance = client.player.distanceTo(hit.getEntity());
        return distance <= 3.3 && !isObstructed(client);
    }

    private boolean isObstructed(MinecraftClient client) {
        // Prevent wallhacking
        return client.world.raycast(
            client.player.getCameraPosVec(1.0f),
            client.player.getCameraPosVec(1.0f).add(client.player.getRotationVec(1.0f).multiply(3.3)),
            client.player.getBlockPos(),
            client.player.getBoundingBox(),
            entity -> true
        ) != null;
    }

    private void performAttack(MinecraftClient client) {
        // 96% accuracy check
        if (random.nextFloat() < 0.96) {
            // Sword swing animation
            if (client.interactionManager != null && client.player != null) {
                client.interactionManager.attackEntity(client.player, ((EntityHitResult) client.crosshairTarget).getEntity());
                client.player.swingHand(client.player.getActiveHand());
            }
            lastAttackTime = System.currentTimeMillis();
        }
    }
}