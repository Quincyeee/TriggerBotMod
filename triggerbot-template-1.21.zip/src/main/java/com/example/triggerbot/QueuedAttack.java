
package com.example.triggerbot;

import net.minecraft.entity.Entity;

public class QueuedAttack {
    public final Entity target;
    public final long scheduledTime;

    public QueuedAttack(Entity target, long scheduledTime) {
        this.target = target;
        this.scheduledTime = scheduledTime;
    }
}
