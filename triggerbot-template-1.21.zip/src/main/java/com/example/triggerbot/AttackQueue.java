package com.example.triggerbot;

import net.minecraft.client.MinecraftClient; import net.minecraft.client.network.ClientPlayerEntity; import net.minecraft.client.network.ClientPlayerInteractionManager; import net.minecraft.entity.Entity; import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket; import net.minecraft.util.Hand;

import java.util.LinkedList; import java.util.Queue;

public class AttackQueue { private static final Queue<QueuedAttack> attackQueue = new LinkedList<>(); private static final MinecraftClient mc = MinecraftClient.getInstance();

private static int tickCounter = 0;

public static void queueAttack(Entity target) {
    attackQueue.offer(new QueuedAttack(target));
}

public static void tick() {
    tickCounter++;
    if (!attackQueue.isEmpty() && tickCounter >= 3) { // every 3 ticks (~150ms)
        QueuedAttack queued = attackQueue.poll();
        if (queued != null && queued.getTarget().isAlive()) {
            sendAttackPacket(queued.getTarget());
        }
        tickCounter = 0;
    }
}

private static void sendAttackPacket(Entity target) {
    ClientPlayerEntity player = mc.player;
    ClientPlayerInteractionManager manager = mc.interactionManager;
    if (player != null && manager != null) {
        PlayerInteractEntityC2SPacket packet = PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
        player.networkHandler.sendPacket(packet);
        player.swingHand(Hand.MAIN_HAND);
    }
}

}

