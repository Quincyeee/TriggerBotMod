package net.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.Random;

public class TriggerBotMod implements ClientModInitializer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static KeyBinding toggleKey;
    private static boolean active = false;
    private static long lastAttack = 0;
    private static final Random random = new Random();

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleKey.wasPressed()) {
                active = !active;
            }

            if (active && mc.player != null && mc.world != null) {
                handleTriggerBot();
            }
        });
    }

    private static void handleTriggerBot() {
        if (!canAttack()) return;

        Entity target = findTarget();
        if (target != null && isValidTarget(target) && random.nextFloat() <= 0.96f) {
            if (isInAttackRange(target) && hasLineOfSight(target)) {
                attack(target);
            }
        }
    }

    private static boolean canAttack() {
        ItemStack mainHand = mc.player.getMainHandStack();
        ItemStack offHand = mc.player.getOffHandStack();

        // Check cooldown
        long timeSinceLast = System.currentTimeMillis() - lastAttack;
        if (timeSinceLast < (500 + random.nextInt(150))) return false;

        // Check sword
        if (!(mainHand.getItem() instanceof SwordItem)) return false;

        // Check eating
        if (mc.player.isUsingItem() && offHand.getItem().isFood()) return false;

        return true;
    }

    private static Entity findTarget() {
        return mc.world.getPlayers().stream()
                .filter(entity -> entity != mc.player)
                .filter(entity -> mc.player.squaredDistanceTo(entity) < 16) // 4 blocks squared
                .min(Comparator.comparingDouble(entity -> mc.player.squaredDistanceTo(entity)))
                .orElse(null);
    }

    private static boolean isValidTarget(Entity entity) {
        return entity instanceof PlayerEntity && entity.isAlive();
    }

    private static boolean isInAttackRange(Entity target) {
        double distance = mc.player.getEyePos().distanceTo(target.getPos());
        return distance >= 3.1 && distance <= 3.3 ? random.nextFloat() > 0.04 : distance <= 3.0;
    }

    private static boolean hasLineOfSight(Entity target) {
        Vec3d start = mc.player.getEyePos();
        Vec3d end = target.getBoundingBox().getCenter();
        RaycastContext context = new RaycastContext(start, end, 
                RaycastContext.ShapeType.COLLIDER, 
                RaycastContext.FluidHandling.NONE, 
                mc.player);
        return mc.world.raycast(context).getType() == HitResult.Type.MISS;
    }

    private static void attack(Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttack = System.currentTimeMillis();
    }
}