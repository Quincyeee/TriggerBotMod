package com.example.triggerbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;

public class TriggerBotLogic {
    private static final TargetTracker tracker = new TargetTracker();
    private static final AttackManager attackManager = new AttackManager();

    public static void tick(MinecraftClient client) {
        if (client.crosshairTarget == null || !(client.crosshairTarget.getEntity() instanceof PlayerEntity)) return;
        ClientPlayerEntity player = client.player;
        PlayerEntity target = (PlayerEntity) client.crosshairTarget.getEntity();

        if (!player.getMainHandStack().getItem().getClass().equals(SwordItem.class)) return;
        if (!tracker.shouldAttack(player, target)) return;

        attackManager.tryAttack(player, target);
    }
}