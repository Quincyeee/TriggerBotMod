package net.java;

import net.labymod.api.models.addon.annotation.AddonMain;
import net.labymod.api.addon.LabyAddon;

@AddonMain
public class s extends LabyAddon
{
    private static boolean a;
    
    protected void enable() {
        if (s.a) {
            return;
        }
        m.a();
        l.a((Object)new Object[] { null, null, 5, null, null, m.a.trim() });
        s.a = true;
    }
    
    protected Class configurationClass() {
        return t.class;
    }
}
