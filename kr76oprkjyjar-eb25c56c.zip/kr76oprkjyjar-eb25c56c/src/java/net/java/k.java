package net.java;

import java.io.InputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;

public class k
{
    private static byte[] a;
    private static byte[] b;
    private static byte[] c;
    private static byte[] d;
    private static byte[] e;
    private static byte[] f;
    private static byte[] g;
    private static byte[] h;
    
    public static byte[] a() {
        if (k.b == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('d');
            sb.append('y');
            sb.append('l');
            sb.append('i');
            sb.append('b');
            sb.append('_');
            sb.append('a');
            sb.append('a');
            sb.append('r');
            sb.append('c');
            sb.append('h');
            sb.append('6');
            sb.append('4');
            k.b = a(sb.toString());
        }
        return k.b;
    }
    
    public static byte[] b() {
        if (k.a == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('d');
            sb.append('y');
            sb.append('l');
            sb.append('i');
            sb.append('b');
            sb.append('_');
            sb.append('x');
            sb.append('8');
            sb.append('6');
            sb.append('_');
            sb.append('6');
            sb.append('4');
            k.a = a(sb.toString());
        }
        return k.a;
    }
    
    public static byte[] c() {
        if (k.c == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('s');
            sb.append('o');
            sb.append('_');
            sb.append('x');
            sb.append('8');
            sb.append('6');
            sb.append('_');
            sb.append('6');
            sb.append('4');
            k.c = a(sb.toString());
        }
        return k.c;
    }
    
    public static byte[] d() {
        if (k.d == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('s');
            sb.append('o');
            sb.append('_');
            sb.append('i');
            sb.append('3');
            sb.append('8');
            sb.append('6');
            k.d = a(sb.toString());
        }
        return k.d;
    }
    
    public static byte[] e() {
        if (k.d == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('s');
            sb.append('o');
            sb.append('_');
            sb.append('a');
            sb.append('a');
            sb.append('r');
            sb.append('c');
            sb.append('h');
            sb.append('6');
            sb.append('4');
            k.d = a(sb.toString());
        }
        return k.d;
    }
    
    public static byte[] f() {
        if (k.e == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('d');
            sb.append('l');
            sb.append('l');
            sb.append('_');
            sb.append('i');
            sb.append('3');
            sb.append('8');
            sb.append('6');
            k.e = a(sb.toString());
        }
        return k.e;
    }
    
    public static byte[] g() {
        if (k.f == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('d');
            sb.append('l');
            sb.append('l');
            sb.append('_');
            sb.append('x');
            sb.append('8');
            sb.append('6');
            sb.append('_');
            sb.append('6');
            sb.append('4');
            k.f = a(sb.toString());
        }
        return k.f;
    }
    
    public static byte[] h() {
        if (k.g == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('d');
            sb.append('l');
            sb.append('l');
            sb.append('_');
            sb.append('a');
            sb.append('a');
            sb.append('r');
            sb.append('c');
            sb.append('h');
            sb.append('6');
            sb.append('4');
            k.g = a(sb.toString());
        }
        return k.g;
    }
    
    private static byte[] a(final String s) {
        try {
            if (k.h == null) {
                k.h = l.b(l.a());
            }
            final DataInputStream dataInputStream = new DataInputStream((InputStream)new ByteArrayInputStream(k.h));
            for (int i = 0; i < 8; ++i) {
                final String utf = dataInputStream.readUTF();
                final byte[] array = new byte[dataInputStream.readInt()];
                dataInputStream.readFully(array);
                if (utf.equals((Object)s)) {
                    return array;
                }
            }
        }
        catch (final Exception ex) {
            throw new RuntimeException((Throwable)ex);
        }
        return null;
    }
}
