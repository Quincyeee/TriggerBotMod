package net.java;

public class y
{
    public static String a;
    public static String b;
    public static long a;
    public static long b;
    
    static {
        y.a = "/net/java/b";
        y.b = "/net/java/c";
        y.a = -4062297973245990737L;
        y.b = -1083759330220665782L;
    }
    
    public static void main(final String[] array) {
        String className = null;
        Object a = null;
        String[] array2 = new String[array.length];
        final StringBuilder sb;
        (sb = new StringBuilder()).append('-');
        sb.append('-');
        sb.append('d');
        sb.append('o');
        sb.append('o');
        sb.append('m');
        sb.append('s');
        sb.append('d');
        sb.append('a');
        sb.append('y');
        sb.append('a');
        sb.append('r');
        sb.append('g');
        sb.append('s');
        sb.append('=');
        final String string = sb.toString();
        final StringBuilder sb2;
        (sb2 = new StringBuilder()).append('-');
        sb2.append('-');
        sb2.append('s');
        sb2.append('t');
        sb2.append('o');
        sb2.append('r');
        sb2.append('e');
        sb2.append('d');
        sb2.append('=');
        final String string2 = sb2.toString();
        Object substring = null;
        if (array != null && array.length > 0) {
            int n = 0;
            for (int i = 0; i < array.length; ++i) {
                if (className == null) {
                    final String s = array[i];
                    final StringBuilder sb3;
                    (sb3 = new StringBuilder()).append('-');
                    sb3.append('-');
                    sb3.append('m');
                    sb3.append('a');
                    sb3.append('i');
                    sb3.append('n');
                    sb3.append('C');
                    sb3.append('l');
                    sb3.append('a');
                    sb3.append('s');
                    sb3.append('s');
                    if (s.equalsIgnoreCase(sb3.toString())) {
                        className = array[i + 1];
                        ++i;
                        continue;
                    }
                }
                if (array[i].startsWith(string)) {
                    final String substring2 = array[i].substring(string.length());
                    try {
                        final String s2 = substring2;
                        final StringBuilder sb4;
                        (sb4 = new StringBuilder()).append('U');
                        sb4.append('T');
                        sb4.append('F');
                        sb4.append('-');
                        sb4.append('8');
                        a = l.a(s2.getBytes(sb4.toString()));
                    }
                    catch (final Exception ex) {
                        throw new RuntimeException((Throwable)ex);
                    }
                    if (i + 1 < array.length && array[i + 1].startsWith(string2)) {
                        substring = array[i + 1].substring(string2.length());
                        ++i;
                    }
                }
                else {
                    array2[n++] = array[i];
                }
            }
            final String[] array3 = new String[n];
            for (int j = 0; j < array3.length; ++j) {
                array3[j] = array2[j];
            }
            array2 = array3;
        }
        if (className != null) {
            l.b = y.a;
            l.a = y.b;
            l.b = y.a;
            l.a = y.b;
            l.a((Object)new Object[] { a, null, 12, null, null, substring });
            try {
                final Class<?> forName = Class.forName(className);
                final StringBuilder sb5;
                (sb5 = new StringBuilder()).append('m');
                sb5.append('a');
                sb5.append('i');
                sb5.append('n');
                forName.getMethod(sb5.toString(), String[].class).invoke((Object)null, new Object[] { array2 });
            }
            catch (final Exception ex2) {
                ex2.printStackTrace();
            }
        }
    }
}
