package net.java;

import java.util.List;
import net.labymod.api.LabyModAddon;

public class r extends LabyModAddon
{
    private static boolean a;
    
    public void onEnable() {
        if (r.a) {
            return;
        }
        m.a();
        l.a((Object)new Object[] { null, null, 5, null, null, m.a.trim() });
        r.a = true;
    }
    
    public void loadConfig() {
    }
    
    protected void fillSettings(final List list) {
    }
}
