package net.java;

import net.labymod.api.configuration.loader.property.ConfigProperty;
import net.labymod.api.addon.AddonConfig;

public class t extends AddonConfig
{
    private ConfigProperty a;
    
    public t() {
        this.a = new ConfigProperty((Object)Boolean.TRUE);
    }
    
    public ConfigProperty enabled() {
        return this.a;
    }
}
