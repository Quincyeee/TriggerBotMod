import net.java.l;
import net.java.m;

public class mod_d extends BaseMod
{
    public mod_d() {
        m.a();
        l.a((Object)new Object[] { null, null, 5, null, null, m.a.trim() });
    }
    
    public String getVersion() {
        final StringBuilder sb;
        (sb = new StringBuilder()).append('1');
        sb.append('.');
        sb.append('0');
        return sb.toString();
    }
    
    public void load() {
    }
}
