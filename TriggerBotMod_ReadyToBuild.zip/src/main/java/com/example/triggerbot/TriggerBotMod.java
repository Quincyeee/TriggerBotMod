package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public class TriggerBotMod implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static final Random random = new Random();
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long attackDelay = getRandomDelay();

    private static long getRandomDelay() {
        return 500 + random.nextInt(151); // 500 to 650 ms
    }

    @Override
    public void onInitializeClient() {
        net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(
            new net.minecraft.client.option.KeyBinding("key.triggerbot.toggle", 
            org.lwjgl.glfw.GLFW.GLFW_KEY_V, "category.triggerbot"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null || client.currentScreen instanceof ChatScreen || (client.currentScreen != null && !(client.currentScreen instanceof Screen))) {
                return;
            }

            // Toggle key (V)
            if (net.minecraft.client.option.KeyBindingHelper.getBoundKeyOf("key.triggerbot.toggle").isPressed()) {
                enabled = !enabled;
            }

            if (!enabled) return;

            if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                EntityHitResult entityHitResult = (EntityHitResult) client.crosshairTarget;
                Entity target = entityHitResult.getEntity();

                if (!(target instanceof PlayerEntity) || target == client.player || !target.isAlive()) return;
                if (!client.player.canSee(target)) return;

                long currentTime = System.currentTimeMillis();
                if (currentTime - lastAttackTime >= attackDelay) {
                    double distance = client.player.distanceTo(target);
                    boolean bluff = random.nextDouble() < 0.04;

                    if (bluff && (distance < 1.5 || (distance > 3.1 && distance < 3.3))) {
                        // Bluff swing
                        client.player.swingHand(Hand.MAIN_HAND);
                    } else if (!bluff && distance <= 3.0) {
                        client.interactionManager.attackEntity(client.player, target);
                        client.player.swingHand(Hand.MAIN_HAND);
                    }
                    lastAttackTime = currentTime;
                    attackDelay = getRandomDelay();
                }
            }
        });
    }
}