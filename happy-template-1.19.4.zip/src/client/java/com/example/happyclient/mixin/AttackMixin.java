package com.example.happyclient.mixin;

import com.example.happyclient.HappyClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class AttackMixin {
    // This will be run every time Minecraft handles attack input (i.e., left click)
    @Inject(method = "handleAttack", at = @At("HEAD"))
    private void onHandleAttack(CallbackInfo ci) {
        HappyClient.tryTriggerbotAttack((MinecraftClient)(Object)this);
    }
}