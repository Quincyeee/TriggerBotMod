package com.example.happyclient.mixin;

import com.example.happyclient.HappyClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class PerFrameAttackMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(boolean tick, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        HappyClient.tryTriggerbotAttack(client);
    }
}