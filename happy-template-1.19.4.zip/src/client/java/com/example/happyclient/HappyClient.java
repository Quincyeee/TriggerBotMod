package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating tracking (food only, either hand)
    private boolean wasEatingFood = false;
    private long finishedEatTime = 0L;
    private boolean postEatDelayActive = false;
    private long nextAllowedPostEatAttack = 0L;

    // Track target transitions for "first see" logic
    private Entity lastTarget = null;
    private long reactionReadyTime = 0L; // For humanized reaction delay

    // Track if the enemy has recently hit the player
    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200; // How long we "remember" the enemy's hit

    // Attack timers for ground and air delays, and post-eat/use delay
    private long nextAllowedGroundAttack = 0L;
    private long nextAllowedAirAttack = 0L;

    // Cooldown threshold (0.86 = 86%)
    private static final float COOLDOWN_THRESHOLD = 0.86f;

    // For tracking "special" ground delay after being hit
    private boolean specialGroundDelayActive = false;
    private long specialGroundDelayUntil = 0L;

    private static final Random random = new Random();

    // --- New drift fields and constants ---
    private double curGroundDelay = 580.0;
    private double curAirDelay = 420.0;
    private static final double SMOOTH = 0.25;

    // --- Humanlike reaction time constants ---
    private static final int JITTER_PCT = 10;

    // --- Aim jitter fields and constants ---
    private long nextTremorTime = 0L;
    private static final int TREMOR_MIN_MS = 40;
    private static final int TREMOR_MAX_MS = 120;
    private static final double BACKGROUND_AMPLITUDE_DEG = 0.08;
    private static final double SHOT_AMPLITUDE_DEG = 0.15;

    // --- Aim smoothing fields ---
    private static final float AIM_SMOOTH_FACTOR = 0.2f;
    private float goalYaw = 0f;
    private float goalPitch = 0f;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            // --- AIM JITTER WITH SMOOTHING ---
            // 1) At very top: initialize goals on first run
            if (nextTremorTime == 0) {
                goalYaw   = client.player.getYaw();
                goalPitch = client.player.getPitch();
            }

            // 2) Background tremor (updates goalYaw/goalPitch at random intervals)
            long now = System.currentTimeMillis();
            if (now >= nextTremorTime) {
                double yawKick   = (random.nextDouble() * 2 - 1) * BACKGROUND_AMPLITUDE_DEG;
                double pitchKick = (random.nextDouble() * 2 - 1) * BACKGROUND_AMPLITUDE_DEG;
                goalYaw   = client.player.getYaw()   + (float) yawKick;
                goalPitch = client.player.getPitch() + (float) pitchKick;
                nextTremorTime = now + (TREMOR_MIN_MS + random.nextInt(TREMOR_MAX_MS - TREMOR_MIN_MS + 1));
            }

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                // Reset tracking if mod is off
                wasEatingFood = false;
                postEatDelayActive = false;
                finishedEatTime = 0L;
                lastTarget = null;
                enemyRecentlyHitMe = false;
                lastEnemyAttackTime = 0L;
                nextAllowedGroundAttack = 0L;
                nextAllowedAirAttack = 0L;
                nextAllowedPostEatAttack = 0L;
                reactionReadyTime = 0L;
                specialGroundDelayActive = false;
                specialGroundDelayUntil = 0L;
                // Also reset aim jitter state
                nextTremorTime = 0L;
                return;
            }

            ClientPlayerEntity player = client.player;

            // Track if the enemy hit me: detect recent damage taken
            if (player.hurtTime > 0) {
                // Enemy has hit me
                if (!enemyRecentlyHitMe) {
                    // Just got hit: activate special ground delay
                    specialGroundDelayActive = true;
                    specialGroundDelayUntil = System.currentTimeMillis() + 700L;
                }
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = System.currentTimeMillis();
            } else {
                // Check if special delay should be reset (700ms after last enemy hit)
                if (specialGroundDelayActive && System.currentTimeMillis() > specialGroundDelayUntil) {
                    specialGroundDelayActive = false;
                }
                // Reset enemyRecentlyHitMe if memory time has passed
                if (enemyRecentlyHitMe && System.currentTimeMillis() - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            ItemStack main = player.getMainHandStack();
            ItemStack off = player.getOffHandStack();

            // Detect if currently eating food with either hand
            boolean isEatingMain = main.isFood() && player.isUsingItem() && player.getActiveHand() == net.minecraft.util.Hand.MAIN_HAND;
            boolean isEatingOff = off.isFood() && player.isUsingItem() && player.getActiveHand() == net.minecraft.util.Hand.OFF_HAND;
            boolean isCurrentlyEatingFood = isEatingMain || isEatingOff;

            if (isCurrentlyEatingFood) {
                wasEatingFood = true;
                postEatDelayActive = false;
                return;
            }

            // If just finished eating (from either hand), start the post-eat delay
            if (wasEatingFood) {
                wasEatingFood = false;
                postEatDelayActive = true;
                finishedEatTime = System.currentTimeMillis();
                nextAllowedPostEatAttack = finishedEatTime + getPostEatDelayMs(player);
                return; // Wait at least one tick before starting delay
            }

            // If in post-eat delay, skip until timer expires
            if (postEatDelayActive) {
                long now2 = System.currentTimeMillis();
                if (now2 < nextAllowedPostEatAttack) {
                    return;
                } else {
                    postEatDelayActive = false; // Done waiting
                }
            }

            // Don't attack if not holding a sword
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                    main.getItem() == Items.STONE_SWORD ||
                    main.getItem() == Items.IRON_SWORD ||
                    main.getItem() == Items.GOLDEN_SWORD ||
                    main.getItem() == Items.DIAMOND_SWORD ||
                    main.getItem() == Items.NETHERITE_SWORD)) {
                lastTarget = null; // Reset target tracking on incorrect weapon
                reactionReadyTime = 0L;
                return;
            }

            // --- No FOV intersection: use Minecraft's targetedEntity (pixel-perfect raycast) ---
            Entity target = client.targetedEntity;

            float cooldown = player.getAttackCooldownProgress(0.0f);
            long now3 = System.currentTimeMillis();

            // Target transition tracking for "first see" logic
            boolean newTarget = (target != null && target != player && target != lastTarget);
            if (newTarget) {
                if (cooldown >= 1.0f) {
                    reactionReadyTime = now3 + getReactionDelayMs(player);
                } else {
                    reactionReadyTime = 0L; // Wait for cooldown to reach 1.0 to start the timer
                }
            }
            lastTarget = target;

            // --- ATTACK DELAY LOGIC (NEW BLOCK) ---
            boolean firedThisTick = false;
            if (target != null && target != player) {
                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                if (cooldown >= 1.0f && reactionReadyTime > 0L) {
                    if (now3 < reactionReadyTime) {
                        // Smooth the actual view toward the goal before returning
                        float curYaw   = client.player.getYaw();
                        float curPitch = client.player.getPitch();
                        float newYaw   = curYaw   + (goalYaw   - curYaw)   * AIM_SMOOTH_FACTOR;
                        float newPitch = curPitch + (goalPitch - curPitch) * AIM_SMOOTH_FACTOR;
                        client.player.setYaw(newYaw);
                        client.player.setPitch(newPitch);
                        return;
                    }
                    reactionReadyTime = 0L;
                }

                if (cooldown < COOLDOWN_THRESHOLD) {
                    // Smooth the actual view toward the goal before returning
                    float curYaw   = client.player.getYaw();
                    float curPitch = client.player.getPitch();
                    float newYaw   = curYaw   + (goalYaw   - curYaw)   * AIM_SMOOTH_FACTOR;
                    float newPitch = curPitch + (goalPitch - curPitch) * AIM_SMOOTH_FACTOR;
                    client.player.setYaw(newYaw);
                    client.player.setPitch(newPitch);
                    return;
                }

                boolean enemyIsEatingOffhand = false;
                if (target instanceof PlayerEntity) {
                    PlayerEntity targetPlayer = (PlayerEntity) target;
                    ItemStack enemyOffhand = targetPlayer.getOffHandStack();
                    if (enemyOffhand != null && enemyOffhand.isFood() && targetPlayer.isUsingItem()) {
                        enemyIsEatingOffhand = true;
                    }
                }

                // -------- AIR ATTACKS --------
                if (isFalling) {
                    if (now3 >= nextAllowedAirAttack) {
                        long airDelay;
                        int roll = random.nextInt(100); // 0-99

                        if (enemyIsEatingOffhand) {
                            airDelay = nextBetaDelay(450, 510, 2.5, 2.5);  // focused
                        } else if (roll < 20) {
                            airDelay = nextSmoothAir(360, 470);           // common
                        } else if (roll == 99) {
                            airDelay = nextBetaDelay(315, 379, 2.0, 1.2);  // rare fast
                        } else {
                            airDelay = nextBetaDelay(360, 470, 2.3, 2.3);  // default
                        }

                        // --- ADD NETWORK JITTER HERE ---
                        int userPingMs = getActualPing(player);
                        int jitter = getNetworkJitter(userPingMs);
                        airDelay = Math.max(1, airDelay + jitter);

                        nextAllowedAirAttack = now3 + airDelay;

                        // --- AIM JITTER: Shot-time burst layer (update goals) ---
                        double shotYawKick   = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        double shotPitchKick = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        goalYaw   = client.player.getYaw()   + (float) shotYawKick;
                        goalPitch = client.player.getPitch() + (float) shotPitchKick;

                        performDoAttack(client);
                        lastAttackTime = now3;
                        firedThisTick = true;
                    }
                }

                // -------- GROUND ATTACKS --------
                else if (onGround) {
                    if (now3 >= nextAllowedGroundAttack) {
                        long groundDelay;
                        int roll = random.nextInt(100); // 0-99

                        if (specialGroundDelayActive) {
                            if (roll == 0) {
                                groundDelay = nextBetaDelay(627, 650, 3.0, 3.0);  // 1%
                            } else {
                                groundDelay = nextSmoothGround(580, 630);         // 99%
                            }
                        } else {
                            groundDelay = nextBetaDelay(520, 627, 2.4, 2.4);       // default
                        }

                        // --- ADD NETWORK JITTER HERE ---
                        int userPingMs = getActualPing(player);
                        int jitter = getNetworkJitter(userPingMs);
                        groundDelay = Math.max(1, groundDelay + jitter);

                        nextAllowedGroundAttack = now3 + groundDelay;

                        // --- AIM JITTER: Shot-time burst layer (update goals) ---
                        double shotYawKick   = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        double shotPitchKick = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        goalYaw   = client.player.getYaw()   + (float) shotYawKick;
                        goalPitch = client.player.getPitch() + (float) shotPitchKick;

                        performDoAttack(client);
                        lastAttackTime = now3;
                        firedThisTick = true;
                    }
                }
            } else {
                // No target: reset reaction timer
                reactionReadyTime = 0L;
            }

            // --- SMOOTH the actual view toward the goal ---
            float curYaw   = client.player.getYaw();
            float curPitch = client.player.getPitch();
            float newYaw   = curYaw   + (goalYaw   - curYaw)   * AIM_SMOOTH_FACTOR;
            float newPitch = curPitch + (goalPitch - curPitch) * AIM_SMOOTH_FACTOR;
            client.player.setYaw(newYaw);
            client.player.setPitch(newPitch);
        });
    }

    // --- Humanlike post-eat delay using log-normal and network jitter ---
    private long getPostEatDelayMs(ClientPlayerEntity player) {
        // 1%: 81-95ms (log-normal), 99%: 65-80ms (log-normal)
        int roll = random.nextInt(100); // 0..99
        double base;
        if (roll == 0) { // 1% rare long
            double ln = sampleLogNormal(Math.log(88), 0.09); // mean 88, small spread
            base = Math.max(81, Math.min(95, ln));
        } else { // 99% normal
            double ln = sampleLogNormal(Math.log(72), 0.17); // mean 72, medium spread
            base = Math.max(65, Math.min(80, ln));
        }
        int userPingMs = getActualPing(player);
        int jitter = getNetworkJitter(userPingMs);
        return Math.max(1, Math.round(base) + jitter);
    }

    // --- Smooth drift & beta helpers ---
    private long nextSmoothGround(int min, int max) {
        double target = min + random.nextDouble() * (max - min);
        curGroundDelay += (target - curGroundDelay) * SMOOTH;
        return (long) curGroundDelay;
    }

    private long nextSmoothAir(int min, int max) {
        double target = min + random.nextDouble() * (max - min);
        curAirDelay += (target - curAirDelay) * SMOOTH;
        return (long) curAirDelay;
    }

    private double sampleBeta(double alpha, double beta) {
        double x = 0, y = 0;
        for (int i = 0; i < (int) alpha; i++) x += -Math.log(random.nextDouble());
        for (int i = 0; i < (int) beta; i++) y += -Math.log(random.nextDouble());
        return x / (x + y);
    }

    private long nextBetaDelay(int min, int max, double alpha, double beta) {
        double b = sampleBeta(alpha, beta);
        return min + Math.round(b * (max - min));
    }

    // --- Custom humanlike reaction delay using log-normal and network jitter ---
    // 40%: 5–15ms, 55%: 26–45ms, 5%: 45–50ms
    private long getReactionDelayMs(ClientPlayerEntity player) {
        int roll = random.nextInt(100); // 0..99
        double base;
        if (roll < 40) { // 40% super fast
            double ln = sampleLogNormal(Math.log(10), 0.30); // mean 10, wider spread
            base = Math.max(5, Math.min(15, ln));
        } else if (roll < 95) { // next 55% normal
            double ln = sampleLogNormal(Math.log(34), 0.18); // mean 34, reasonable spread
            base = Math.max(26, Math.min(45, ln));
        } else { // last 5% slowest
            double ln = sampleLogNormal(Math.log(47.5), 0.04); // mean ~47.5, tight spread
            base = Math.max(45, Math.min(50, ln));
        }
        int userPingMs = getActualPing(player);
        int jitter = getNetworkJitter(userPingMs);
        return Math.max(1, Math.round(base) + jitter);
    }

    private double sampleLogNormal(double mean, double stddev) {
        return Math.exp(mean + stddev * random.nextGaussian());
    }

    private int getActualPing(ClientPlayerEntity player) {
        if (player.networkHandler != null && player.networkHandler.getPlayerListEntry(player.getUuid()) != null) {
            return player.networkHandler.getPlayerListEntry(player.getUuid()).getLatency();
        }
        return 40; // fallback
    }

    private int getNetworkJitter(int pingMs) {
        int spread = Math.max(1, (int)(pingMs * JITTER_PCT / 100.0));
        return random.nextInt(2 * spread + 1) - spread; // [-spread, +spread]
    }

    /**
     * Calls MinecraftClient.doAttack() directly for the triggerbot attack.
     * This method requires an access widener on doAttack().
     */
    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }
}