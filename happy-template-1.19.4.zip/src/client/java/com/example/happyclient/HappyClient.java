package com.example.happyclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

import java.util.Random;

public class HappyClient {
    // State variables moved to static for use from mixin
    private static boolean modEnabled = true; // Always enabled for demo, toggle logic can be re-added if needed

    private static long lastGroundAttackTime = 0L;
    private static long lastAirAttackTime = 0L;
    private static long lastTargetChangeTime = 0L;
    private static long scheduledPostEatAttackTime = 0L;

    private static boolean wasEatingOffhand = false;
    private static boolean postEatDelayActive = false;

    private static int lastTargetId = -1;
    private static boolean targetPreviouslyInCrosshair = false;

    private static final Random random = new Random();
    private static final float COOLDOWN_THRESHOLD = 0.86f;

    // This method is called every render frame by the Mixin
    public static void tryTriggerbotAttack(MinecraftClient client) {
        if (!modEnabled) {
            resetAll();
            return;
        }

        if (client.player == null || client.world == null) return;
        if (client.currentScreen != null) return;

        long now = System.currentTimeMillis();

        handlePostEatDelay(client, now);
        if (postEatDelayActive || client.player.isUsingItem()) return;

        ItemStack main = client.player.getMainHandStack();
        if (!isSword(main)) {
            resetTargeting();
            return;
        }

        Entity target = client.targetedEntity;
        float cooldown = client.player.getAttackCooldownProgress(0.0f);
        boolean valid = target instanceof PlayerEntity && target != client.player;
        boolean isNew = valid && (target.getId() != lastTargetId || !targetPreviouslyInCrosshair);
        if (isNew) lastTargetChangeTime = now;

        if (valid) {
            if (client.player.isOnGround()) {
                handleGroundAttack(client, now, cooldown, isNew);
            } else if (client.player.getVelocity().y < -0.08) {
                handleAirAttack(client, now, cooldown, isNew, (PlayerEntity) target);
            }
        } else {
            resetGroundAir();
        }

        updateTargetState(valid, target);
    }

    private static int sampleTruncatedNormal(int min, int max, double mean, double stddev) {
        int value;
        do {
            value = (int) Math.round(mean + stddev * random.nextGaussian());
        } while (value < min || value > max);
        return value;
    }

    private static int sampleGroundDelay() {
        int roll = random.nextInt(1000);
        if (roll < 5) {
            return sampleTruncatedNormal(520, 589, 554.5, 15);
        } else if (roll > 994) {
            return sampleTruncatedNormal(636, 650, 643, 5);
        } else {
            return sampleTruncatedNormal(590, 635, 612.5, 10);
        }
    }

    private static int sampleAirDelay(boolean eating) {
        if (eating) {
            return sampleTruncatedNormal(361, 420, 390.5, 14);
        } else {
            return sampleTruncatedNormal(325, 360, 342.5, 10);
        }
    }

    private static int sampleReactionDelay() {
        return sampleTruncatedNormal(0, 5, 2, 1);
    }

    private static void handleGroundAttack(MinecraftClient client, long now, float cooldown, boolean isNew) {
        if (isNew) {
            int reaction = sampleReactionDelay();
            if (now - lastTargetChangeTime >= reaction && cooldown >= COOLDOWN_THRESHOLD) {
                client.doAttack();
                lastGroundAttackTime = now;
                lastTargetChangeTime = now;
            }
        } else {
            int delay = sampleGroundDelay();
            if ((lastGroundAttackTime == 0L || now - lastGroundAttackTime >= delay) && cooldown >= COOLDOWN_THRESHOLD) {
                client.doAttack();
                lastGroundAttackTime = now;
            }
        }
    }

    private static void handleAirAttack(MinecraftClient client, long now, float cooldown, boolean isNew, PlayerEntity target) {
        if (isNew) {
            int reaction = sampleReactionDelay();
            if (now - lastTargetChangeTime >= reaction && cooldown >= COOLDOWN_THRESHOLD) {
                client.doAttack();
                lastAirAttackTime = now;
                lastTargetChangeTime = now;
            }
        } else {
            boolean eating = target.isUsingItem();
            int delay = sampleAirDelay(eating);
            if ((lastAirAttackTime == 0L || now - lastAirAttackTime >= delay) && cooldown >= COOLDOWN_THRESHOLD) {
                client.doAttack();
                lastAirAttackTime = now;
            }
        }
    }

    private static void handlePostEatDelay(MinecraftClient client, long now) {
        ClientPlayerEntity player = client.player;
        boolean eatingOff = player.getOffHandStack().isFood() && player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND;
        if (eatingOff) {
            wasEatingOffhand = true;
            postEatDelayActive = false;
            return;
        }
        if (wasEatingOffhand) {
            wasEatingOffhand = false;
            postEatDelayActive = true;
            scheduledPostEatAttackTime = now + (65 + random.nextInt(6));
            return;
        }
        if (postEatDelayActive && now < scheduledPostEatAttackTime) return;
        postEatDelayActive = false;
    }

    private static boolean isSword(ItemStack stack) {
        return switch (stack.getItem().toString()) {
            case "minecraft:wooden_sword", "minecraft:stone_sword", "minecraft:iron_sword",
                 "minecraft:golden_sword", "minecraft:diamond_sword", "minecraft:netherite_sword" -> true;
            default -> false;
        };
    }

    private static void resetAll() {
        lastGroundAttackTime = lastAirAttackTime = lastTargetChangeTime = scheduledPostEatAttackTime = 0L;
        wasEatingOffhand = postEatDelayActive = false;
        lastTargetId = -1;
        targetPreviouslyInCrosshair = false;
    }

    private static void resetTargeting() {
        lastGroundAttackTime = lastAirAttackTime = 0L;
        lastTargetId = -1;
        targetPreviouslyInCrosshair = false;
    }

    private static void resetGroundAir() {
        lastGroundAttackTime = lastAirAttackTime = 0L;
    }

    private static void updateTargetState(boolean valid, Entity target) {
        if (valid) {
            lastTargetId = target.getId();
            targetPreviouslyInCrosshair = true;
        } else {
            lastTargetId = -1;
            targetPreviouslyInCrosshair = false;
        }
    }
}