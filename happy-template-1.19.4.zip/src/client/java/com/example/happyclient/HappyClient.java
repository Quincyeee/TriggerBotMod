package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final double MAX_REACH = 3.0;
    private static final double FOV_DEGREES = 100.0;

    private long lastAttackTime = 0;
    private long lastHurtTimestamp = 0;
    private boolean wasHitRecently = false;
    private long lastOffhandEatTime = 0;
    private long eatDelayMs = 0;
    private boolean wasEatingOffhand = false;

    private static final int PERLIN_SIZE = 256;
    private final double[] perlinGradients = new double[PERLIN_SIZE + 1];
    private final Random random = new Random();

    @Override
    public void onInitializeClient() {
        for (int i = 0; i < PERLIN_SIZE; i++) {
            perlinGradients[i] = random.nextDouble() * 2 - 1;
        }
        perlinGradients[PERLIN_SIZE] = perlinGradients[0];

        ClientTickEvents.END_CLIENT_TICK.register(this::tryAttack);
    }

    private void tryAttack(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) return;
        ClientPlayerEntity player = client.player;
        long now = System.currentTimeMillis();

        // Track hit status
        if (player.hurtTime > 0) {
            lastHurtTimestamp = now;
            wasHitRecently = true;
        } else if (wasHitRecently && now - lastHurtTimestamp > 700) {
            wasHitRecently = false;
        }

        // Screen or use-item check
        if (client.currentScreen != null || player.isUsingItem()) return;

        // Eating delay check
        boolean eatingOffhand = player.isUsingItem()
                && player.getActiveHand() == Hand.OFF_HAND
                && player.getOffHandStack().isFood();
        if (wasEatingOffhand && !eatingOffhand) {
            lastOffhandEatTime = now;
            eatDelayMs = 65 + random.nextInt(16);
        }
        wasEatingOffhand = eatingOffhand;
        if (lastOffhandEatTime > 0 && now - lastOffhandEatTime < eatDelayMs) return;

        // Must be holding a sword
        ItemStack held = player.getMainHandStack();
        if (!(held.getItem() instanceof SwordItem)) return;

        // Use client.crosshairTarget for entity selection
        if (!(client.crosshairTarget instanceof EntityHitResult entityHit)) return;
        Entity target = entityHit.getEntity();

        // Only attack visible players
        if (!(target instanceof PlayerEntity)) return;
        if (!player.canSee(target)) return;
        if (!isWithinFov(player.getRotationVec(1.0F), player.getCameraPosVec(1.0F), target.getCameraPosVec(1.0F))) return;

        // Calculate attack delay
        long chosenDelay;
        if (player.isOnGround()) {
            double baseMin = wasHitRecently ? 580 : 520;
            double baseMax = wasHitRecently ? 630 : 627;
            double baseMid = (baseMin + baseMax) / 2;
            double sigma = 0.25;
            double mu = Math.log(baseMid) - 0.5 * sigma * sigma;
            double sample = Math.exp(mu + sigma * random.nextGaussian());
            double clamped = Math.max(baseMin, Math.min(baseMax, sample));
            double drift = perlinNoise(now / 1000.0) * 20;
            chosenDelay = (long) Math.max(0, clamped + drift);
        } else {
            // Check if the target is eating with the off hand
            boolean targetEating = false;
            if (target instanceof LivingEntity livingTarget) {
                targetEating = livingTarget.isUsingItem()
                        && livingTarget.getActiveHand() == Hand.OFF_HAND
                        && livingTarget.getOffHandStack().isFood();
            }
            if (targetEating) {
                chosenDelay = 370 + random.nextInt(181);
            } else {
                int chance = random.nextInt(100);
                if (chance < 5) {
                    chosenDelay = 315 + random.nextInt(26);
                } else if (chance < 20) {
                    chosenDelay = 461 + random.nextInt(90);
                } else {
                    chosenDelay = 370 + random.nextInt(91);
                }
                double mean = chosenDelay;
                double sigmaJ = 0.1;
                double muJ = Math.log(mean) - 0.5 * sigmaJ * sigmaJ;
                double jitter = Math.exp(muJ + sigmaJ * random.nextGaussian()) - mean;
                chosenDelay = chosenDelay + (long) Math.max(-10, Math.min(10, jitter));
            }
        }

        if (now - lastAttackTime < chosenDelay) return;
        lastAttackTime = now;

        // 🟢 Call doAttack() directly (target already selected by crosshair)
        client.doAttack();
    }

    private double perlinNoise(double x) {
        int xi = ((int) Math.floor(x)) & 255;
        double xf = x - Math.floor(x);
        double u = fade(xf);
        double g1 = perlinGradients[xi];
        double g2 = perlinGradients[xi + 1];
        double d1 = g1 * xf;
        double d2 = g2 * (xf - 1);
        return lerp(u, d1, d2);
    }

    private double fade(double t) {
        return t * t * t * (t * (t * 6 - 15) + 10);
    }

    private double lerp(double t, double a, double b) {
        return a + t * (b - a);
    }

    private boolean isWithinFov(Vec3d lookVec, Vec3d origin, Vec3d targetPos) {
        Vec3d toTarget = targetPos.subtract(origin).normalize();
        double dot = lookVec.normalize().dotProduct(toTarget);
        double halfFovRad = Math.toRadians(FOV_DEGREES / 2.0);
        return Math.acos(dot) <= halfFovRad;
    }
}