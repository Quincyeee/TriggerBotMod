package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    // --- State ---
    private long lastAttackTime = 0L, finishedEatTime = 0L, lastEnemyAttackTime = 0L;
    private long nextAllowedGroundAttack = 0L, nextAllowedAirAttack = 0L, nextAllowedPostEatAttack = 0L;
    private boolean modEnabled = false, prevAltPressed = false;
    private boolean wasEatingFood = false, postEatDelayActive = false;
    private boolean enemyRecentlyHitMe = false, specialGroundDelayActive = false;
    private long specialGroundDelayUntil = 0L, reactionReadyTime = 0L;
    private boolean aiming = false, overshootActive = false;
    private boolean attackIntentGround = false, attackIntentAir = false;
    private Entity lastTarget = null;
    private static final Random random = new Random();

    // --- Constants ---
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200;
    private static final float COOLDOWN_THRESHOLD = 0.86f;
    private static final double SMOOTH = 0.25;
    private static final int JITTER_PCT = 10;
    private static final int TREMOR_MIN_MS = 40, TREMOR_MAX_MS = 120;
    private static final double BACKGROUND_AMPLITUDE_DEG = 0.08, SHOT_AMPLITUDE_DEG = 0.15;
    private static final double MISS_PROBABILITY = 0.10, MIN_DIST_MISS = 3.1, MAX_DIST_MISS = 3.5, GLANCE_OFFSET_BLOCKS = 0.25;

    // --- Drift/aim fields ---
    private double curGroundDelay = 580.0, curAirDelay = 420.0;
    private long nextTremorTime = 0L;
    private float goalYaw = 0f, goalPitch = 0f;
    private float startYaw = 0f, startPitch = 0f, endYaw = 0f, endPitch = 0f;
    private long aimStartTime = 0L, aimEndTime = 0L;
    private float overshootYaw = 0f, overshootPitch = 0f;
    private long overshootStartTime = 0L, overshootEndTime = 0L;
    private EasingType currentEasing = EasingType.SINE, overshootEasing = EasingType.QUAD;
    private double currentEasingParam = 3.0, overshootParam = 2.0;

    private enum EasingType { SINE, QUAD, EXPO, CUBIC, CIRC }

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null || client.currentScreen != null) return;

            // --- Aim jitter ---
            if (nextTremorTime == 0) {
                goalYaw = client.player.getYaw();
                goalPitch = client.player.getPitch();
            }
            long now = System.currentTimeMillis();
            if (now >= nextTremorTime) {
                goalYaw = client.player.getYaw() + (float)((random.nextDouble() * 2 - 1) * BACKGROUND_AMPLITUDE_DEG);
                goalPitch = client.player.getPitch() + (float)((random.nextDouble() * 2 - 1) * BACKGROUND_AMPLITUDE_DEG);
                nextTremorTime = now + (TREMOR_MIN_MS + random.nextInt(TREMOR_MAX_MS - TREMOR_MIN_MS + 1));
            }

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
            if (altPressed && !prevAltPressed) modEnabled = !modEnabled;
            prevAltPressed = altPressed;

            if (!modEnabled) {
                wasEatingFood = false; postEatDelayActive = false; finishedEatTime = 0L; lastTarget = null;
                enemyRecentlyHitMe = false; lastEnemyAttackTime = 0L; nextAllowedGroundAttack = 0L; nextAllowedAirAttack = 0L;
                nextAllowedPostEatAttack = 0L; reactionReadyTime = 0L; specialGroundDelayActive = false; specialGroundDelayUntil = 0L;
                aiming = false; overshootActive = false; nextTremorTime = 0L; attackIntentGround = false; attackIntentAir = false;
                return;
            }

            ClientPlayerEntity player = client.player;
            if (player.hurtTime > 0) {
                if (!enemyRecentlyHitMe) { specialGroundDelayActive = true; specialGroundDelayUntil = now + 700L; }
                enemyRecentlyHitMe = true; lastEnemyAttackTime = now;
            } else {
                if (specialGroundDelayActive && now > specialGroundDelayUntil) specialGroundDelayActive = false;
                if (enemyRecentlyHitMe && now - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) enemyRecentlyHitMe = false;
            }

            ItemStack main = player.getMainHandStack(), off = player.getOffHandStack();
            boolean isEatingMain = main.isFood() && player.isUsingItem() && player.getActiveHand() == net.minecraft.util.Hand.MAIN_HAND;
            boolean isEatingOff = off.isFood() && player.isUsingItem() && player.getActiveHand() == net.minecraft.util.Hand.OFF_HAND;
            if (isEatingMain || isEatingOff) { wasEatingFood = true; postEatDelayActive = false; return; }
            if (wasEatingFood) { wasEatingFood = false; postEatDelayActive = true; finishedEatTime = now; nextAllowedPostEatAttack = finishedEatTime + getPostEatDelayMs(player); return; }
            if (postEatDelayActive) { if (now < nextAllowedPostEatAttack) return; else postEatDelayActive = false; }
            if (!(main.getItem() == Items.WOODEN_SWORD || main.getItem() == Items.STONE_SWORD || main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD || main.getItem() == Items.DIAMOND_SWORD || main.getItem() == Items.NETHERITE_SWORD)) {
                lastTarget = null; reactionReadyTime = 0L; aiming = false; overshootActive = false; attackIntentGround = false; attackIntentAir = false; return;
            }

            Entity target = client.targetedEntity;
            float cooldown = player.getAttackCooldownProgress(0.0f);
            long now3 = now;

            // --- Miss logic ---
            if (target instanceof PlayerEntity && enemyRecentlyHitMe && ((PlayerEntity)target).isSprinting()) {
                double dist = player.getPos().distanceTo(target.getPos());
                if (dist >= MIN_DIST_MISS && dist <= MAX_DIST_MISS && random.nextDouble() < MISS_PROBABILITY) {
                    performDoAttack(client); lastAttackTime = now3; return;
                }
            }
            if (lastTarget instanceof PlayerEntity && client.targetedEntity == null) {
                PlayerEntity t = (PlayerEntity) lastTarget;
                Vec3d eyePos = player.getCameraPosVec(1f), toCenter = t.getPos().add(0, t.getEyeHeight(t.getPose())*0.5, 0).subtract(eyePos);
                double dist = toCenter.length(), angleThresh = Math.toDegrees(Math.atan(GLANCE_OFFSET_BLOCKS / dist));
                Vec2f aimAngles = getYawPitch(toCenter);
                float yawDiff = Math.abs(MathHelper.wrapDegrees(player.getYaw() - aimAngles.x));
                float pitchDiff = Math.abs(MathHelper.wrapDegrees(player.getPitch() - aimAngles.y));
                if (yawDiff <= angleThresh && pitchDiff <= angleThresh && random.nextDouble() < MISS_PROBABILITY) {
                    performDoAttack(client); lastAttackTime = now3; return;
                }
            }

            // --- Target and attack logic ---
            boolean newTarget = (target != null && target != player && target != lastTarget);
            if (newTarget) reactionReadyTime = (cooldown >= 1.0f) ? now3 + getReactionDelayMs() : 0L;
            lastTarget = target;

            if (target != null && target != player) {
                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;
                boolean enemyIsEatingOffhand = (target instanceof PlayerEntity) && ((PlayerEntity)target).getOffHandStack() != null
                        && ((PlayerEntity)target).getOffHandStack().isFood() && ((PlayerEntity)target).isUsingItem();
                boolean intentSet = false;
                if (isFalling) {
                    if (!attackIntentAir && now3 >= nextAllowedAirAttack && !intentSet) {
                        long airDelay; int roll = random.nextInt(100);
                        if (enemyIsEatingOffhand) {
                            airDelay =
                                roll < 20 ? nextSmoothAir(360, 520)
                                : roll == 99 ? nextBetaDelay(360, 400, 2.0, 1.2)
                                : nextBetaDelay(360, 520, 2.5, 2.5);
                        } else if (roll < 20) {
                            airDelay = nextSmoothAir(315, 460);
                        } else if (roll == 99) {
                            airDelay = nextBetaDelay(315, 379, 2.0, 1.2);
                        } else {
                            airDelay = nextBetaDelay(315, 460, 2.3, 2.3);
                        }
                        airDelay = Math.max(1, airDelay); nextAllowedAirAttack = now3 + airDelay;
                        selectRandomEasing();
                        float newGoalYaw = player.getYaw() + (float)((random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG);
                        float newGoalPitch = player.getPitch() + (float)((random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG);
                        if (random.nextInt(5) == 0) setAimWithOvershoot(player.getYaw(), player.getPitch(), newGoalYaw, newGoalPitch,
                                (float)(random.nextGaussian() * 0.07), (float)(random.nextGaussian() * 0.07));
                        else setBiomechanicalAim(player.getYaw(), player.getPitch(), newGoalYaw, newGoalPitch);
                        attackIntentAir = false; reactionReadyTime = (cooldown >= 1.0f) ? now3 + getReactionDelayMs() : 0L; intentSet = true;
                    }
                    if (!attackIntentAir && reactionReadyTime > 0L && now3 >= reactionReadyTime) { attackIntentAir = true; reactionReadyTime = 0L; }
                    if (attackIntentAir && cooldown >= 1.0f) { performDoAttack(client); lastAttackTime = now3; attackIntentAir = false; }
                } else if (onGround) {
                    if (!attackIntentGround && now3 >= nextAllowedGroundAttack && !intentSet) {
                        long groundDelay; int roll = random.nextInt(100);
                        groundDelay = specialGroundDelayActive ? (roll == 0 ? nextBetaDelay(627, 650, 3.0, 3.0) : nextSmoothGround(580, 630))
                                : nextBetaDelay(520, 627, 2.4, 2.4);
                        groundDelay = Math.max(1, groundDelay); nextAllowedGroundAttack = now3 + groundDelay;
                        selectRandomEasing();
                        float newGoalYaw = player.getYaw() + (float)((random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG);
                        float newGoalPitch = player.getPitch() + (float)((random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG);
                        if (random.nextInt(5) == 0) setAimWithOvershoot(player.getYaw(), player.getPitch(), newGoalYaw, newGoalPitch,
                                (float)(random.nextGaussian() * 0.07), (float)(random.nextGaussian() * 0.07));
                        else setBiomechanicalAim(player.getYaw(), player.getPitch(), newGoalYaw, newGoalPitch);
                        attackIntentGround = false; reactionReadyTime = (cooldown >= 1.0f) ? now3 + getReactionDelayMs() : 0L; intentSet = true;
                    }
                    if (!attackIntentGround && reactionReadyTime > 0L && now3 >= reactionReadyTime) { attackIntentGround = true; reactionReadyTime = 0L; }
                    if (attackIntentGround && cooldown >= 1.0f) { performDoAttack(client); lastAttackTime = now3; attackIntentGround = false; }
                }
            } else { reactionReadyTime = 0L; attackIntentGround = false; attackIntentAir = false; }

            // --- Biomechanical aim ---
            if (overshootActive) doOvershootAim(player, goalYaw, goalPitch);
            else doBiomechanicalAim(player, goalYaw, goalPitch);
        });
    }

    // --- Helpers ---
    private Vec2f getYawPitch(Vec3d vec) {
        double x = vec.x, y = vec.y, z = vec.z, dist = Math.sqrt(x * x + z * z);
        float yaw = (float)(Math.toDegrees(Math.atan2(-x, z)));
        float pitch = (float)(Math.toDegrees(-Math.atan2(y, dist)));
        return new Vec2f(yaw, pitch);
    }
    private void selectRandomEasing() {
        EasingType[] es = EasingType.values();
        currentEasing = es[random.nextInt(es.length)];
        if (currentEasing == EasingType.EXPO || currentEasing == EasingType.CUBIC) currentEasingParam = 2.2 + random.nextDouble() * 1.6;
        if (currentEasing == EasingType.QUAD) currentEasingParam = 1.6 + random.nextDouble() * 0.8;
    }
    private float applyEasing(float t) {
        switch (currentEasing) {
            case SINE:  return -(float)(Math.cos(Math.PI * t) - 1) / 2f;
            case QUAD:  return t < 0.5 ? (float)(Math.pow(2, currentEasingParam) * t * t) : 1 - (float)(Math.pow(-2 * t + 2, currentEasingParam)) / 2f;
            case EXPO:  return t < 0.5 ? (float)(Math.pow(2, currentEasingParam * t) - 1) / (float)(Math.pow(2, currentEasingParam) - 1) / 2f :
                                        1 - (float)(Math.pow(2, -currentEasingParam * (t - 1))) / (float)(Math.pow(2, currentEasingParam) - 1) / 2f;
            case CUBIC: return t < 0.5 ? (float)(4 * Math.pow(t, currentEasingParam)) : 1 - (float)(Math.pow(-2 * t + 2, currentEasingParam)) / 2f;
            case CIRC:  return t < 0.5 ? (1f - (float)Math.sqrt(1 - 4 * t * t)) / 2f : ((float)Math.sqrt(1 - Math.pow(-2 * t + 2, 2)) + 1f) / 2f;
            default:    return t;
        }
    }
    private void setBiomechanicalAim(float fromYaw, float fromPitch, float toYaw, float toPitch) {
        this.startYaw = fromYaw; this.startPitch = fromPitch; this.endYaw = toYaw; this.endPitch = toPitch;
        long now = System.currentTimeMillis(), duration = 50 + random.nextInt(70);
        this.aimStartTime = now; this.aimEndTime = now + duration; this.aiming = true; this.overshootActive = false;
    }
    private void setAimWithOvershoot(float fromYaw, float fromPitch, float toYaw, float toPitch, float overshootYawDelta, float overshootPitchDelta) {
        setBiomechanicalAim(fromYaw, fromPitch, toYaw + overshootYawDelta, toPitch + overshootPitchDelta);
        this.overshootYaw = toYaw; this.overshootPitch = toPitch; this.overshootActive = true; this.overshootStartTime = aimEndTime;
        long overshootDuration = 15 + random.nextInt(25); this.overshootEndTime = overshootStartTime + overshootDuration;
        EasingType[] es = EasingType.values();
        this.overshootEasing = es[random.nextInt(es.length)];
        this.overshootParam = (overshootEasing == EasingType.EXPO || overshootEasing == EasingType.CUBIC) ? 2.2 + random.nextDouble() * 1.6
                               : (overshootEasing == EasingType.QUAD ? 1.6 + random.nextDouble() * 0.8 : overshootParam);
    }
    private void doBiomechanicalAim(ClientPlayerEntity player, float fallbackYaw, float fallbackPitch) {
        long now = System.currentTimeMillis();
        if (aiming) {
            float t = Math.max(0f, Math.min(1f, (float)(now - aimStartTime) / (float)(aimEndTime - aimStartTime)));
            float ease = applyEasing(t);
            float newYaw = lerp(startYaw, endYaw, ease) + filteredNoise(now, 0.04f) + (float)(random.nextGaussian() * 0.04f);
            float newPitch = lerp(startPitch, endPitch, ease) + filteredNoise(now + 777, 0.04f) + (float)(random.nextGaussian() * 0.04f);
            player.setYaw(newYaw); player.setPitch(newPitch); if (t >= 1f) aiming = false;
        } else { player.setYaw(fallbackYaw); player.setPitch(fallbackPitch); }
    }
    private void doOvershootAim(ClientPlayerEntity player, float fallbackYaw, float fallbackPitch) {
        long now = System.currentTimeMillis();
        if (aiming) doBiomechanicalAim(player, fallbackYaw, fallbackPitch);
        else if (overshootActive) {
            float t = Math.max(0f, Math.min(1f, (float)(now - overshootStartTime) / (float)(overshootEndTime - overshootStartTime)));
            float ease = applyOvershootEasing(t);
            float newYaw = lerp(endYaw, overshootYaw, ease) + filteredNoise(now, 0.025f) + (float)(random.nextGaussian() * 0.02f);
            float newPitch = lerp(endPitch, overshootPitch, ease) + filteredNoise(now + 317, 0.025f) + (float)(random.nextGaussian() * 0.02f);
            player.setYaw(newYaw); player.setPitch(newPitch); if (t >= 1f) overshootActive = false;
        } else { player.setYaw(fallbackYaw); player.setPitch(fallbackPitch); }
    }
    private float applyOvershootEasing(float t) {
        switch (overshootEasing) {
            case SINE:  return -(float)(Math.cos(Math.PI * t) - 1) / 2f;
            case QUAD:  return t < 0.5 ? (float)(Math.pow(2, overshootParam) * t * t) : 1 - (float)(Math.pow(-2 * t + 2, overshootParam)) / 2f;
            case EXPO:  return t < 0.5 ? (float)(Math.pow(2, overshootParam * t) - 1) / (float)(Math.pow(2, overshootParam) - 1) / 2f :
                                        1 - (float)(Math.pow(2, -overshootParam * (t - 1))) / (float)(Math.pow(2, overshootParam) - 1) / 2f;
            case CUBIC: return t < 0.5 ? (float)(4 * Math.pow(t, overshootParam)) : 1 - (float)(Math.pow(-2 * t + 2, overshootParam)) / 2f;
            case CIRC:  return t < 0.5 ? (1f - (float)Math.sqrt(1 - 4 * t * t)) / 2f : ((float)Math.sqrt(1 - Math.pow(-2 * t + 2, 2)) + 1f) / 2f;
            default:    return t;
        }
    }
    private float filteredNoise(long t, float amplitude) {
        double freq = 0.004, n = Math.sin((t % 100000) * freq + Math.cos(t * freq * 0.6));
        return (float)(amplitude * n);
    }
    private float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private long getPostEatDelayMs(ClientPlayerEntity player) {
        int roll = random.nextInt(100);
        double ln = (roll == 0) ? sampleLogNormal(Math.log(88), 0.09) : sampleLogNormal(Math.log(72), 0.17);
        double base = (roll == 0) ? Math.max(81, Math.min(95, ln)) : Math.max(65, Math.min(80, ln));
        return Math.max(1, Math.round(base));
    }
    private long nextSmoothGround(int min, int max) {
        double target = min + random.nextDouble() * (max - min);
        curGroundDelay += (target - curGroundDelay) * SMOOTH;
        return (long) curGroundDelay;
    }
    private long nextSmoothAir(int min, int max) {
        double target = min + random.nextDouble() * (max - min);
        curAirDelay += (target - curAirDelay) * SMOOTH;
        return (long) curAirDelay;
    }
    private double sampleBeta(double alpha, double beta) {
        double x = 0, y = 0; for (int i = 0; i < (int) alpha; i++) x += -Math.log(random.nextDouble());
        for (int i = 0; i < (int) beta; i++) y += -Math.log(random.nextDouble());
        return x / (x + y);
    }
    private long nextBetaDelay(int min, int max, double alpha, double beta) {
        return min + Math.round(sampleBeta(alpha, beta) * (max - min));
    }
    private long getReactionDelayMs() {
        return (random.nextInt(10) == 0) ? 6 + random.nextInt(5) : random.nextInt(6);
    }
    private double sampleLogNormal(double mean, double stddev) { return Math.exp(mean + stddev * random.nextGaussian()); }
    private int getActualPing(ClientPlayerEntity player) {
        if (player.networkHandler != null && player.networkHandler.getPlayerListEntry(player.getUuid()) != null)
            return player.networkHandler.getPlayerListEntry(player.getUuid()).getLatency();
        return 40;
    }
    private int getNetworkJitter(int pingMs) {
        int spread = Math.max(1, (int)(pingMs * JITTER_PCT / 100.0));
        return random.nextInt(2 * spread + 1) - spread;
    }
    private void performDoAttack(MinecraftClient client) { client.doAttack(); }
}