package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;
    private static final Random random = new Random();

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating/use tracking
    private boolean wasEatingOrUsing = false;
    private long finishedEatOrUseTime = 0L;
    private boolean postEatDelayActive = false;

    // Track target transitions for "first see" logic
    private Entity lastTarget = null;
    private boolean justSawTarget = false;

    // Track if the enemy has recently hit the player
    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200; // How long we "remember" the enemy's hit

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                // Reset tracking if mod is off
                wasEatingOrUsing = false;
                postEatDelayActive = false;
                finishedEatOrUseTime = 0L;
                lastTarget = null;
                justSawTarget = false;
                enemyRecentlyHitMe = false;
                lastEnemyAttackTime = 0L;
                return;
            }

            ClientPlayerEntity player = client.player;

            // Track if the enemy hit me: detect recent damage taken
            if (player.hurtTime > 0) {
                // We just took damage
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = System.currentTimeMillis();
            } else {
                // If enough time has passed since last hit, reset the state
                if (enemyRecentlyHitMe && System.currentTimeMillis() - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            // Don't do anything while eating or using an item in either hand (self!)
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }

            // If just finished eating/using, start the delay (self!)
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = System.currentTimeMillis();
                return; // Wait at least one tick before starting delay
            }

            // If in post-eat/use delay, wait 70-80ms (log-normal) before attacking (self!)
            if (postEatDelayActive) {
                long now = System.currentTimeMillis();
                long wait = microDrift(nextLogNormalDelay(70, 80), 70, 80);
                if (now - finishedEatOrUseTime < wait) {
                    return;
                } else {
                    postEatDelayActive = false; // Done waiting
                }
            }

            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                    main.getItem() == Items.STONE_SWORD ||
                    main.getItem() == Items.IRON_SWORD ||
                    main.getItem() == Items.GOLDEN_SWORD ||
                    main.getItem() == Items.DIAMOND_SWORD ||
                    main.getItem() == Items.NETHERITE_SWORD)) {
                lastTarget = null; // Reset target tracking on incorrect weapon
                justSawTarget = false;
                return;
            }

            Entity target = client.targetedEntity;

            // --- Track "first see" for crosshair ---
            if (target != null && target != player) {
                // If previously there was no valid target, or a different target, this is a "first see"
                if (lastTarget == null || lastTarget != target) {
                    justSawTarget = true;
                }
            } else {
                // No target: reset "first see" logic
                justSawTarget = false;
            }
            lastTarget = target;

            if (target != null && target != player) {
                if (target instanceof PlayerEntity &&
                        player.getScoreboardTeam() != null &&
                        player.getScoreboardTeam().equals(((PlayerEntity) target).getScoreboardTeam())) {
                    justSawTarget = false;
                    return;
                }

                long now = System.currentTimeMillis();
                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                // --- Cooldown check: Only allow attack if cooldown is >= 70% ---
                if (!canAttackBasedOnCooldown(player, 0.70)) {
                    return;
                }

                if (isFalling) {
                    long jumpDelay = getJumpDelay(target);
                    if (now - lastAttackTime >= jumpDelay) {
                        performDoAttack(client);
                        lastAttackTime = now;
                    }
                } else if (onGround) {
                    // --- New Ground Delay Logic ---

                    // 0.5% chance for early attack (450-550ms log-normal)
                    boolean earlyAttack = random.nextInt(200) == 0;

                    // 0.5% chance for slow attack (640-660ms log-normal)
                    boolean extraSlowAttack = random.nextInt(200) == 1;

                    long groundDelay;
                    if (earlyAttack) {
                        groundDelay = microDrift(nextLogNormalDelay(450, 550), 450, 550);
                    } else if (extraSlowAttack) {
                        groundDelay = microDrift(nextLogNormalDelay(640, 660), 640, 660);
                    } else if (enemyRecentlyHitMe) {
                        // If enemy has recently hit me, use 600-627ms log-normal
                        groundDelay = microDrift(nextLogNormalDelay(600, 627), 600, 627);
                    } else {
                        // Otherwise, use 580-627ms log-normal
                        groundDelay = microDrift(nextLogNormalDelay(580, 627), 580, 627);
                    }

                    if (now - lastAttackTime >= groundDelay) {
                        performDoAttack(client);
                        lastAttackTime = now;
                    }
                }
            }
        });
    }

    /**
     * Adds a small random micro-drift to a given delay.
     * The result is clamped between min and max.
     */
    private long microDrift(long delay, int min, int max) {
        double stddev = 2.5; // Adjust for realism
        double drift = random.nextGaussian() * stddev; // normal dist, mean 0
        long drifted = Math.round(delay + drift);
        return Math.max(min, Math.min(max, drifted));
    }

    /**
     * Calls MinecraftClient.doAttack() directly for the triggerbot attack.
     * This method requires an access widener on doAttack().
     */
    private void performDoAttack(MinecraftClient client) {
        // Do not send packets, do not swing, rely only on doAttack
        client.doAttack();
    }

    /**
     * Returns a log-normal delay between min and max (inclusive).
     * This produces a bell curve in log-space, i.e. human-like delays.
     */
    private long nextLogNormalDelay(int min, int max) {
        double logMin = Math.log(Math.max(min, 1));
        double logMax = Math.log(max);
        double mu = (logMin + logMax) / 2.0;
        double sigma = (logMax - logMin) / 6.0; // 99.7% of values in [min, max]

        // Box-Muller transform for standard normal
        double u1 = random.nextDouble();
        double u2 = random.nextDouble();
        double standardNormal = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);

        double sample = Math.exp(mu + sigma * standardNormal);
        long result = Math.round(sample);
        return Math.max(min, Math.min(max, result));
    }

    /**
     * Gets the log-normal jump (crit/falling) delay based on enemy state and random chance.
     * Now with micro-drift. Eating logic only applies to the enemy!
     */
    private long getJumpDelay(Entity target) {
        // Only consider enemy's eating state!
        boolean targetIsEating = false;
        if (target instanceof PlayerEntity) {
            PlayerEntity targetPlayer = (PlayerEntity) target;
            targetIsEating = targetPlayer.isUsingItem();
        }

        if (targetIsEating) {
            int roll = random.nextInt(100);
            if (roll < 70) {
                // 70%: 370-420ms log-normal
                return microDrift(nextLogNormalDelay(370, 420), 370, 420);
            } else {
                // 30%: 421-480ms log-normal
                return microDrift(nextLogNormalDelay(421, 480), 421, 480);
            }
        } else {
            int roll = random.nextInt(100);
            if (roll < 3) {
                // 3%: 309-319ms log-normal
                return microDrift(nextLogNormalDelay(309, 319), 309, 319);
            } else if (roll < 4) {
                // Next 1%: 421-460ms log-normal
                return microDrift(nextLogNormalDelay(421, 460), 421, 460);
            } else {
                // 96%: 320-360ms log-normal
                return microDrift(nextLogNormalDelay(320, 360), 320, 360);
            }
        }
    }

    /**
     * Checks if attack cooldown is at least the given percent [0.0, 1.0].
     * Returns true if the attack cooldown progress is >= percent.
     * For swords, 1.0 is fully "charged", 0.0 is just after swinging.
     */
    private boolean canAttackBasedOnCooldown(ClientPlayerEntity player, double minPercent) {
        // getAttackCooldownProgress returns [0.0, 1.0]
        float cooldown = player.getAttackCooldownProgress(0.0f);
        return cooldown >= minPercent && cooldown <= 1.0f;
    }
}