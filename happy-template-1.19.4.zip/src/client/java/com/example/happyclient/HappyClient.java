package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating/use tracking
    private boolean wasEatingOrUsing = false;
    private boolean postEatDelayActive = false;
    private long postEatDelayStartTime = 0L;
    private long postEatDelayDuration = 0L;

    // Reaction time logic
    private boolean reactionActive = false;
    private long reactionStartTime = 0L;
    private long reactionDelay = 0L;
    private Entity reactionTarget = null;

    // Target tracking
    private Entity lastTarget = null;

    // Ground attack delay tracking
    private int groundAttackCount = 0;

    // Enemy hit tracking
    private boolean enemyRecentlyHitMe = false;
    private long enemyHitMeTimer = 0L;
    private static final long ENEMY_HIT_ME_RESET_MS = 700; // ms

    // Combat minute scaling
    private long combatStartTime = 0L;
    private int minuteDelayIncrease = 0;

    // Drift logic
    private double drift = 0.0;
    private static final double DRIFT_STD = 3.0; // ms for drift step

    // Miss logic
    private static final double MISS_CHANCE = 0.02;
    private static final Random random = new Random();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
                resetAllState();
                return;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                resetAllState();
                return;
            }

            ClientPlayerEntity player = client.player;

            // Don't do anything while eating or using an item in either hand
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }

            // If just finished eating/using, start random post-eat delay
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                postEatDelayStartTime = System.currentTimeMillis();
                postEatDelayDuration = 65 + random.nextInt(11); // 65-75ms
                return;
            }

            // If in post-eat delay, block attacks until delay passed
            if (postEatDelayActive) {
                if (System.currentTimeMillis() - postEatDelayStartTime < postEatDelayDuration) {
                    return;
                } else {
                    postEatDelayActive = false;
                }
            }

            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                    main.getItem() == Items.STONE_SWORD ||
                    main.getItem() == Items.IRON_SWORD ||
                    main.getItem() == Items.GOLDEN_SWORD ||
                    main.getItem() == Items.DIAMOND_SWORD ||
                    main.getItem() == Items.NETHERITE_SWORD)) {
                lastTarget = null;
                groundAttackCount = 0;
                return;
            }

            Entity target = client.targetedEntity;

            // --- Reaction time logic ---
            if (target != null && target != player) {
                if (lastTarget == null || lastTarget != target) {
                    // New target acquired, start reaction timer
                    reactionActive = true;
                    reactionStartTime = System.currentTimeMillis();
                    reactionDelay = getReactionDelay(player, target);
                    reactionTarget = target;
                }
            }
            // If target disappears or changes, reset reaction
            if (target == null || target != reactionTarget) {
                reactionActive = false;
                reactionTarget = null;
            }
            lastTarget = target;

            // --- Combat minute scaling ---
            updateCombatMinuteScaling();

            // --- Enemy hit logic: detect if enemy recently hit me ---
            updateEnemyHitTracking(player, target);

            if (target != null && target != player) {
                if (target instanceof PlayerEntity &&
                        player.getScoreboardTeam() != null &&
                        player.getScoreboardTeam().equals(((PlayerEntity) target).getScoreboardTeam())) {
                    return;
                }

                long now = System.currentTimeMillis();
                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                float cooldown = player.getAttackCooldownProgress(0.0f);

                // Reaction delay check
                if (reactionActive) {
                    if (now - reactionStartTime < reactionDelay) {
                        return;
                    } else {
                        reactionActive = false; // Reaction time elapsed, allow attack
                    }
                }

                // --- FALLING (jump) branch ---
                if (isFalling) {
                    long jumpDelay = getJumpDelay(player, target);
                    if (now - lastAttackTime >= jumpDelay && cooldown >= 0.86f) {
                        boolean missRoll = shouldMiss();
                        if (!missRoll) {
                            updateAim(target); // Only aim-correct 98% of the time
                        }
                        performDoAttack(client);
                        lastAttackTime = now;
                        return;
                    }
                }
                // --- GROUND branch ---
                else if (onGround) {
                    long groundDelay = getGroundDelay();
                    groundAttackCount++;
                    if (now - lastAttackTime >= groundDelay && cooldown >= 0.86f) {
                        boolean missRoll = shouldMiss();
                        if (!missRoll) {
                            updateAim(target); // Only aim-correct 98% of the time
                        }
                        performDoAttack(client);
                        lastAttackTime = now;
                        return;
                    }
                }
            }
        });
    }

    // Reaction time logic
    private long getReactionDelay(ClientPlayerEntity player, Entity target) {
        boolean isLinear = isLinearPath(player, target);
        boolean lookingAtMe = isLookingAtMe(player, target);
        if (isLinear && lookingAtMe) {
            // 30-50ms uniform
            return 30 + random.nextInt(21);
        } else {
            int roll = random.nextInt(100);
            if (roll < 50) {
                return 0 + random.nextInt(6); // 0-5ms, 50%
            } else if (roll < 70) {
                return 6 + random.nextInt(10); // 6-15ms, 20%
            } else {
                return 16 + random.nextInt(10); // 16-25ms, 30%
            }
        }
    }

    // Simulates if the target is moving in a linear path towards player
    private boolean isLinearPath(ClientPlayerEntity player, Entity target) {
        // This is a placeholder for more advanced movement analysis.
        // For now, just check if X/Z difference is small (almost head-on).
        double dx = Math.abs(player.getX() - target.getX());
        double dz = Math.abs(player.getZ() - target.getZ());
        return (dx < 0.3 || dz < 0.3); // adjust threshold for "linear"
    }

    // Simulates if the target is looking at me
    private boolean isLookingAtMe(ClientPlayerEntity player, Entity target) {
        // Estimate if target's yaw is pointed at player (within ~25deg)
        double dx = player.getX() - target.getX();
        double dz = player.getZ() - target.getZ();
        double targetYaw = target.getYaw();
        double yawToPlayer = Math.toDegrees(Math.atan2(-dx, dz));
        double diff = Math.abs(wrapDegrees(targetYaw - yawToPlayer));
        return diff < 25.0;
    }

    // Wraps yaw degrees to [-180, 180]
    private static double wrapDegrees(double degrees) {
        degrees = degrees % 360;
        if (degrees >= 180) degrees -= 360;
        if (degrees < -180) degrees += 360;
        return degrees;
    }

    private boolean shouldMiss() {
        return random.nextDouble() < MISS_CHANCE;
    }

    private void updateCombatMinuteScaling() {
        long now = System.currentTimeMillis();
        if (combatStartTime == 0) {
            combatStartTime = now;
        }
        int mins = (int) ((now - combatStartTime) / 60000L);
        minuteDelayIncrease = mins * 5 + (mins > 0 ? random.nextInt(5) - 2 : 0);
    }

    private void updateEnemyHitTracking(ClientPlayerEntity player, Entity target) {
        long now = System.currentTimeMillis();
        boolean gotHit = false;

        if (player.hurtTime > 0) {
            gotHit = true;
        }

        if (gotHit) {
            enemyRecentlyHitMe = true;
            enemyHitMeTimer = now;
        } else if (enemyRecentlyHitMe) {
            if (now - enemyHitMeTimer > ENEMY_HIT_ME_RESET_MS) {
                enemyRecentlyHitMe = false;
            }
        }
    }

    private long nextGaussianDelay(int min, int max) {
        double mean = (min + max) / 2.0;
        double std = (max - min) * 0.12;
        double val;
        do {
            val = mean + random.nextGaussian() * std;
        } while (val < min || val > max);
        return (long) val;
    }

    private long nextUniformDelay(int min, int max) {
        if (max <= min) return min;
        return min + random.nextInt(max - min + 1);
    }

    private long applyDrift(long rawDelay, int min, int max) {
        drift += random.nextGaussian() * DRIFT_STD;
        drift = Math.max(Math.min(drift, 10), -10);
        long drifted = (long) (rawDelay + drift);
        return Math.max(Math.min(drifted, max), min);
    }

    private long getGroundDelay() {
        int baseMin, baseMax;
        if (enemyRecentlyHitMe) {
            baseMin = 600 + minuteDelayIncrease;
            baseMax = 640 + minuteDelayIncrease;
        } else {
            baseMin = 520 + minuteDelayIncrease;
            baseMax = 594 + minuteDelayIncrease;
        }

        if (random.nextInt(100) < 2) {
            int range = baseMax - baseMin + 1;
            int tailSize = Math.max(1, (int) (range * 0.05));
            boolean top = random.nextBoolean();
            if (top) {
                long d = nextUniformDelay(baseMax - tailSize, baseMax);
                return applyDrift(d, baseMin, baseMax);
            } else {
                long d = nextUniformDelay(baseMin, baseMin + tailSize);
                return applyDrift(d, baseMin, baseMax);
            }
        }
        long d = nextGaussianDelay(baseMin, baseMax);
        return applyDrift(d, baseMin, baseMax);
    }

    private long getJumpDelay(ClientPlayerEntity player, Entity target) {
        boolean targetIsEating = false;
        if (target instanceof PlayerEntity) {
            PlayerEntity targetPlayer = (PlayerEntity) target;
            targetIsEating = targetPlayer.isUsingItem();
        }
        double dist = player.squaredDistanceTo(target);
        double distBlocks = Math.sqrt(dist);

        int baseMin, baseMax;
        if (targetIsEating || (distBlocks >= 2.6 && distBlocks <= 3.0)) {
            baseMin = 320 + minuteDelayIncrease;
            baseMax = 450 + minuteDelayIncrease;
        } else {
            baseMin = 460 + minuteDelayIncrease;
            baseMax = 530 + minuteDelayIncrease;
        }

        if (random.nextInt(100) < 2) {
            int range = baseMax - baseMin + 1;
            int tailSize = Math.max(1, (int) (range * 0.05));
            boolean top = random.nextBoolean();
            if (top) {
                long d = nextUniformDelay(baseMax - tailSize, baseMax);
                return applyDrift(d, baseMin, baseMax);
            } else {
                long d = nextUniformDelay(baseMin, baseMin + tailSize);
                return applyDrift(d, baseMin, baseMax);
            }
        }
        long d = nextGaussianDelay(baseMin, baseMax);
        return applyDrift(d, baseMin, baseMax);
    }

    /**
     * Only correct aim if not missing.
     */
    private void updateAim(Entity target) {
        // Implement your aim logic here, e.g. smooth look at target, snap, etc.
        // This is a stub for integration; you can fill in as needed.
    }

    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }

    private void resetAllState() {
        wasEatingOrUsing = false;
        postEatDelayActive = false;
        postEatDelayStartTime = 0L;
        postEatDelayDuration = 0L;
        reactionActive = false;
        reactionStartTime = 0L;
        reactionDelay = 0L;
        reactionTarget = null;
        lastTarget = null;
        groundAttackCount = 0;
        enemyRecentlyHitMe = false;
        enemyHitMeTimer = 0L;
        combatStartTime = 0L;
        minuteDelayIncrease = 0;
        lastAttackTime = 0L;
        drift = 0.0;
    }
}