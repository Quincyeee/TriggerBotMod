package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer; import net.minecraft.client.MinecraftClient; import net.minecraft.client.network.ClientPlayerEntity; import net.minecraft.entity.Entity; import net.minecraft.entity.player.PlayerEntity; import net.minecraft.item.ItemStack; import net.minecraft.util.Hand; import org.lwjgl.glfw.GLFW;

import java.util.Random; import java.util.concurrent.Executors; import java.util.concurrent.ScheduledExecutorService; import java.util.concurrent.TimeUnit;

public class HappyClient implements ClientModInitializer { private volatile boolean modEnabled = false; private volatile boolean prevAltPressed = false;

// Attack timing state
private long lastGroundAttackTime = 0L;
private long lastAirAttackTime = 0L;
private long lastTargetChangeTime = 0L;
private long scheduledPostEatAttackTime = 0L;
private boolean wasEatingOffhand = false;
private boolean postEatDelayActive = false;
private int lastTargetId = -1;
private boolean targetPreviouslyInCrosshair = false;

private static final Random random = new Random();
private static final float COOLDOWN_THRESHOLD = 0.86f;

// Millisecond scheduler executing both toggle & attack logic
private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

@Override
public void onInitializeClient() {
    // Start continuous scheduler loop
    scheduler.scheduleAtFixedRate(() -> {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        // Poll Left-Alt for enabling/disabling
        long window = client.getWindow().getHandle();
        boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
        if (altPressed && !prevAltPressed) {
            modEnabled = !modEnabled;
            if (!modEnabled) resetAll();
        }
        prevAltPressed = altPressed;

        // If disabled, skip attack logic
        if (!modEnabled) return;

        // Execute attack logic on the main thread
        client.execute(this::runAttackLogic);
    }, 0, 1, TimeUnit.MILLISECONDS);
}

private void runAttackLogic() {
    long now = System.currentTimeMillis();
    MinecraftClient client = MinecraftClient.getInstance();
    ClientPlayerEntity player = client.player;

    // Handle post-eat delay
    handlePostEatDelay(player, now);
    if (postEatDelayActive || player.isUsingItem()) return;

    // Ensure holding a sword
    ItemStack main = player.getMainHandStack();
    if (!isSword(main)) {
        resetTargeting();
        return;
    }

    Entity target = client.targetedEntity;
    float cooldown = player.getAttackCooldownProgress(0.0f);
    boolean valid = target instanceof PlayerEntity && target != player;
    boolean isNew = valid && (target.getId() != lastTargetId || !targetPreviouslyInCrosshair);
    if (isNew) lastTargetChangeTime = now;

    boolean ready = (lastGroundAttackTime != 0L || lastAirAttackTime != 0L)
                    ? cooldown >= COOLDOWN_THRESHOLD
                    : true;

    if (valid) {
        if (player.isOnGround()) {
            if (isNew) {
                if (now - lastTargetChangeTime >= sampleReactionDelay() && ready) {
                    client.doAttack();
                    lastGroundAttackTime = now;
                    lastTargetChangeTime = now;
                }
            } else {
                int delay = sampleGroundDelay();
                if ((lastGroundAttackTime == 0L || now - lastGroundAttackTime >= delay) && ready) {
                    client.doAttack();
                    lastGroundAttackTime = now;
                }
            }
        } else if (player.getVelocity().y < -0.08) {
            boolean eating = ((PlayerEntity) target).isUsingItem();
            if (isNew) {
                if (now - lastTargetChangeTime >= sampleReactionDelay() && ready) {
                    client.doAttack();
                    lastAirAttackTime = now;
                    lastTargetChangeTime = now;
                }
            } else {
                int delay = sampleAirDelay(eating);
                if ((lastAirAttackTime == 0L || now - lastAirAttackTime >= delay) && ready) {
                    client.doAttack();
                    lastAirAttackTime = now;
                }
            }
        }
    } else {
        resetGroundAir();
    }

    updateTargetState(valid, target);
}

// Sampling and helper methods
private int sampleTruncatedNormal(int min, int max, double mean, double stddev) {
    int v;
    do { v = (int) Math.round(mean + stddev * random.nextGaussian()); }
    while (v < min || v > max);
    return v;
}

private int sampleGroundDelay() {
    int roll = random.nextInt(1000);
    if (roll < 5)    return sampleTruncatedNormal(520, 589, 554.5, 15);
    else if (roll > 994) return sampleTruncatedNormal(636, 650, 643, 5);
    else              return sampleTruncatedNormal(590, 635, 612.5, 10);
}

private int sampleAirDelay(boolean eating) {
    return eating
        ? sampleTruncatedNormal(361, 420, 390.5, 14)
        : sampleTruncatedNormal(325, 360, 342.5, 10);
}

private int sampleReactionDelay() {
    return sampleTruncatedNormal(0, 5, 2, 1);
}

private void handlePostEatDelay(ClientPlayerEntity player, long now) {
    boolean eatingOff = player.getOffHandStack().isFood()
                        && player.isUsingItem()
                        && player.getActiveHand() == Hand.OFF_HAND;
    if (eatingOff) {
        wasEatingOffhand = true;
        postEatDelayActive = false;
        return;
    }
    if (wasEatingOffhand) {
        wasEatingOffhand = false;
        postEatDelayActive = true;
        scheduledPostEatAttackTime = now + (65 + random.nextInt(6));
        return;
    }
    if (postEatDelayActive && now < scheduledPostEatAttackTime) return;
    postEatDelayActive = false;
}

private boolean isSword(ItemStack stack) {
    return switch (stack.getItem().toString()) {
        case "minecraft:wooden_sword", "minecraft:stone_sword", "minecraft:iron_sword",
             "minecraft:golden_sword", "minecraft:diamond_sword", "minecraft:netherite_sword"
            -> true;
        default -> false;
    };
}

private void resetAll() {
    lastGroundAttackTime = lastAirAttackTime = lastTargetChangeTime = scheduledPostEatAttackTime = 0L;
    wasEatingOffhand = postEatDelayActive = false;
    lastTargetId = -1;
    targetPreviouslyInCrosshair = false;
}

private void resetTargeting() {
    lastGroundAttackTime = lastAirAttackTime = 0L;
    lastTargetId = -1;
    targetPreviouslyInCrosshair = false;
}

private void resetGroundAir() {
    lastGroundAttackTime = lastAirAttackTime = 0L;
}

private void updateTargetState(boolean valid, Entity target) {
    if (valid) {
        lastTargetId = target.getId();
        targetPreviouslyInCrosshair = true;
    } else {
        lastTargetId = -1;
        targetPreviouslyInCrosshair = false;
    }
}

}

