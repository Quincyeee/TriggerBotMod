package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating tracking (food only, either hand)
    private boolean wasEatingFood = false;
    private long finishedEatTime = 0L;
    private boolean postEatDelayActive = false;
    private long nextAllowedPostEatAttack = 0L;

    // Track target transitions for "first see" logic
    private Entity lastTarget = null;
    private long reactionReadyTime = 0L; // For humanized reaction delay

    // Track if the enemy has recently hit the player
    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200; // How long we "remember" the enemy's hit

    // Attack timers for ground and air delays, and post-eat/use delay
    private long nextAllowedGroundAttack = 0L;
    private long nextAllowedAirAttack = 0L;

    // Cooldown threshold (0.86 = 86%)
    private static final float COOLDOWN_THRESHOLD = 0.86f;

    // For tracking "special" ground delay after being hit
    private boolean specialGroundDelayActive = false;
    private long specialGroundDelayUntil = 0L;

    private static final Random random = new Random();

    // --- New drift fields and constants ---
    private double curGroundDelay = 580.0;
    private double curAirDelay = 420.0;
    private static final double SMOOTH = 0.25;

    // --- Humanlike reaction time constants ---
    private static final int JITTER_PCT = 10;

    // --- Aim jitter fields and constants ---
    private long nextTremorTime = 0L;
    private static final int TREMOR_MIN_MS = 40;
    private static final int TREMOR_MAX_MS = 120;
    private static final double BACKGROUND_AMPLITUDE_DEG = 0.08;
    private static final double SHOT_AMPLITUDE_DEG = 0.15;

    // --- Legitimate aim movement fields ---
    private boolean aiming = false;
    private float startYaw = 0f, startPitch = 0f, endYaw = 0f, endPitch = 0f;
    private long aimStartTime = 0L, aimEndTime = 0L;

    // --- Diversified biomechanical aim curve fields ---
    private EasingType currentEasing = EasingType.SINE;
    private double currentEasingParam = 3.0; // for exponent-based easings
    private boolean overshootActive = false;
    private float overshootYaw = 0f, overshootPitch = 0f;
    private long overshootStartTime = 0L, overshootEndTime = 0L;
    private EasingType overshootEasing = EasingType.QUAD;
    private double overshootParam = 2.0;

    // --- Aim smoothing fields ---
    private float goalYaw = 0f;
    private float goalPitch = 0f;

    // --- For attack intent/cooldown sync ---
    private boolean attackIntentGround = false, attackIntentAir = false;

    // --- Diversified biomechanical curve support ---
    private enum EasingType { SINE, QUAD, EXPO, CUBIC, CIRC }

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            // --- AIM JITTER WITH BIOMECHANICAL CURVE ---
            if (nextTremorTime == 0) {
                goalYaw   = client.player.getYaw();
                goalPitch = client.player.getPitch();
            }

            long now = System.currentTimeMillis();
            if (now >= nextTremorTime) {
                double yawKick   = (random.nextDouble() * 2 - 1) * BACKGROUND_AMPLITUDE_DEG;
                double pitchKick = (random.nextDouble() * 2 - 1) * BACKGROUND_AMPLITUDE_DEG;
                goalYaw   = client.player.getYaw()   + (float) yawKick;
                goalPitch = client.player.getPitch() + (float) pitchKick;
                nextTremorTime = now + (TREMOR_MIN_MS + random.nextInt(TREMOR_MAX_MS - TREMOR_MIN_MS + 1));
            }

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                wasEatingFood = false;
                postEatDelayActive = false;
                finishedEatTime = 0L;
                lastTarget = null;
                enemyRecentlyHitMe = false;
                lastEnemyAttackTime = 0L;
                nextAllowedGroundAttack = 0L;
                nextAllowedAirAttack = 0L;
                nextAllowedPostEatAttack = 0L;
                reactionReadyTime = 0L;
                specialGroundDelayActive = false;
                specialGroundDelayUntil = 0L;
                aiming = false;
                overshootActive = false;
                nextTremorTime = 0L;
                attackIntentGround = false;
                attackIntentAir = false;
                return;
            }

            ClientPlayerEntity player = client.player;

            if (player.hurtTime > 0) {
                if (!enemyRecentlyHitMe) {
                    specialGroundDelayActive = true;
                    specialGroundDelayUntil = System.currentTimeMillis() + 700L;
                }
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = System.currentTimeMillis();
            } else {
                if (specialGroundDelayActive && System.currentTimeMillis() > specialGroundDelayUntil) {
                    specialGroundDelayActive = false;
                }
                if (enemyRecentlyHitMe && System.currentTimeMillis() - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            ItemStack main = player.getMainHandStack();
            ItemStack off = player.getOffHandStack();

            boolean isEatingMain = main.isFood() && player.isUsingItem() && player.getActiveHand() == net.minecraft.util.Hand.MAIN_HAND;
            boolean isEatingOff = off.isFood() && player.isUsingItem() && player.getActiveHand() == net.minecraft.util.Hand.OFF_HAND;
            boolean isCurrentlyEatingFood = isEatingMain || isEatingOff;

            if (isCurrentlyEatingFood) {
                wasEatingFood = true;
                postEatDelayActive = false;
                return;
            }

            if (wasEatingFood) {
                wasEatingFood = false;
                postEatDelayActive = true;
                finishedEatTime = System.currentTimeMillis();
                nextAllowedPostEatAttack = finishedEatTime + getPostEatDelayMs(player);
                return;
            }

            if (postEatDelayActive) {
                long now2 = System.currentTimeMillis();
                if (now2 < nextAllowedPostEatAttack) {
                    return;
                } else {
                    postEatDelayActive = false;
                }
            }

            if (!(main.getItem() == Items.WOODEN_SWORD ||
                    main.getItem() == Items.STONE_SWORD ||
                    main.getItem() == Items.IRON_SWORD ||
                    main.getItem() == Items.GOLDEN_SWORD ||
                    main.getItem() == Items.DIAMOND_SWORD ||
                    main.getItem() == Items.NETHERITE_SWORD)) {
                lastTarget = null;
                reactionReadyTime = 0L;
                aiming = false;
                overshootActive = false;
                attackIntentGround = false;
                attackIntentAir = false;
                return;
            }

            Entity target = client.targetedEntity;

            float cooldown = player.getAttackCooldownProgress(0.0f);
            long now3 = System.currentTimeMillis();

            // Target transition tracking for "first see" logic
            boolean newTarget = (target != null && target != player && target != lastTarget);
            if (newTarget) {
                if (cooldown >= 1.0f) {
                    reactionReadyTime = now3 + getReactionDelayMs();
                } else {
                    reactionReadyTime = 0L;
                }
            }
            lastTarget = target;

            // --- ATTACK DELAY LOGIC (INTENT, THEN COOLDOWN GATE) ---
            if (target != null && target != player) {
                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                boolean enemyIsEatingOffhand = false;
                if (target instanceof PlayerEntity) {
                    PlayerEntity targetPlayer = (PlayerEntity) target;
                    ItemStack enemyOffhand = targetPlayer.getOffHandStack();
                    if (enemyOffhand != null && enemyOffhand.isFood() && targetPlayer.isUsingItem()) {
                        enemyIsEatingOffhand = true;
                    }
                }

                // Only one intent can be active per tick
                boolean intentSet = false;

                // -------- AIR ATTACKS --------
                if (isFalling) {
                    if (!attackIntentAir && now3 >= nextAllowedAirAttack && !intentSet) {
                        long airDelay;
                        int roll = random.nextInt(100);

                        if (enemyIsEatingOffhand) {
                            airDelay = nextBetaDelay(450, 510, 2.5, 2.5);
                        } else if (roll < 20) {
                            airDelay = nextSmoothAir(360, 470);
                        } else if (roll == 99) {
                            airDelay = nextBetaDelay(315, 379, 2.0, 1.2);
                        } else {
                            airDelay = nextBetaDelay(360, 470, 2.3, 2.3);
                        }

                        airDelay = Math.max(1, airDelay);

                        nextAllowedAirAttack = now3 + airDelay;

                        // Set diversified biomechanical aim for this attack
                        selectRandomEasing();
                        double shotYawKick   = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        double shotPitchKick = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        float newGoalYaw = client.player.getYaw() + (float) shotYawKick;
                        float newGoalPitch = client.player.getPitch() + (float) shotPitchKick;

                        // 1/5 of flicks use an overshoot and correction
                        if (random.nextInt(5) == 0) {
                            float overshootAmountYaw = (float)(random.nextGaussian() * 0.07);
                            float overshootAmountPitch = (float)(random.nextGaussian() * 0.07);
                            setAimWithOvershoot(client.player.getYaw(), client.player.getPitch(), newGoalYaw, newGoalPitch, overshootAmountYaw, overshootAmountPitch);
                        } else {
                            setBiomechanicalAim(client.player.getYaw(), client.player.getPitch(), newGoalYaw, newGoalPitch);
                        }

                        // Log air attack delay
                        sendPrivateMessage(client, "[HappyClient] Air attack delay: " + airDelay + "ms");

                        // Wait for reaction delay (the "human" intent timer)
                        attackIntentAir = false;
                        if (cooldown >= 1.0f) {
                            reactionReadyTime = now3 + getReactionDelayMs();
                        } else {
                            reactionReadyTime = 0L;
                        }
                        intentSet = true;
                    }
                    if (!attackIntentAir && reactionReadyTime > 0L && now3 >= reactionReadyTime) {
                        attackIntentAir = true;
                        reactionReadyTime = 0L;
                    }
                    if (attackIntentAir && cooldown >= 1.0f) {
                        performDoAttack(client);
                        lastAttackTime = now3;
                        attackIntentAir = false;
                        sendPrivateMessage(client, "[HappyClient] Air attack fired!");
                    }
                }
                // -------- GROUND ATTACKS --------
                else if (onGround) {
                    if (!attackIntentGround && now3 >= nextAllowedGroundAttack && !intentSet) {
                        long groundDelay;
                        int roll = random.nextInt(100);

                        if (specialGroundDelayActive) {
                            if (roll == 0) {
                                groundDelay = nextBetaDelay(627, 650, 3.0, 3.0);
                            } else {
                                groundDelay = nextSmoothGround(580, 630);
                            }
                        } else {
                            groundDelay = nextBetaDelay(520, 627, 2.4, 2.4);
                        }

                        groundDelay = Math.max(1, groundDelay);

                        nextAllowedGroundAttack = now3 + groundDelay;

                        // Set diversified biomechanical aim for this attack
                        selectRandomEasing();
                        double shotYawKick   = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        double shotPitchKick = (random.nextDouble() * 2 - 1) * SHOT_AMPLITUDE_DEG;
                        float newGoalYaw = client.player.getYaw() + (float) shotYawKick;
                        float newGoalPitch = client.player.getPitch() + (float) shotPitchKick;

                        // 1/5 of flicks use an overshoot and correction
                        if (random.nextInt(5) == 0) {
                            float overshootAmountYaw = (float)(random.nextGaussian() * 0.07);
                            float overshootAmountPitch = (float)(random.nextGaussian() * 0.07);
                            setAimWithOvershoot(client.player.getYaw(), client.player.getPitch(), newGoalYaw, newGoalPitch, overshootAmountYaw, overshootAmountPitch);
                        } else {
                            setBiomechanicalAim(client.player.getYaw(), client.player.getPitch(), newGoalYaw, newGoalPitch);
                        }

                        // Log ground attack delay
                        sendPrivateMessage(client, "[HappyClient] Ground attack delay: " + groundDelay + "ms");

                        // Wait for reaction delay (the "human" intent timer)
                        attackIntentGround = false;
                        if (cooldown >= 1.0f) {
                            reactionReadyTime = now3 + getReactionDelayMs();
                        } else {
                            reactionReadyTime = 0L;
                        }
                        intentSet = true;
                    }
                    if (!attackIntentGround && reactionReadyTime > 0L && now3 >= reactionReadyTime) {
                        attackIntentGround = true;
                        reactionReadyTime = 0L;
                    }
                    if (attackIntentGround && cooldown >= 1.0f) {
                        performDoAttack(client);
                        lastAttackTime = now3;
                        attackIntentGround = false;
                        sendPrivateMessage(client, "[HappyClient] Ground attack fired!");
                    }
                }
            } else {
                reactionReadyTime = 0L;
                attackIntentGround = false;
                attackIntentAir = false;
            }

            // --- BIOMECHANICAL AIM CURVE ---
            if (overshootActive) {
                doOvershootAim(player, goalYaw, goalPitch);
            } else {
                doBiomechanicalAim(player, goalYaw, goalPitch);
            }
        });
    }

    // --- Send chat message visible only to the client ---
    private void sendPrivateMessage(MinecraftClient client, String msg) {
        if (client.player != null) {
            client.player.sendMessage(new LiteralText(msg), false);
        }
    }

    // --- Diversified biomechanical aim curve with micro-jitter and velocity profile ---
    private void selectRandomEasing() {
        EasingType[] easings = EasingType.values();
        currentEasing = easings[random.nextInt(easings.length)];
        // For exponent/param-based easings
        if (currentEasing == EasingType.EXPO || currentEasing == EasingType.CUBIC) {
            currentEasingParam = 2.2 + random.nextDouble() * 1.6; // 2.2–3.8
        }
        if (currentEasing == EasingType.QUAD) {
            currentEasingParam = 1.6 + random.nextDouble() * 0.8; // 1.6–2.4
        }
    }

    private float applyEasing(float t) {
        switch (currentEasing) {
            case SINE:
                return -(float)(Math.cos(Math.PI * t) - 1) / 2f;
            case QUAD:
                return t < 0.5
                        ? (float)(Math.pow(2, currentEasingParam) * t * t)
                        : 1 - (float)(Math.pow(-2 * t + 2, currentEasingParam)) / 2f;
            case EXPO:
                return t < 0.5
                        ? (float)(Math.pow(2, currentEasingParam * t) - 1) / (float)(Math.pow(2, currentEasingParam) - 1) / 2f
                        : 1 - (float)(Math.pow(2, -currentEasingParam * (t - 1))) / (float)(Math.pow(2, currentEasingParam) - 1) / 2f;
            case CUBIC:
                return t < 0.5
                        ? (float)(4 * Math.pow(t, currentEasingParam))
                        : 1 - (float)(Math.pow(-2 * t + 2, currentEasingParam)) / 2f;
            case CIRC:
                return t < 0.5
                        ? (1f - (float)Math.sqrt(1 - 4 * t * t)) / 2f
                        : ((float)Math.sqrt(1 - Math.pow(-2 * t + 2, 2)) + 1f) / 2f;
            default:
                return t;
        }
    }

    private void setBiomechanicalAim(float fromYaw, float fromPitch, float toYaw, float toPitch) {
        this.startYaw = fromYaw;
        this.startPitch = fromPitch;
        this.endYaw = toYaw;
        this.endPitch = toPitch;
        long now = System.currentTimeMillis();
        long duration = 50 + random.nextInt(70); // 50-120ms
        this.aimStartTime = now;
        this.aimEndTime = now + duration;
        this.aiming = true;
        this.overshootActive = false;
    }

    private void setAimWithOvershoot(float fromYaw, float fromPitch, float toYaw, float toPitch, float overshootYawDelta, float overshootPitchDelta) {
        // Phase 1: Flick to (toYaw + overshoot), Phase 2: correct back to toYaw
        setBiomechanicalAim(fromYaw, fromPitch, toYaw + overshootYawDelta, toPitch + overshootPitchDelta);
        this.overshootYaw = toYaw;
        this.overshootPitch = toPitch;
        this.overshootActive = true;
        this.overshootStartTime = aimEndTime;
        long overshootDuration = 15 + random.nextInt(25); // 15-40ms correction
        this.overshootEndTime = overshootStartTime + overshootDuration;
        EasingType[] es = EasingType.values();
        this.overshootEasing = es[random.nextInt(es.length)];
        if (overshootEasing == EasingType.EXPO || overshootEasing == EasingType.CUBIC)
            this.overshootParam = 2.2 + random.nextDouble() * 1.6;
        else if (overshootEasing == EasingType.QUAD)
            this.overshootParam = 1.6 + random.nextDouble() * 0.8;
    }

    private void doBiomechanicalAim(ClientPlayerEntity player, float fallbackYaw, float fallbackPitch) {
        long now = System.currentTimeMillis();
        if (aiming) {
            float t = (float)(now - aimStartTime) / (float)(aimEndTime - aimStartTime);
            t = Math.max(0f, Math.min(1f, t));
            float ease = applyEasing(t);
            float newYaw = lerp(startYaw, endYaw, ease);
            float newPitch = lerp(startPitch, endPitch, ease);
            newYaw += filteredNoise(now, 0.04f);
            newPitch += filteredNoise(now + 777, 0.04f);
            newYaw += random.nextGaussian() * 0.04f;
            newPitch += random.nextGaussian() * 0.04f;
            player.setYaw(newYaw);
            player.setPitch(newPitch);
            if (t >= 1f) aiming = false;
        } else {
            player.setYaw(fallbackYaw);
            player.setPitch(fallbackPitch);
        }
    }

    private void doOvershootAim(ClientPlayerEntity player, float fallbackYaw, float fallbackPitch) {
        long now = System.currentTimeMillis();
        if (aiming) {
            doBiomechanicalAim(player, fallbackYaw, fallbackPitch);
        } else if (overshootActive) {
            float t = (float)(now - overshootStartTime) / (float)(overshootEndTime - overshootStartTime);
            t = Math.max(0f, Math.min(1f, t));
            float ease = applyOvershootEasing(t);
            float newYaw = lerp(endYaw, overshootYaw, ease);
            float newPitch = lerp(endPitch, overshootPitch, ease);
            newYaw += filteredNoise(now, 0.025f);
            newPitch += filteredNoise(now + 317, 0.025f);
            newYaw += random.nextGaussian() * 0.02f;
            newPitch += random.nextGaussian() * 0.02f;
            player.setYaw(newYaw);
            player.setPitch(newPitch);
            if (t >= 1f) overshootActive = false;
        } else {
            player.setYaw(fallbackYaw);
            player.setPitch(fallbackPitch);
        }
    }

    private float applyOvershootEasing(float t) {
        switch (overshootEasing) {
            case SINE:
                return -(float)(Math.cos(Math.PI * t) - 1) / 2f;
            case QUAD:
                return t < 0.5
                        ? (float)(Math.pow(2, overshootParam) * t * t)
                        : 1 - (float)(Math.pow(-2 * t + 2, overshootParam)) / 2f;
            case EXPO:
                return t < 0.5
                        ? (float)(Math.pow(2, overshootParam * t) - 1) / (float)(Math.pow(2, overshootParam) - 1) / 2f
                        : 1 - (float)(Math.pow(2, -overshootParam * (t - 1))) / (float)(Math.pow(2, overshootParam) - 1) / 2f;
            case CUBIC:
                return t < 0.5
                        ? (float)(4 * Math.pow(t, overshootParam))
                        : 1 - (float)(Math.pow(-2 * t + 2, overshootParam)) / 2f;
            case CIRC:
                return t < 0.5
                        ? (1f - (float)Math.sqrt(1 - 4 * t * t)) / 2f
                        : ((float)Math.sqrt(1 - Math.pow(-2 * t + 2, 2)) + 1f) / 2f;
            default:
                return t;
        }
    }

    // Simple filtered noise for small, smooth micro-movement
    private float filteredNoise(long t, float amplitude) {
        double freq = 0.004; // tweak for smoothness/speed
        double n = Math.sin((t % 100000) * freq + Math.cos(t * freq * 0.6));
        return (float)(amplitude * n);
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    // --- Humanlike post-eat delay using log-normal and network jitter ---
    private long getPostEatDelayMs(ClientPlayerEntity player) {
        int roll = random.nextInt(100);
        double base;
        if (roll == 0) {
            double ln = sampleLogNormal(Math.log(88), 0.09);
            base = Math.max(81, Math.min(95, ln));
        } else {
            double ln = sampleLogNormal(Math.log(72), 0.17);
            base = Math.max(65, Math.min(80, ln));
        }
        int userPingMs = getActualPing(player);
        int jitter = getNetworkJitter(userPingMs);
        return Math.max(1, Math.round(base) + jitter);
    }

    // --- Smooth drift & beta helpers ---
    private long nextSmoothGround(int min, int max) {
        double target = min + random.nextDouble() * (max - min);
        curGroundDelay += (target - curGroundDelay) * SMOOTH;
        return (long) curGroundDelay;
    }

    private long nextSmoothAir(int min, int max) {
        double target = min + random.nextDouble() * (max - min);
        curAirDelay += (target - curAirDelay) * SMOOTH;
        return (long) curAirDelay;
    }

    private double sampleBeta(double alpha, double beta) {
        double x = 0, y = 0;
        for (int i = 0; i < (int) alpha; i++) x += -Math.log(random.nextDouble());
        for (int i = 0; i < (int) beta; i++) y += -Math.log(random.nextDouble());
        return x / (x + y);
    }

    private long nextBetaDelay(int min, int max, double alpha, double beta) {
        double b = sampleBeta(alpha, beta);
        return min + Math.round(b * (max - min));
    }

    // --- Custom humanlike reaction delay: 0-15ms, no network jitter ---
    private long getReactionDelayMs() {
        return random.nextInt(16); // 0-15ms inclusive, uniform
    }

    private double sampleLogNormal(double mean, double stddev) {
        return Math.exp(mean + stddev * random.nextGaussian());
    }

    private int getActualPing(ClientPlayerEntity player) {
        if (player.networkHandler != null && player.networkHandler.getPlayerListEntry(player.getUuid()) != null) {
            return player.networkHandler.getPlayerListEntry(player.getUuid()).getLatency();
        }
        return 40;
    }

    private int getNetworkJitter(int pingMs) {
        int spread = Math.max(1, (int)(pingMs * JITTER_PCT / 100.0));
        return random.nextInt(2 * spread + 1) - spread;
    }

    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }
}