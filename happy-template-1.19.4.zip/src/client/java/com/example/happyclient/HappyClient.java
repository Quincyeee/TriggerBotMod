package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final Random random = new Random();

    private static final double FOV_DEGREES = 100.0; // Use your in-game FOV

    // --- Human RT GMM (fit these to real data for best results!) ---
    private static final double[] GMM_MEANS = {240, 320, 430};
    private static final double[] GMM_STDS = {18, 30, 45};
    private static final double[] GMM_WEIGHTS = {0.45, 0.45, 0.10};

    // --- Weibull & AR(1) state ---
    private double currentK = 1.1; // Varying shape parameter for Weibull
    private int clicksSinceKChange = 0;
    private double prevSlowAR = 500, prevFastAR = 500;
    private long sessionStartTime = System.currentTimeMillis();

    // Activation and state
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;
    private Entity lastTarget = null;
    private boolean hasAttackedThisCooldown = false;

    // For anti-cheat delays and "recently hit" logic
    private boolean wasEatingOrUsing = false;
    private boolean postEatDelayActive = false;
    private long finishedEatOrUseTime = 0L;
    private long lastAttackTime = 0L;
    private long nextAllowedGroundAttack = 0L;
    private long nextAllowedAirAttack = 0L;
    private long nextAllowedPostEatAttack = 0L;
    private long lastGroundDelay = 540; // start in the middle of ground range
    private long lastAirDelay = 400; // start in the middle of air range
    private long lastAttackDelay = 0L;

    // For anti-cheat "recently hit me" window
    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private boolean inRecentlyHitDelayWindow = false;
    private long recentlyHitWindowStart = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200;
    private static final long RECENTLY_HIT_WINDOW_MS = 700L;

    // --- Anticipation block state ---
    private boolean pendingScheduledAttack = false;
    private long scheduledAttackTime = 0L;
    private MinecraftClient scheduledAttackClient = null;
    private double predictedYaw = 0, predictedPitch = 0;
    private long lastPredictTime = System.currentTimeMillis();

    // --- For tick-based frame jitter instead of Thread.sleep ---
    private boolean pendingJitterAttack = false;
    private long jitterScheduledAttackTime = 0L;
    private MinecraftClient jitterScheduledAttackClient = null;

    @Override
    public void onInitializeClient() {
        sessionStartTime = System.currentTimeMillis();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                resetState();
                return;
            }

            ClientPlayerEntity player = client.player;

            // Detect crosshair target
            Entity currentTarget = null;
            if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                EntityHitResult entityHit = (EntityHitResult) client.crosshairTarget;
                Entity entity = entityHit.getEntity();
                if (entity instanceof PlayerEntity) {
                    currentTarget = entity;
                }
            }

            long now = System.currentTimeMillis();

            // ─── ANTICIPATION BLOCK (updated version) ───

            // 1) Fire any pending click:
            if (pendingScheduledAttack && now >= scheduledAttackTime) {
                // Check line of sight and FOV before attacking
                if (scheduledAttackClient != null && player.canSee(lastTarget) && isInFov(player, lastTarget, FOV_DEGREES)) {
                    performDoAttack(scheduledAttackClient);
                    hasAttackedThisCooldown = true;
                    lastAttackTime = now;
                }
                pendingScheduledAttack = false;
            }

            // 2) Fire any pending jittered attack:
            if (pendingJitterAttack && now >= jitterScheduledAttackTime) {
                // Check line of sight and FOV before attacking
                if (jitterScheduledAttackClient != null && player.canSee(lastTarget) && isInFov(player, lastTarget, FOV_DEGREES)) {
                    performDoAttack(jitterScheduledAttackClient);
                    hasAttackedThisCooldown = true;
                    lastAttackTime = now;
                }
                pendingJitterAttack = false;
            }

            // 3) New target: do anticipation (true prediction 10%, standard 90%)
            if (currentTarget instanceof PlayerEntity &&
                player.canSee(currentTarget) &&
                isInFov(player, currentTarget, FOV_DEGREES)) {
                if (lastTarget != currentTarget) {
                    if (random.nextDouble() < 0.10) {
                        // ───── 10% TRUE PREDICTION-BASED ANTICIPATION ─────
                        long dt = now - lastPredictTime;
                        if (dt > 0) {
                            // Compute predicted yaw/pitch based on target position
                            Vec3d eyePos = player.getCameraPosVec(1.0F);
                            Vec3d tgtPos = ((PlayerEntity) currentTarget).getCameraPosVec(1.0F);
                            Vec3d delta = tgtPos.subtract(eyePos);
                            predictedYaw = Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90;
                            predictedPitch = -Math.toDegrees(Math.atan2(delta.y, Math.hypot(delta.x, delta.z)));

                            double yawDiff = Math.abs(player.getYaw() - predictedYaw);
                            double pitchDiff = Math.abs(player.getPitch() - predictedPitch);
                            double vy = dt > 1e-6 ? yawDiff / dt : 0.0;
                            double vp = dt > 1e-6 ? pitchDiff / dt : 0.0;
                            long timeToCenter = (long)(Math.max(
                                vy > 1e-6 ? yawDiff / vy : 0,
                                vp > 1e-6 ? pitchDiff / vp : 0
                            ));
                            long buffer = 4 + random.nextInt(3); // 4–6ms early
                            if (timeToCenter <= 50) {
                                scheduledAttackTime    = now + timeToCenter - buffer;
                                pendingScheduledAttack = true;
                                scheduledAttackClient  = client;
                            }
                        }
                        lastPredictTime = now;
                    } else {
                        // ───── 90% STANDARD ANTICIPATION (DELAYED REACTION) ─────
                        int anticipationDelay = 30 + random.nextInt(31); // 30–60ms
                        scheduledAttackTime    = now + anticipationDelay;
                        pendingScheduledAttack = true;
                        scheduledAttackClient  = client;
                    }
                }
            }
            lastTarget = currentTarget;

            // ────────────────────────────

            // Track if the enemy hit me: detect recent damage taken
            if (player.hurtTime > 0) {
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = now;
                inRecentlyHitDelayWindow = true;
                recentlyHitWindowStart = now;
            } else {
                if (inRecentlyHitDelayWindow && now - recentlyHitWindowStart > RECENTLY_HIT_WINDOW_MS) {
                    inRecentlyHitDelayWindow = false;
                }
                if (enemyRecentlyHitMe && now - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            // Post-eat/use delays
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = now;
                nextAllowedPostEatAttack = finishedEatOrUseTime + nextHumanLikeDelay(70, 80, false, false, false, 0);
                return;
            }
            if (postEatDelayActive) {
                if (now < nextAllowedPostEatAttack) {
                    return;
                } else {
                    postEatDelayActive = false;
                }
            }

            // Only attack if holding a sword
            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                    main.getItem() == Items.STONE_SWORD ||
                    main.getItem() == Items.IRON_SWORD ||
                    main.getItem() == Items.GOLDEN_SWORD ||
                    main.getItem() == Items.DIAMOND_SWORD ||
                    main.getItem() == Items.NETHERITE_SWORD)) {
                resetState();
                return;
            }

            float cooldown = player.getAttackCooldownProgress(0.5F);
            if (cooldown < 0.86f) {
                hasAttackedThisCooldown = false;
            }

            boolean canAttack = true;

            // --- Attack logic for air/ground ---
            if (currentTarget != null && currentTarget instanceof PlayerEntity &&
                player.canSee(currentTarget) && isInFov(player, currentTarget, FOV_DEGREES)) {
                if (!player.isOnGround() && player.getVelocity().y < -0.08) {
                    if (cooldown < 0.86f) {
                        hasAttackedThisCooldown = false;
                        return;
                    }
                    if (hasAttackedThisCooldown) return;
                    if (!canAttack) return;

                    long delay;
                    boolean targetIsEating = ((PlayerEntity) currentTarget).isUsingItem();
                    if (targetIsEating) {
                        delay = nextHumanLikeDelay(390, 520, false, false, true, 0);
                    } else {
                        delay = nextHumanLikeDelay(314, 520, false, false, false, 0);
                    }
                    scheduleJitteredAttack(client, delay);
                    lastAirDelay = delay;
                    lastAttackDelay = delay;
                    nextAllowedAirAttack = now + delay;
                } else if (player.isOnGround()) {
                    if (cooldown < 0.86f) {
                        hasAttackedThisCooldown = false;
                        return;
                    }
                    if (hasAttackedThisCooldown) return;
                    if (!canAttack) return;

                    long delay;
                    if (inRecentlyHitDelayWindow) {
                        delay = nextHumanLikeDelay(580, 650, true, false, false, 0);
                    } else {
                        delay = nextHumanLikeDelay(520, 579, false, false, false, 0);
                    }
                    scheduleJitteredAttack(client, delay);
                    lastGroundDelay = delay;
                    lastAttackDelay = delay;
                    nextAllowedGroundAttack = now + delay;
                }
            }
        });
    }

    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }

    /**
     * Returns true if the target is within the specified FOV angle (degrees) of the player's view.
     */
    private boolean isInFov(ClientPlayerEntity player, Entity target, double fovDegrees) {
        Vec3d playerPos = player.getCameraPosVec(1.0F);
        Vec3d targetPos = target.getPos().add(0, target.getStandingEyeHeight(), 0);
        Vec3d toTarget = targetPos.subtract(playerPos).normalize();

        // Player's look vector
        Vec3d look = player.getRotationVec(1.0F).normalize();

        // Angle in degrees between look and toTarget
        double dot = look.dotProduct(toTarget);
        double angle = Math.acos(dot) * (180.0 / Math.PI);
        return angle <= (fovDegrees / 2.0);
    }

    /**
     * Advanced human-like delay generator with:
     * - Continuously varying Weibull k
     * - Mixture of AR(1) components (slow/fast)
     * - Time-of-session λ drift
     * - Frame-jitter desynchronization (now via scheduling, not sleep)
     * - Real RT GMM fallback
     * All output is clamped to [min, max].
     */
    private long nextHumanLikeDelay(int min, int max, boolean recentlyHit, boolean postEat, boolean eating, int comboCount) {
        // 1. Update Weibull k value every 5-10 clicks
        clicksSinceKChange++;
        if (clicksSinceKChange >= 5 + random.nextInt(6)) { // every 5-10
            currentK = 0.7 + random.nextDouble() * (1.6 - 0.7);
            clicksSinceKChange = 0;
        }

        // 2. Time-of-session λ drift
        double baseLambda = (min + max) / 2.0;
        long minutes = (System.currentTimeMillis() - sessionStartTime) / 60000;
        double drift = (random.nextDouble() - 0.5) * 20 * minutes; // ±10ms/minute
        double lambda = Math.max(30, baseLambda + drift);

        // 3. Generate base delay: mixture of Weibull & GMM (real RT)
        double delay;
        if (random.nextDouble() < 0.15) {
            delay = sampleGMMHumanRT();
        } else {
            double u = random.nextDouble();
            delay = lambda * Math.pow(-Math.log(1 - u), 1.0 / currentK);
        }

        // 4. AR(1) mixture: slow/fast blend
        double slowAlpha = 0.2, fastAlpha = 0.8;
        prevSlowAR = slowAlpha * delay + (1 - slowAlpha) * prevSlowAR;
        prevFastAR = fastAlpha * delay + (1 - fastAlpha) * prevFastAR;
        delay = 0.5 * prevSlowAR + 0.5 * prevFastAR;

        // 5. Clamp pre-jitter (keep in bounds before jitter so frame-jitter can't escape)
        delay = Math.max(min, Math.min(max, delay));

        return (long) Math.round(delay);
    }

    // Real human RT GMM sample (fit these with real data if possible)
    private double sampleGMMHumanRT() {
        double r = random.nextDouble();
        int which = 0;
        if (r < GMM_WEIGHTS[0]) which = 0;
        else if (r < GMM_WEIGHTS[0] + GMM_WEIGHTS[1]) which = 1;
        else which = 2;
        return GMM_MEANS[which] + GMM_STDS[which] * random.nextGaussian();
    }

    /**
     * Instead of Thread.sleep, schedule the attack to happen after a jittered delay using the tick loop.
     * This sets a pendingJitterAttack flag and the scheduled time; the tick loop will fire the attack.
     */
    private void scheduleJitteredAttack(MinecraftClient client, long intendedDelay) {
        int tickJitter = -2 + random.nextInt(5); // -2..2
        int msJitter = random.nextInt(18); // 0-17 ms
        long jitter = tickJitter * 50L + msJitter;
        long now = System.currentTimeMillis();
        jitterScheduledAttackTime = now + intendedDelay + jitter;
        jitterScheduledAttackClient = client;
        pendingJitterAttack = true;
    }

    private void resetState() {
        wasEatingOrUsing = false;
        postEatDelayActive = false;
        finishedEatOrUseTime = 0L;
        lastTarget = null;
        enemyRecentlyHitMe = false;
        lastEnemyAttackTime = 0L;
        inRecentlyHitDelayWindow = false;
        recentlyHitWindowStart = 0L;
        nextAllowedGroundAttack = 0L;
        nextAllowedAirAttack = 0L;
        nextAllowedPostEatAttack = 0L;
        lastGroundDelay = 540;
        lastAirDelay = 400;
        lastAttackDelay = 0L;
        hasAttackedThisCooldown = false;
        currentK = 1.1;
        clicksSinceKChange = 0;
        prevSlowAR = 500;
        prevFastAR = 500;
        sessionStartTime = System.currentTimeMillis();
        pendingScheduledAttack = false;
        scheduledAttackTime = 0L;
        scheduledAttackClient = null;
        predictedYaw = 0;
        predictedPitch = 0;
        lastPredictTime = System.currentTimeMillis();
        pendingJitterAttack = false;
        jitterScheduledAttackTime = 0L;
        jitterScheduledAttackClient = null;
    }
}