package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer; import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents; import net.minecraft.client.MinecraftClient; import net.minecraft.client.network.ClientPlayerEntity; import net.minecraft.entity.Entity; import net.minecraft.entity.player.PlayerEntity; import net.minecraft.item.ItemStack; import net.minecraft.item.Item; import net.minecraft.item.Items; import net.minecraft.util.Hand; import net.minecraft.util.hit.HitResult; import net.minecraft.util.math.Vec3d; import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer { // CONFIGURATION private static final float COOLDOWN_THRESHOLD = 0.86f; private static final boolean REQUIRE_CRIT = false; private static final boolean ONLY_SWORDS = true; private static final double MAX_REACH = 3.0D;

private static final Random random = new Random();

// State guards
private boolean modEnabled = false;
private boolean prevAltPressed = false;
private boolean hasFiredThis = false;
private int lastTargetId = -1;
private boolean targetPreviouslyInCrosshair = false;

@Override
public void onInitializeClient() {
    ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
}

private void onTick(MinecraftClient client) {
    if (client.player == null || client.world == null) {
        resetShotGuard();
        return;
    }
    if (client.currentScreen != null) {
        resetShotGuard();
        return;
    }
    // Toggle mod
    boolean altPressed = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
    if (altPressed && !prevAltPressed) modEnabled = !modEnabled;
    prevAltPressed = altPressed;
    if (!modEnabled) {
        resetAll();
        return;
    }

    // Raycast
    HitResult hit = client.cameraEntity.raycast(MAX_REACH + 5.0D, 0.0F, false);
    if (hit == null || hit.getType() != HitResult.Type.ENTITY) {
        resetShotGuard();
        updateTargetState(false, null);
        return;
    }
    Entity e = ((HitResult.EntityHitResult) hit).getEntity();
    if (!(e instanceof PlayerEntity)) {
        resetShotGuard();
        updateTargetState(false, null);
        return;
    }
    PlayerEntity target = (PlayerEntity) e;

    // Target state
    boolean valid = target.getId() != client.player.getId();
    boolean isNew = valid && (target.getId() != lastTargetId || !targetPreviouslyInCrosshair);
    if (isNew) resetShotGuard();

    // Gating: sword check
    ItemStack main = client.player.getMainHandStack();
    if (ONLY_SWORDS && !isSword(main)) {
        updateTargetState(false, null);
        return;
    }
    // Reach check
    Vec3d a = client.player.getPos(), b = target.getPos();
    if (a.squaredDistanceTo(b) > MAX_REACH * MAX_REACH) {
        resetShotGuard();
        updateTargetState(false, target);
        return;
    }
    // Cooldown
    float cooldown = client.player.getAttackCooldownProgress(0.0F);
    if (cooldown < COOLDOWN_THRESHOLD) return;
    // Crit
    if (REQUIRE_CRIT && !canCrit(client.player)) return;
    // Single-shot guard
    if (hasFiredThis) return;

    // Determine delay based on ground/air
    int delayMs;
    if (client.player.isOnGround()) {
        delayMs = sampleGroundDelay();
    } else if (client.player.getVelocity().y < -0.08) {
        delayMs = sampleAirDelay(target.isUsingItem());
    } else {
        delayMs = sampleReactionDelay();
    }

    // Schedule attack on separate thread
    scheduleAttack(client.player, target, delayMs);
    hasFiredThis = true;
    updateTargetState(valid, target);
}

private void scheduleAttack(ClientPlayerEntity attacker, PlayerEntity victim, int delayMs) {
    new Thread(() -> {
        try {
            Thread.sleep(delayMs);
        } catch (InterruptedException ignored) {}
        sendAttack(attacker, victim);
    }, "TriggerBot-DelayThread").start();
}

private void sendAttack(ClientPlayerEntity attacker, PlayerEntity victim) {
    // Swing hand animation
    attacker.swingHand(Hand.MAIN_HAND);
    // Send attack packet to match original triggerbot
    attacker.networkHandler.sendPacket(
        new CPlayerPacket.CUseEntityPacket(victim, CPlayerPacket.AttackType.ATTACK)
    );
}

private int sampleTruncatedNormal(int min, int max, double mean, double stddev) {
    int value;
    do { value = (int) Math.round(mean + stddev * random.nextGaussian()); }
    while (value < min || value > max);
    return value;
}

private int sampleGroundDelay() {
    int roll = random.nextInt(1000);
    if (roll < 5) {
        return sampleTruncatedNormal(520, 589, 554.5, 15);
    } else if (roll > 994) {
        return sampleTruncatedNormal(636, 650, 643, 5);
    } else {
        return sampleTruncatedNormal(590, 635, 612.5, 10);
    }
}

private int sampleAirDelay(boolean eating) {
    if (eating) {
        return sampleTruncatedNormal(361, 420, 390.5, 14);
    } else {
        return sampleTruncatedNormal(325, 360, 342.5, 10);
    }
}

private int sampleReactionDelay() {
    return sampleTruncatedNormal(0, 5, 2, 1);
}

private boolean isSword(ItemStack stack) {
    Item i = stack.getItem();
    return i == Items.WOODEN_SWORD || i == Items.STONE_SWORD || i == Items.IRON_SWORD
        || i == Items.GOLDEN_SWORD || i == Items.DIAMOND_SWORD || i == Items.NETHERITE_SWORD;
}

private boolean canCrit(ClientPlayerEntity me) {
    return me.getVelocity().y < 0.0D && !me.isOnGround();
}

private void resetShotGuard() {
    hasFiredThis = false;
}

private void resetAll() {
    hasFiredThis = false;
    lastTargetId = -1;
    targetPreviouslyInCrosshair = false;
}

private void updateTargetState(boolean valid, PlayerEntity target) {
    if (valid && target != null) {
        lastTargetId = target.getId();
        targetPreviouslyInCrosshair = true;
    } else {
        lastTargetId = -1;
        targetPreviouslyInCrosshair = false;
    }
}

}

