package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;
    private static final Random random = new Random();

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating/use tracking
    private boolean wasEatingOrUsing = false;
    private long finishedEatOrUseTime = 0L;
    private boolean postEatDelayActive = false;

    // Track target transitions for "first see" logic
    private Entity lastTarget = null;

    // --- NEW FIELDS FOR REACTION DELAY ---
    private long targetAcquiredTime = 0L;
    private long targetReactionDelay = 0L;      // in milliseconds
    private boolean reactionPending = false;

    // Track if the enemy has recently hit the player
    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200;

    // Attack timers for ground and air delays, and post-eat/use delay
    private long nextAllowedGroundAttack = 0L;
    private long nextAllowedAirAttack = 0L;
    private long nextAllowedPostEatAttack = 0L;

    // --- Human-like randomization state ---
    private long lastGroundDelay = 0L;
    private long lastAirDelay = 0L;

    // --- Aim jitter state ---
    private float lastSentYaw = Float.NaN;
    private float lastSentPitch = Float.NaN;
    private int jitterTickCounter = 0;
    private int jitterNonIdenticalTicks = 0;
    private static final int JITTER_WINDOW = 45;

    // --- Angle/attack anti-GrimAC logic ---
    private int aimMicroflickTicks = 0;
    private int aimMicroflickTarget = 60 + random.nextInt(31);

    // --- AimModulo360 enforce-variance logic ---
    private static final int WINDOW_SIZE = 45;
    private float[] deltaYawWindow = new float[WINDOW_SIZE];
    private float[] deltaPitchWindow = new float[WINDOW_SIZE];
    private int windowIndex = 0;
    private boolean forceBigFlickNextTick = false;

    // --- Reaction time logic for tracking
    private float lastYaw = Float.NaN;
    private float lastPitch = Float.NaN;
    private boolean lastHadTarget = false;
    private int nearTargetCount = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                wasEatingOrUsing = false;
                postEatDelayActive = false;
                finishedEatOrUseTime = 0L;
                lastTarget = null;
                reactionPending = false;
                enemyRecentlyHitMe = false;
                lastEnemyAttackTime = 0L;
                nextAllowedGroundAttack = 0L;
                nextAllowedAirAttack = 0L;
                nextAllowedPostEatAttack = 0L;
                lastGroundDelay = 0L;
                lastAirDelay = 0L;
                lastSentYaw = Float.NaN;
                lastSentPitch = Float.NaN;
                jitterTickCounter = 0;
                jitterNonIdenticalTicks = 0;
                aimMicroflickTicks = 0;
                aimMicroflickTarget = 60 + random.nextInt(31);
                for (int i = 0; i < WINDOW_SIZE; i++) {
                    deltaYawWindow[i] = 0f;
                    deltaPitchWindow[i] = 0f;
                }
                windowIndex = 0;
                forceBigFlickNextTick = false;
                lastYaw = Float.NaN;
                lastPitch = Float.NaN;
                lastHadTarget = false;
                nearTargetCount = 0;
                return;
            }

            ClientPlayerEntity player = client.player;
            Entity currentTarget = client.targetedEntity;

            // Save old yaw/pitch before jitter (for Δ computation)
            float prevYaw = player.getYaw();
            float prevPitch = player.getPitch();

            // --- Apply aim jitter every tick (with microflicks and forced coverage) ---
            float appliedJitterYaw = 0, appliedJitterPitch = 0;
            aimMicroflickTicks++;
            if (forceBigFlickNextTick) {
                appliedJitterYaw = (random.nextFloat() * 1.3f + 0.2f) * (random.nextBoolean() ? 1f : -1f);
                appliedJitterPitch = (random.nextFloat() * 1.3f + 0.2f) * (random.nextBoolean() ? 1f : -1f);
                forceBigFlickNextTick = false;
                aimMicroflickTicks = 0;
                aimMicroflickTarget = 30 + random.nextInt(61);
            } else if (aimMicroflickTicks >= aimMicroflickTarget) {
                appliedJitterYaw = (random.nextFloat() * 1.4f + 0.2f) * (random.nextBoolean() ? 1f : -1f);
                appliedJitterPitch = (random.nextFloat() * 1.4f + 0.2f) * (random.nextBoolean() ? 1f : -1f);
                aimMicroflickTicks = 0;
                aimMicroflickTarget = 30 + random.nextInt(61);
            } else {
                appliedJitterYaw = (random.nextFloat() * 0.01f + 0.005f) * (random.nextBoolean() ? 1f : -1f);
                appliedJitterPitch = (random.nextFloat() * 0.01f + 0.005f) * (random.nextBoolean() ? 1f : -1f);
            }

            float newYaw = prevYaw + appliedJitterYaw;
            float newPitch = Math.max(-90f, Math.min(90f, prevPitch + appliedJitterPitch));
            player.setYaw(newYaw);
            player.setPitch(newPitch);

            // Track Δyaw, Δpitch in ring buffer
            float deltaYaw = Math.abs(((newYaw - prevYaw + 540) % 360) - 180);
            float deltaPitch = Math.abs(((newPitch - prevPitch + 540) % 360) - 180);

            deltaYawWindow[windowIndex] = deltaYaw;
            deltaPitchWindow[windowIndex] = deltaPitch;
            windowIndex = (windowIndex + 1) % WINDOW_SIZE;

            // Check if too many Δ are "small" (<0.02°)
            int smallYaw = 0, smallPitch = 0;
            for (int i = 0; i < WINDOW_SIZE; i++) {
                if (deltaYawWindow[i] < 0.02f) smallYaw++;
                if (deltaPitchWindow[i] < 0.02f) smallPitch++;
            }
            if (smallYaw >= 40 || smallPitch >= 40) {
                forceBigFlickNextTick = true;
            }

            // Always apply safe jitter (even after a microflick)
            applySafeAimJitter(player);

            // Track if the enemy hit me: detect recent damage taken
            if (player.hurtTime > 0) {
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = System.currentTimeMillis();
            } else {
                if (enemyRecentlyHitMe && System.currentTimeMillis() - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            // Don't do anything while eating or using an item in either hand (self!)
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }

            // If just finished eating/using, start the delay (self!)
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = System.currentTimeMillis();
                nextAllowedPostEatAttack = finishedEatOrUseTime + nextHumanDelay(70, 80);
                return;
            }

            // If in post-eat/use delay, skip until timer expires
            if (postEatDelayActive) {
                long now = System.currentTimeMillis();
                if (now < nextAllowedPostEatAttack) {
                    return;
                } else {
                    postEatDelayActive = false;
                }
            }

            // Don't attack if not holding a sword
            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                lastTarget = null;
                reactionPending = false;
                lastYaw = player.getYaw();
                lastPitch = player.getPitch();
                lastHadTarget = false;
                nearTargetCount = 0;
                return;
            }

            // --- Reaction time logic based on snap/tracking ---
            float currentYaw = player.getYaw();
            float currentPitch = player.getPitch();
            boolean justAcquiredTarget = (currentTarget != null && currentTarget != lastTarget);
            float yawDelta = Float.isNaN(lastYaw) ? 0f : computeAngularDelta(lastYaw, currentYaw);
            float pitchDelta = Float.isNaN(lastPitch) ? 0f : computeAngularDelta(lastPitch, currentPitch);
            boolean farSnap = (justAcquiredTarget && (Math.abs(yawDelta) > 10f || Math.abs(pitchDelta) > 10f));
            boolean nearTracking = false;

            if (currentTarget != null && lastHadTarget) {
                if (Math.abs(yawDelta) < 3f && Math.abs(pitchDelta) < 3f) {
                    nearTargetCount++;
                    if (nearTargetCount >= 3) {
                        nearTracking = true;
                    }
                } else {
                    nearTargetCount = 0;
                }
            } else {
                nearTargetCount = 0;
            }

            if (justAcquiredTarget) {
                targetAcquiredTime = System.currentTimeMillis();
                if (farSnap) {
                    targetReactionDelay = nextHumanDelay(85, 110);
                    reactionPending = true;
                } else {
                    reactionPending = false;
                }
            }
            lastTarget = currentTarget;
            lastYaw = currentYaw;
            lastPitch = currentPitch;
            lastHadTarget = (currentTarget != null);

            // --- Attack logic: no reach enforcement, just vanilla ---
            if (currentTarget != null && !player.isOnGround() && player.getVelocity().y < -0.08) {
                long now = System.currentTimeMillis();
                if (now >= nextAllowedAirAttack) {
                    long jumpDelay = nextRealHumanDelay(lastAirDelay, true, false);
                    lastAirDelay = jumpDelay;
                    nextAllowedAirAttack = now + jumpDelay;
                    applyAttackAimJitter(player);
                    performDoAttack(client);
                    lastAttackTime = now;
                }
            } else if (currentTarget != null && player.isOnGround()) {
                long now = System.currentTimeMillis();
                if (reactionPending) {
                    if (now < targetAcquiredTime + targetReactionDelay) {
                        return;
                    } else {
                        reactionPending = false;
                    }
                }
                if (now >= nextAllowedGroundAttack) {
                    long groundDelay;
                    if (enemyRecentlyHitMe) {
                        groundDelay = nextRealHumanDelay(lastGroundDelay, false, true);
                    } else {
                        groundDelay = nextRealHumanDelay(lastGroundDelay, false, false);
                    }
                    lastGroundDelay = groundDelay;
                    nextAllowedGroundAttack = now + groundDelay;
                    applyAttackAimJitter(player);
                    performDoAttack(client);
                    lastAttackTime = now;
                }
            }
        });
    }

    /**
     * Compute the minimal angular difference mod 360.
     */
    private float computeAngularDelta(float prev, float curr) {
        float delta = ((curr - prev + 540f) % 360f) - 180f;
        return delta;
    }

    /**
     * Applies safe aim jitter to the player's rotation.
     */
    private void applySafeAimJitter(ClientPlayerEntity player) {
        float baseYaw = player.getYaw();
        float basePitch = player.getPitch();

        float jitterYaw = (random.nextFloat() * 0.01f + 0.005f) * (random.nextBoolean() ? 1f : -1f);
        float jitterPitch = (random.nextFloat() * 0.01f + 0.005f) * (random.nextBoolean() ? 1f : -1f);

        float newYaw = baseYaw + jitterYaw;
        float newPitch = basePitch + jitterPitch;

        if (Float.compare(newYaw, lastSentYaw) == 0) {
            newYaw += (random.nextFloat() - 0.5f) * 0.001f + 0.0001f;
        }
        if (Float.compare(newPitch, lastSentPitch) == 0) {
            newPitch += (random.nextFloat() - 0.5f) * 0.001f + 0.0001f;
        }

        newPitch = Math.max(-90f, Math.min(90f, newPitch));

        jitterTickCounter++;
        if (Math.abs(newYaw - lastSentYaw) > 0.00009f || Math.abs(newPitch - lastSentPitch) > 0.00009f) {
            jitterNonIdenticalTicks++;
        }

        if (jitterTickCounter >= JITTER_WINDOW) {
            if (jitterNonIdenticalTicks < 20) {
                jitterNonIdenticalTicks = 0;
                jitterTickCounter = 0;
            } else {
                jitterNonIdenticalTicks = 0;
                jitterTickCounter = 0;
            }
        }

        lastSentYaw = newYaw;
        lastSentPitch = newPitch;

        player.setYaw(newYaw);
        player.setPitch(newPitch);
    }

    /**
     * Applies a larger random aim deviation to the player's rotation before attacking, to evade GrimAC hit-angle checks.
     */
    private void applyAttackAimJitter(ClientPlayerEntity player) {
        float baseYaw = player.getYaw();
        float basePitch = player.getPitch();

        float jitterRange = random.nextFloat() < 0.08f ? (random.nextFloat() * 0.8f + 1.2f) : (random.nextFloat() * 1.0f + 0.2f);
        float jitterYaw = jitterRange * (random.nextBoolean() ? 1f : -1f);
        float jitterPitch = jitterRange * (random.nextBoolean() ? 1f : -1f);

        player.setYaw(baseYaw + jitterYaw);
        player.setPitch(Math.max(-90f, Math.min(90f, basePitch + jitterPitch)));
    }

    /**
     * "Humanized" log-normal delay using randomized curve each call.
     */
    private long nextHumanDelay(int min, int max) {
        double logMin = Math.log(Math.max(min, 1));
        double logMax = Math.log(max);
        double muBase = (logMin + logMax) / 2.0;
        double sigmaBase = (logMax - logMin) / 6.0;

        double mu = muBase + (random.nextDouble() - 0.5) * 0.20;
        double sigma = sigmaBase * (0.85 + random.nextDouble() * 0.4);

        if (random.nextDouble() < 0.05) {
            return min + random.nextInt((max - min) + 1);
        }
        if (random.nextDouble() < 0.05) {
            long a = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
            long b = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
            long sample = (a + b) / 2;
            return Math.max(min, Math.min(max, sample));
        }

        long result = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
        return Math.max(min, Math.min(max, result));
    }

    /**
     * Human-like, correlated, realistic attack delay generator.
     */
    private long nextRealHumanDelay(long previousDelay, boolean isAir, boolean recentlyHit) {
        double mean = isAir ? 350.0 : (recentlyHit ? 610.0 : 550.0);
        double sigma = isAir ? 0.25 : 0.22;

        double mu = Math.log(mean);

        long delay = (long) Math.exp(mu + sigma * random.nextGaussian());

        if (previousDelay > 0) {
            delay = (long) (0.7 * delay + 0.3 * previousDelay);
        }

        delay += random.nextInt(11) - 5;

        if (isAir)
            return Math.max(50, Math.min(1200, delay));
        else
            return Math.max(50, Math.min(2000, delay));
    }

    /**
     * Calls MinecraftClient.doAttack() directly for the triggerbot attack.
     */
    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }

    @Deprecated
    private long getHumanizedJumpDelay(Entity target) {
        boolean targetIsEating = false;
        if (target instanceof PlayerEntity) {
            PlayerEntity targetPlayer = (PlayerEntity) target;
            targetIsEating = targetPlayer.isUsingItem();
        }

        if (targetIsEating) {
            int roll = random.nextInt(100);
            if (roll < 70) {
                return nextHumanDelay(370, 420);
            } else {
                return nextHumanDelay(421, 480);
            }
        } else {
            int roll = random.nextInt(100);
            if (roll < 85) {
                return nextHumanDelay(341, 370);
            } else if (roll < 90) {
                return nextHumanDelay(421, 460);
            } else if (roll < 95) {
                return nextHumanDelay(460, 520);
            } else {
                return nextHumanDelay(316, 340);
            }
        }
    }
}