package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    private boolean wasEatingOffhand = false;
    private boolean postEatDelayActive = false;
    private long scheduledPostEatAttackTime = 0L;

    private int lastTargetId = -1;
    private boolean targetPreviouslyInCrosshair = false;

    private float groundAttackCooldownTarget = 1.0f;
    private float airAttackCooldownTarget = 1.0f;

    private static final Random random = new Random();

    // Gaussian params
    private static final float COOLDOWN_MEAN = 0.955f;
    private static final float COOLDOWN_STDDEV = 0.025f;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            if (altPressed && !prevAltPressed) modEnabled = !modEnabled;
            prevAltPressed = altPressed;

            if (!modEnabled) {
                resetAll();
                return;
            }

            handlePostEatDelay(client);
            if (postEatDelayActive || client.player.isUsingItem()) return;

            ItemStack main = client.player.getMainHandStack();
            if (!isSword(main)) {
                resetTargeting();
                return;
            }

            // Use targetedEntity instead of raycast
            Entity target = client.targetedEntity;
            boolean valid = target instanceof PlayerEntity && target != client.player;
            boolean isNew = valid && (target.getId() != lastTargetId || !targetPreviouslyInCrosshair);
            if (isNew) {
                lastTargetId = target.getId();
                targetPreviouslyInCrosshair = true;
                randomizeCooldownTargetsGaussian();
            }

            if (valid) {
                float cooldown = client.player.getAttackCooldownProgress(0.0f);
                if (client.player.isOnGround()) {
                    handleGroundAttack(client, cooldown);
                } else if (client.player.getVelocity().y < -0.08) {
                    handleAirAttack(client, cooldown);
                }
            } else {
                lastTargetId = -1;
                targetPreviouslyInCrosshair = false;
            }
        });
    }

    private void randomizeCooldownTargetsGaussian() {
        groundAttackCooldownTarget = gaussianCooldown();
        airAttackCooldownTarget = gaussianCooldown();
    }

    private float gaussianCooldown() {
        double value = random.nextGaussian() * COOLDOWN_STDDEV + COOLDOWN_MEAN;
        if (value < 0.90) value = 0.90;
        if (value > 1.01) value = 1.01;
        return (float) value;
    }

    private void handleGroundAttack(MinecraftClient client, float cooldown) {
        if (cooldown >= groundAttackCooldownTarget) {
            client.doAttack();
            groundAttackCooldownTarget = gaussianCooldown();
        }
    }

    private void handleAirAttack(MinecraftClient client, float cooldown) {
        if (cooldown >= airAttackCooldownTarget) {
            client.doAttack();
            airAttackCooldownTarget = gaussianCooldown();
        }
    }

    // Updated post-eat delay to 70-75ms
    private void handlePostEatDelay(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        boolean eatingOff = player.getOffHandStack().isFood() && player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND;
        long now = System.currentTimeMillis();
        if (eatingOff) {
            wasEatingOffhand = true;
            postEatDelayActive = false;
            return;
        }
        if (wasEatingOffhand) {
            wasEatingOffhand = false;
            postEatDelayActive = true;
            scheduledPostEatAttackTime = now + (70 + random.nextInt(6)); // 70-75 ms
            return;
        }
        if (postEatDelayActive && now < scheduledPostEatAttackTime) return;
        postEatDelayActive = false;
    }

    private boolean isSword(ItemStack stack) {
        return switch (stack.getItem().toString()) {
            case "minecraft:wooden_sword", "minecraft:stone_sword", "minecraft:iron_sword",
                 "minecraft:golden_sword", "minecraft:diamond_sword", "minecraft:netherite_sword" -> true;
            default -> false;
        };
    }

    private void resetAll() {
        wasEatingOffhand = postEatDelayActive = false;
        scheduledPostEatAttackTime = 0L;
        lastTargetId = -1;
        targetPreviouslyInCrosshair = false;
        groundAttackCooldownTarget = 1.0f;
        airAttackCooldownTarget = 1.0f;
    }

    private void resetTargeting() {
        lastTargetId = -1;
        targetPreviouslyInCrosshair = false;
        groundAttackCooldownTarget = 1.0f;
        airAttackCooldownTarget = 1.0f;
    }
}