package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class HappyClient implements ClientModInitializer {

    private static final Random random = new Random();

    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "HappyClient-AttackScheduler");
        t.setDaemon(true);
        return t;
    });

    private volatile boolean modEnabled = false;
    private boolean prevAltPressed = false;

    private volatile boolean attackScheduled = false;
    private volatile AttackMode scheduledMode = AttackMode.NONE;
    private volatile long scheduledAttackReadyTimeMs = 0L;

    // For post-eat delay tracking
    private volatile boolean postEatDelayActive = false;
    private volatile long postEatDelayEndMs = 0L;
    private boolean wasEatingOffhandLastTick = false;
    private boolean wasOnGroundLastTick = true;

    // For reaction time logic
    private Entity lastTargetedEntity = null;
    private volatile boolean reactionTimeActive = false;
    private volatile long reactionTimeEndMs = 0L;

    enum AttackMode {
        NONE,
        JUMP,
        GROUND
    }

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod with Left Alt key
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                attackScheduled = false;
                scheduledMode = AttackMode.NONE;
                postEatDelayActive = false;
                wasEatingOffhandLastTick = false;
                wasOnGroundLastTick = true;
                lastTargetedEntity = null;
                reactionTimeActive = false;
                reactionTimeEndMs = 0L;
                return;
            }

            ClientPlayerEntity player = client.player;
            // Track if you are eating food from offhand
            ItemStack offHand = player.getStackInHand(Hand.OFF_HAND);
            boolean isEatingFoodOffhand = isFood(offHand) && player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND;

            // Detect just finished eating from offhand (on last tick you were eating, now you're not)
            if (wasEatingOffhandLastTick && !isEatingFoodOffhand) {
                if (player.isOnGround()) {
                    int delay = 62 + random.nextInt(9); // 62-70ms inclusive
                    long now = System.currentTimeMillis();
                    postEatDelayActive = true;
                    postEatDelayEndMs = now + delay;
                } else {
                    postEatDelayActive = false; // Jumping cancels post-eat delay
                }
            }
            // If you jump anytime after eating, cancel the post-eat delay
            if (!player.isOnGround() && postEatDelayActive) {
                postEatDelayActive = false;
            }
            wasEatingOffhandLastTick = isEatingFoodOffhand;
            wasOnGroundLastTick = player.isOnGround();

            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                    main.getItem() == Items.STONE_SWORD ||
                    main.getItem() == Items.IRON_SWORD ||
                    main.getItem() == Items.GOLDEN_SWORD ||
                    main.getItem() == Items.DIAMOND_SWORD ||
                    main.getItem() == Items.NETHERITE_SWORD)) {
                attackScheduled = false;
                scheduledMode = AttackMode.NONE;
                lastTargetedEntity = null;
                reactionTimeActive = false;
                reactionTimeEndMs = 0L;
                return;
            }

            Entity target = client.targetedEntity;
            boolean validTarget = target != null && target != player && target instanceof PlayerEntity;

            // Reaction time logic: Detect new target
            if (validTarget && target != lastTargetedEntity) {
                // New target acquired, start reaction delay (0-10ms)
                int reactionDelay = random.nextInt(11); // 0-10ms inclusive
                long now = System.currentTimeMillis();
                reactionTimeActive = true;
                reactionTimeEndMs = now + reactionDelay;
                // Schedule disabling reaction time after delay (tick+fraction)
                scheduler.schedule(() -> {
                    client.execute(() -> {
                        // If you jumped, ignore/cancel reaction time
                        if (!player.isOnGround()) {
                            reactionTimeActive = false;
                            return;
                        }
                        reactionTimeActive = false;
                    });
                }, reactionDelay, TimeUnit.MILLISECONDS);
            }
            // Cancel reaction time if you jump
            if (!player.isOnGround() && reactionTimeActive) {
                reactionTimeActive = false;
            }
            lastTargetedEntity = validTarget ? target : null;

            if (!validTarget) {
                attackScheduled = false;
                scheduledMode = AttackMode.NONE;
                return;
            }

            double yVel = player.getVelocity().y;
            boolean onGround = player.isOnGround();

            boolean isInVelocityRange = !onGround && yVel <= -0.08 && yVel >= -0.16;

            long nowMs = System.currentTimeMillis();

            // If post-eat delay is active, don't schedule attacks until it's over (unless you jump)
            if (postEatDelayActive && nowMs < postEatDelayEndMs) {
                attackScheduled = false;
                scheduledMode = AttackMode.NONE;
                return;
            }

            // If reaction time is active, don't schedule attacks until it's over (unless you jump)
            if (reactionTimeActive && nowMs < reactionTimeEndMs) {
                attackScheduled = false;
                scheduledMode = AttackMode.NONE;
                return;
            }

            // Only allow attacks if cooldown is higher than 86%
            float cooldown = player.getAttackCooldownProgress(0.0f);
            if (cooldown <= 0.86f) {
                attackScheduled = false;
                scheduledMode = AttackMode.NONE;
                return;
            }

            // Only schedule a new attack if one isn't already pending
            if (!attackScheduled) {
                if (isInVelocityRange) {
                    long jumpDelay = getJumpDelay(target);
                    scheduledAttackReadyTimeMs = nowMs + jumpDelay;
                    scheduledMode = AttackMode.JUMP;
                    attackScheduled = true;
                    scheduleAttack(client, scheduledAttackReadyTimeMs, scheduledMode);
                } else if (onGround) {
                    long groundDelay = getGroundDelay();
                    scheduledAttackReadyTimeMs = nowMs + groundDelay;
                    scheduledMode = AttackMode.GROUND;
                    attackScheduled = true;
                    scheduleAttack(client, scheduledAttackReadyTimeMs, scheduledMode);
                }
            }
        });
    }

    private void scheduleAttack(MinecraftClient client, long attackReadyMs, AttackMode mode) {
        long delay = Math.max(0, attackReadyMs - System.currentTimeMillis());
        scheduler.schedule(() -> {
            client.execute(() -> {
                if (!modEnabled) {
                    attackScheduled = false;
                    scheduledMode = AttackMode.NONE;
                    return;
                }
                ClientPlayerEntity player = client.player;
                if (player == null || client.world == null) {
                    attackScheduled = false;
                    scheduledMode = AttackMode.NONE;
                    return;
                }
                ItemStack main = player.getMainHandStack();
                if (!(main.getItem() == Items.WOODEN_SWORD ||
                        main.getItem() == Items.STONE_SWORD ||
                        main.getItem() == Items.IRON_SWORD ||
                        main.getItem() == Items.GOLDEN_SWORD ||
                        main.getItem() == Items.DIAMOND_SWORD ||
                        main.getItem() == Items.NETHERITE_SWORD)) {
                    attackScheduled = false;
                    scheduledMode = AttackMode.NONE;
                    return;
                }
                Entity target = client.targetedEntity;
                if (target == null || target == player || !(target instanceof PlayerEntity)) {
                    attackScheduled = false;
                    scheduledMode = AttackMode.NONE;
                    return;
                }
                double yVel = player.getVelocity().y;
                boolean onGround = player.isOnGround();
                boolean isInVelocityRange = !onGround && yVel <= -0.08 && yVel >= -0.16;

                // Only allow attacks if cooldown is higher than 86% (again, in case it changed)
                float cooldown = player.getAttackCooldownProgress(0.0f);
                if (cooldown <= 0.86f) {
                    attackScheduled = false;
                    scheduledMode = AttackMode.NONE;
                    return;
                }

                // Do not attack if post-eat delay is still active (unless you jumped)
                long nowMs = System.currentTimeMillis();
                if (postEatDelayActive && nowMs < postEatDelayEndMs) {
                    attackScheduled = false;
                    scheduledMode = AttackMode.NONE;
                    return;
                }
                // Do not attack if reaction time is still active (unless you jumped)
                if (reactionTimeActive && nowMs < reactionTimeEndMs) {
                    attackScheduled = false;
                    scheduledMode = AttackMode.NONE;
                    return;
                }

                boolean shouldAttack = (mode == AttackMode.JUMP && isInVelocityRange)
                        || (mode == AttackMode.GROUND && onGround);

                if (shouldAttack) {
                    performDoAttack(client);
                }
                attackScheduled = false;
                scheduledMode = AttackMode.NONE;
            });
        }, delay, TimeUnit.MILLISECONDS);
    }

    // Helper: returns true if item is food, false otherwise
    private static boolean isFood(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        FoodComponent food = stack.getItem().getFoodComponent();
        return food != null;
    }

    private long microDrift(long delay, int min, int max) {
        double stddev = 2.5;
        double drift = random.nextGaussian() * stddev;
        long drifted = Math.round(delay + drift);
        return Math.max(min, Math.min(max, drifted));
    }

    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }

    private long nextLogNormalDelay(int min, int max) {
        double logMin = Math.log(Math.max(min, 1));
        double logMax = Math.log(max);
        double mu = (logMin + logMax) / 2.0;
        double sigma = (logMax - logMin) / 6.0;

        double u1 = random.nextDouble();
        double u2 = random.nextDouble();
        double standardNormal = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);

        double sample = Math.exp(mu + sigma * standardNormal);
        long result = Math.round(sample);
        return Math.max(min, Math.min(max, result));
    }

    private long getJumpDelay(Entity target) {
        boolean targetIsEating = false;
        if (target instanceof PlayerEntity) {
            PlayerEntity targetPlayer = (PlayerEntity) target;
            targetIsEating = targetPlayer.isUsingItem();
        }
        if (targetIsEating) {
            return microDrift(nextLogNormalDelay(361, 420), 361, 420);
        } else {
            return microDrift(nextLogNormalDelay(320, 360), 320, 360);
        }
    }

    private long getGroundDelay() {
        int roll = random.nextInt(200); // 0-199
        if (roll < 2) {
            return microDrift(nextLogNormalDelay(520, 589), 520, 589);
        } else if (roll == 2) {
            return microDrift(nextLogNormalDelay(636, 650), 636, 650);
        } else {
            return microDrift(nextLogNormalDelay(590, 635), 590, 635);
        }
    }
}