package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final Random random = new Random();

    // Activation and state
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;
    private Entity lastTarget = null;
    private boolean hasAttackedThisCooldown = false;

    // For anti-cheat delays and "recently hit" logic
    private boolean wasEatingOrUsing = false;
    private boolean postEatDelayActive = false;
    private long finishedEatOrUseTime = 0L;
    private long lastAttackTime = 0L;
    private long nextAllowedGroundAttack = 0L;
    private long nextAllowedAirAttack = 0L;
    private long nextAllowedPostEatAttack = 0L;
    private long lastGroundDelay = 0L;
    private long lastAirDelay = 0L;
    private long lastAttackDelay = 0L;

    // For anti-cheat "recently hit me" window
    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private boolean inRecentlyHitDelayWindow = false;
    private long recentlyHitWindowStart = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200;
    private static final long RECENTLY_HIT_WINDOW_MS = 700L;

    // For air/ground attack reaction
    private long airTargetAcquiredTime = 0L;
    private long airTargetReactionDelay = 0L;
    private boolean airReactionPending = false;

    // Anticipation logic for ground/air attacks
    private long targetAcquiredTime = 0L;
    private boolean reactionPending = false;
    private long reactionPendingStarted = 0L;
    private static final long REACTION_PENDING_TIMEOUT_MS = 500;
    private int attackDelayThisTime = 0;
    private long attackReadyTime = 0L;

    // Anticipation logic (prediction window)
    private boolean anticipationActive = false;
    private long predictedAcquiredTime = 0L;
    private long lastLeftPredictionWindow = 0L;
    private static final float PREDICT_ANGLE = 4.0f;
    private static final float ACTUAL_HIT_ANGLE = 1.0f;
    private static final long ANTICIPATION_FORGIVENESS_MS = 300; // Reset anticipation if left for 300ms
    private float lastScreenAngle = Float.MAX_VALUE;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                resetState();
                return;
            }

            ClientPlayerEntity player = client.player;

            // Detect crosshair target
            Entity currentTarget = null;
            if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                EntityHitResult entityHit = (EntityHitResult) client.crosshairTarget;
                Entity entity = entityHit.getEntity();
                if (entity instanceof PlayerEntity) {
                    currentTarget = entity;
                }
            }

            // --- Anticipation logic (no aim movement here) ---
            float playerYaw = player.getYaw();
            float playerPitch = player.getPitch();

            // Compute entity angle if any target is found
            Entity aimTarget = currentTarget;
            float targetYaw = playerYaw;
            float targetPitch = playerPitch;
            float screenAngle = Float.MAX_VALUE;
            if (aimTarget != null) {
                // Calculate actual yaw/pitch to entity
                double dx = aimTarget.getX() - player.getX();
                double dz = aimTarget.getZ() - player.getZ();
                double dy = (aimTarget.getY() + aimTarget.getStandingEyeHeight()) - (player.getY() + player.getStandingEyeHeight());

                targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0F);
                double dist = Math.sqrt(dx * dx + dz * dz);
                targetPitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));

                // Compute angular distance for anticipation
                float dyaw = ((targetYaw - playerYaw + 540f) % 360f) - 180f;
                float dpitch = targetPitch - playerPitch;
                screenAngle = (float) Math.sqrt(dyaw * dyaw + dpitch * dpitch);
            }

            long now = System.currentTimeMillis();

            // --- Anticipation logic with retrigger suppression and pending timeout ---
            if (aimTarget != null) {
                if (!anticipationActive && lastScreenAngle > PREDICT_ANGLE && screenAngle < PREDICT_ANGLE) {
                    anticipationActive = true;
                    predictedAcquiredTime = now;
                }
                if (anticipationActive && screenAngle < ACTUAL_HIT_ANGLE && !reactionPending) {
                    int[] bounds = nextScatteredReactionBounds(); // e.g. [30,50] or [0,20], etc.
                    attackDelayThisTime = bounds[0] + random.nextInt(bounds[1] - bounds[0] + 1);
                    targetAcquiredTime = predictedAcquiredTime;
                    attackReadyTime = targetAcquiredTime + attackDelayThisTime;
                    reactionPending = true;
                    reactionPendingStarted = now;
                    anticipationActive = false;
                }
                if (anticipationActive && screenAngle >= PREDICT_ANGLE) {
                    lastLeftPredictionWindow = now;
                }
                if (anticipationActive && now - lastLeftPredictionWindow > ANTICIPATION_FORGIVENESS_MS) {
                    anticipationActive = false;
                }
                // Timeout reactionPending if not fired in time (e.g. target lost)
                if (reactionPending && now - reactionPendingStarted > REACTION_PENDING_TIMEOUT_MS) {
                    reactionPending = false;
                }
            } else {
                anticipationActive = false;
                // Don't clear reactionPending here; let timeout handle it
            }
            lastScreenAngle = screenAngle;

            // -- No aim movement or jitter applied here --

            // Track if the enemy hit me: detect recent damage taken
            if (player.hurtTime > 0) {
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = now;
                inRecentlyHitDelayWindow = true;
                recentlyHitWindowStart = now;
            } else {
                if (inRecentlyHitDelayWindow && now - recentlyHitWindowStart > RECENTLY_HIT_WINDOW_MS) {
                    inRecentlyHitDelayWindow = false;
                }
                if (enemyRecentlyHitMe && now - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            // Post-eat/use delays
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = now;
                nextAllowedPostEatAttack = finishedEatOrUseTime + nextHumanDelay(70, 80);
                return;
            }
            if (postEatDelayActive) {
                if (now < nextAllowedPostEatAttack) {
                    return;
                } else {
                    postEatDelayActive = false;
                }
            }

            // Only attack if holding a sword
            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                resetState();
                return;
            }

            float cooldown = player.getAttackCooldownProgress(0.5F);
            if (cooldown < 0.86f) {
                hasAttackedThisCooldown = false;
            }

            boolean canAttack = true;

            // --- Attack logic for air/ground with anticipation gating ---
            boolean anticipationElapsed = reactionPending && now >= attackReadyTime;

            if (aimTarget != null && !player.isOnGround() && player.getVelocity().y < -0.08) {
                if (cooldown < 0.86f) {
                    hasAttackedThisCooldown = false;
                    return;
                }
                if (hasAttackedThisCooldown) return;
                if (!canAttack) return;
                if (!anticipationElapsed) return;

                if (airReactionPending) {
                    if (now < airTargetAcquiredTime + airTargetReactionDelay) {
                        return;
                    } else {
                        airReactionPending = false;
                    }
                }

                double cooldownPercent = 0.86 + (random.nextDouble() * 0.14);
                long minCooldown = (long)((lastAttackDelay > 0 ? lastAttackDelay : 100) * cooldownPercent);
                if (now - lastAttackTime < minCooldown) {
                    return;
                }
                if (now >= nextAllowedAirAttack) {
                    long jumpDelay = nextCustomJumpDelay(aimTarget);
                    lastAirDelay = jumpDelay;
                    lastAttackDelay = jumpDelay;
                    nextAllowedAirAttack = now + jumpDelay;
                    performDoAttack(client);
                    lastAttackTime = now;
                    hasAttackedThisCooldown = true;
                    reactionPending = false;
                }
            } else if (aimTarget != null && player.isOnGround()) {
                if (cooldown < 0.86f) {
                    hasAttackedThisCooldown = false;
                    return;
                }
                if (hasAttackedThisCooldown) return;
                if (!canAttack) return;
                if (!anticipationElapsed) return;

                long groundDelay;
                if (inRecentlyHitDelayWindow) {
                    groundDelay = nextCustomGroundDelay(true);
                } else {
                    groundDelay = nextCustomGroundDelay(false);
                }
                lastGroundDelay = groundDelay;
                lastAttackDelay = groundDelay;
                nextAllowedGroundAttack = now + groundDelay;
                performDoAttack(client);
                lastAttackTime = now;
                hasAttackedThisCooldown = true;
                reactionPending = false;
            }
        });
    }

    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }

    // --- Human delay helpers, delays, and anti-cheat ground/air attacks ---
    private long nextHumanDelay(int min, int max) {
        double logMin = Math.log(Math.max(min, 1));
        double logMax = Math.log(max);
        double muBase = (logMin + logMax) / 2.0;
        double sigmaBase = (logMax - logMin) / 6.0;

        double mu = muBase + (random.nextDouble() - 0.5) * 0.20;
        double sigma = sigmaBase * (0.85 + random.nextDouble() * 0.4);

        if (random.nextDouble() < 0.05) return min + random.nextInt((max - min) + 1);
        if (random.nextDouble() < 0.05) {
            long a = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
            long b = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
            long sample = (a + b) / 2;
            return Math.max(min, Math.min(max, sample));
        }

        long result = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
        return Math.max(min, Math.min(max, result));
    }

    private long mixedDelay(long previousDelay, int min, int max) {
        double typeRoll = random.nextDouble();
        if (typeRoll < 0.6) {
            double logMin = Math.log(Math.max(min, 1));
            double logMax = Math.log(Math.max(max, min + 1));
            double mu = (logMin + logMax) / 2.0;
            double sigma = (logMax - logMin) / 3.0;
            long delay = (long) Math.exp(mu + sigma * random.nextGaussian());
            if (previousDelay > 0) delay = (long) (0.7 * delay + 0.3 * previousDelay);
            delay += random.nextInt(11) - 5;
            return Math.max(min, Math.min(max, delay));
        } else if (typeRoll < 0.9) {
            return min + random.nextInt(max - min + 1);
        } else {
            int mid = (min + max) / 2;
            int range = (max - min) / 10;
            if (random.nextBoolean()) {
                int upper = mid - range;
                return min + random.nextInt(Math.max(1, upper - min + 1));
            } else {
                int lower = mid + range;
                return lower + random.nextInt(Math.max(1, max - lower + 1));
            }
        }
    }

    private long nextCustomGroundDelay(boolean recentlyHit) {
        int roll = random.nextInt(100);
        if (recentlyHit) {
            if (roll < 90) return mixedDelay(lastGroundDelay, 580, 630);
            else if (roll < 95) return mixedDelay(lastGroundDelay, 635, 650);
            else return mixedDelay(lastGroundDelay, 550, 579);
        } else {
            if (roll < 90) return mixedDelay(lastGroundDelay, 550, 579);
            else if (roll < 95) return mixedDelay(lastGroundDelay, 520, 549);
            else return mixedDelay(lastGroundDelay, 635, 650);
        }
    }

    private long nextCustomJumpDelay(Entity target) {
        boolean targetIsEating = false;
        if (target instanceof PlayerEntity) targetIsEating = ((PlayerEntity)target).isUsingItem();
        int roll = random.nextInt(100);
        if (targetIsEating) {
            if (roll < 60) return mixedDelay(lastAirDelay, 390, 450);
            else return mixedDelay(lastAirDelay, 451, 520);
        } else {
            if (roll < 70) return mixedDelay(lastAirDelay, 341, 360);
            else if (roll < 90) return mixedDelay(lastAirDelay, 314, 319);
            else if (roll < 95) return mixedDelay(lastAirDelay, 361, 420);
            else return mixedDelay(lastAirDelay, 421, 480);
        }
    }

    // --- Scattered anticipation reaction delay bounds ---
    private int[] nextScatteredReactionBounds() {
        double roll = random.nextDouble();
        if (roll < 0.025) {
            // 2.5% super fast
            return new int[]{0, 20};
        } else if (roll < 0.05) {
            // 2.5% slow blink
            return new int[]{50, 80};
        } else {
            // 95% normal
            return new int[]{30, 50};
        }
    }

    // --- Helpers ---
    private void resetState() {
        wasEatingOrUsing = false;
        postEatDelayActive = false;
        finishedEatOrUseTime = 0L;
        lastTarget = null;
        reactionPending = false;
        airReactionPending = false;
        anticipationActive = false;
        predictedAcquiredTime = 0L;
        lastLeftPredictionWindow = 0L;
        lastScreenAngle = Float.MAX_VALUE;
        reactionPendingStarted = 0L;
        attackDelayThisTime = 0;
        attackReadyTime = 0L;
        enemyRecentlyHitMe = false;
        lastEnemyAttackTime = 0L;
        inRecentlyHitDelayWindow = false;
        recentlyHitWindowStart = 0L;
        nextAllowedGroundAttack = 0L;
        nextAllowedAirAttack = 0L;
        nextAllowedPostEatAttack = 0L;
        lastGroundDelay = 0L;
        lastAirDelay = 0L;
        lastAttackDelay = 0L;
        hasAttackedThisCooldown = false;
    }
}