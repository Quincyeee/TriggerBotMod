package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer; import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents; import net.minecraft.client.MinecraftClient; import net.minecraft.client.network.ClientPlayerEntity; import net.minecraft.entity.Entity; import net.minecraft.entity.player.PlayerEntity; import net.minecraft.item.ItemStack; import net.minecraft.util.Hand; import org.lwjgl.glfw.GLFW;

import java.util.Random; import java.util.concurrent.Executors; import java.util.concurrent.ScheduledExecutorService; import java.util.concurrent.TimeUnit;

public class HappyClient implements ClientModInitializer {

private boolean modEnabled = false;
private boolean prevAltPressed = false;

private long lastGroundAttackTime = 0L;
private long lastAirAttackTime = 0L;
private long lastTargetChangeTime = 0L;
private long scheduledPostEatAttackTime = 0L;

private boolean wasEatingOffhand = false;
private boolean postEatDelayActive = false;

private int lastTargetId = -1;
private boolean targetPreviouslyInCrosshair = false;

private static final Random random = new Random();
private static final float COOLDOWN_THRESHOLD = 0.86f;

// Single-threaded scheduler for sub-tick timing
private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

@Override
public void onInitializeClient() {
    WorldRenderEvents.END.register(context -> {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;
        if (client.currentScreen != null) return;

        long now = System.currentTimeMillis();
        long window = client.getWindow().getHandle();
        boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

        if (altPressed && !prevAltPressed) modEnabled = !modEnabled;
        prevAltPressed = altPressed;

        if (!modEnabled) {
            resetAll();
            return;
        }

        handlePostEatDelay(client, now);
        if (postEatDelayActive || client.player.isUsingItem()) return;

        ItemStack main = client.player.getMainHandStack();
        if (!isSword(main)) {
            resetTargeting();
            return;
        }

        Entity target = client.targetedEntity;
        float cooldown = client.player.getAttackCooldownProgress(0.0f);
        boolean valid = target instanceof PlayerEntity && target != client.player;
        boolean isNew = valid && (target.getId() != lastTargetId || !targetPreviouslyInCrosshair);
        if (isNew) lastTargetChangeTime = now;

        if (valid) {
            if (client.player.isOnGround()) {
                handleGroundAttack(client, now, cooldown, isNew);
            } else if (client.player.getVelocity().y < -0.08) {
                handleAirAttack(client, now, cooldown, isNew, (PlayerEntity) target);
            }
        } else {
            resetGroundAir();
        }

        updateTargetState(valid, target);
    });
}

private void handleGroundAttack(MinecraftClient client, long now, float cooldown, boolean isNew) {
    if (cooldown < COOLDOWN_THRESHOLD) return;

    long totalDelay;
    if (isNew) {
        totalDelay = sampleReactionDelay();
        lastTargetChangeTime = now;
    } else {
        totalDelay = sampleGroundDelay();
    }
    long scheduledTime = now + totalDelay;

    scheduler.schedule(() -> {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.execute(mc::doAttack);
    }, totalDelay, TimeUnit.MILLISECONDS);

    lastGroundAttackTime = scheduledTime;
}

private void handleAirAttack(MinecraftClient client, long now, float cooldown,
                             boolean isNew, PlayerEntity target) {
    if (cooldown < COOLDOWN_THRESHOLD) return;

    long totalDelay;
    if (isNew) {
        totalDelay = sampleReactionDelay();
        lastTargetChangeTime = now;
    } else {
        totalDelay = sampleAirDelay(target.isUsingItem());
    }
    long scheduledTime = now + totalDelay;

    scheduler.schedule(() -> {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.execute(mc::doAttack);
    }, totalDelay, TimeUnit.MILLISECONDS);

    lastAirAttackTime = scheduledTime;
}

private void handlePostEatDelay(MinecraftClient client, long now) {
    ClientPlayerEntity player = client.player;
    boolean eatingOff = player.getOffHandStack().isFood()
                        && player.isUsingItem()
                        && player.getActiveHand() == Hand.OFF_HAND;
    if (eatingOff) {
        wasEatingOffhand = true;
        postEatDelayActive = false;
        return;
    }
    if (wasEatingOffhand) {
        wasEatingOffhand = false;
        postEatDelayActive = true;
        scheduledPostEatAttackTime = now + (65 + random.nextInt(6));
        return;
    }
    if (postEatDelayActive && now < scheduledPostEatAttackTime) return;
    postEatDelayActive = false;
}

private int sampleTruncatedNormal(int min, int max, double mean, double stddev) {
    int value;
    do {
        value = (int) Math.round(mean + stddev * random.nextGaussian());
    } while (value < min || value > max);
    return value;
}

private int sampleGroundDelay() {
    int roll = random.nextInt(1000);
    if (roll < 5)    return sampleTruncatedNormal(520, 589, 554.5, 15);
    if (roll > 994)  return sampleTruncatedNormal(636, 650, 643, 5);
    return sampleTruncatedNormal(590, 635, 612.5, 10);
}

private int sampleAirDelay(boolean eating) {
    return eating
        ? sampleTruncatedNormal(361, 420, 390.5, 14)
        : sampleTruncatedNormal(325, 360, 342.5, 10);
}

private int sampleReactionDelay() {
    return sampleTruncatedNormal(0, 5, 2, 1);
}

private boolean isSword(ItemStack stack) {
    return switch (stack.getItem().toString()) {
        case "minecraft:wooden_sword", "minecraft:stone_sword", "minecraft:iron_sword",
             "minecraft:golden_sword", "minecraft:diamond_sword", "minecraft:netherite_sword" -> true;
        default -> false;
    };
}

private void resetAll() {
    lastGroundAttackTime = lastAirAttackTime = lastTargetChangeTime
                         = scheduledPostEatAttackTime = 0L;
    wasEatingOffhand = postEatDelayActive = false;
    lastTargetId = -1;
    targetPreviouslyInCrosshair = false;
}

private void resetTargeting() {
    lastGroundAttackTime = lastAirAttackTime = 0L;
    lastTargetId = -1;
    targetPreviouslyInCrosshair = false;
}

private void resetGroundAir() {
    lastGroundAttackTime = lastAirAttackTime = 0L;
}

private void updateTargetState(boolean valid, Entity target) {
    if (valid) {
        lastTargetId = target.getId();
        targetPreviouslyInCrosshair = true;
    } else {
        lastTargetId = -1;
        targetPreviouslyInCrosshair = false;
    }
}

}

