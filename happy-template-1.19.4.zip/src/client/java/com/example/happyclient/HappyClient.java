package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final Random random = new Random();

    // --- Human RT GMM (fit these to real data for best results!) ---
    private static final double[] GMM_MEANS = {240, 320, 430};
    private static final double[] GMM_STDS = {18, 30, 45};
    private static final double[] GMM_WEIGHTS = {0.45, 0.45, 0.10};

    // --- Weibull & AR(1) state ---
    private double currentK = 1.1;
    private int clicksSinceKChange = 0;
    private double prevSlowAR = 500, prevFastAR = 500;
    private long sessionStartTime = System.currentTimeMillis();

    private boolean modEnabled = false;
    private boolean prevAltPressed = false;
    private Entity lastTarget = null;
    private boolean hasAttackedThisCooldown = false;

    private boolean wasEatingOrUsing = false;
    private boolean postEatDelayActive = false;
    private long finishedEatOrUseTime = 0L;
    private long lastAttackTime = 0L;
    private long nextAllowedGroundAttack = 0L;
    private long nextAllowedAirAttack = 0L;
    private long nextAllowedPostEatAttack = 0L;
    private long lastGroundDelay = 540;
    private long lastAirDelay = 400;
    private long lastAttackDelay = 0L;

    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private boolean inRecentlyHitDelayWindow = false;
    private long recentlyHitWindowStart = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200;
    private static final long RECENTLY_HIT_WINDOW_MS = 700L;

    private boolean pendingJitterAttack = false;
    private long jitterScheduledAttackTime = 0L;
    private MinecraftClient jitterScheduledAttackClient = null;

    // For first attack reaction time (ground or air descent)
    private boolean awaitingFirstAttack = false;
    private long firstAttackScheduledTime = 0L;
    private MinecraftClient firstAttackClient = null;
    private Entity firstAttackTarget = null;

    @Override
    public void onInitializeClient() {
        sessionStartTime = System.currentTimeMillis();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                resetState();
                return;
            }

            ClientPlayerEntity player = client.player;

            // Detect crosshair target
            Entity currentTarget = null;
            if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                EntityHitResult entityHit = (EntityHitResult) client.crosshairTarget;
                Entity entity = entityHit.getEntity();
                if (entity instanceof PlayerEntity) {
                    currentTarget = entity;
                }
            }

            long now = System.currentTimeMillis();

            // --- Fire any pending first attack (ground or descent) ---
            if (awaitingFirstAttack && now >= firstAttackScheduledTime) {
                if (firstAttackClient != null &&
                    client.crosshairTarget != null &&
                    client.crosshairTarget.getType() == HitResult.Type.ENTITY &&
                    ((EntityHitResult)client.crosshairTarget).getEntity() == firstAttackTarget) {
                    performDoAttack(firstAttackClient);
                    hasAttackedThisCooldown = true;
                    lastAttackTime = now;
                }
                awaitingFirstAttack = false;
                firstAttackClient = null;
                firstAttackTarget = null;
            }

            // --- Fire any pending jittered attack ---
            if (pendingJitterAttack && now >= jitterScheduledAttackTime) {
                if (jitterScheduledAttackClient != null) {
                    performDoAttack(jitterScheduledAttackClient);
                    hasAttackedThisCooldown = true;
                    lastAttackTime = now;
                }
                pendingJitterAttack = false;
            }

            // Track if the enemy hit me: detect recent damage taken
            if (player.hurtTime > 0) {
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = now;
                inRecentlyHitDelayWindow = true;
                recentlyHitWindowStart = now;
            } else {
                if (inRecentlyHitDelayWindow && now - recentlyHitWindowStart > RECENTLY_HIT_WINDOW_MS) {
                    inRecentlyHitDelayWindow = false;
                }
                if (enemyRecentlyHitMe && now - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            // Post-eat/use delays
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = now;
                nextAllowedPostEatAttack = finishedEatOrUseTime + nextHumanLikeDelay(70, 80, false, false, false, 0);
                return;
            }
            if (postEatDelayActive) {
                if (now < nextAllowedPostEatAttack) {
                    return;
                } else {
                    postEatDelayActive = false;
                }
            }

            // Only attack if holding a sword
            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                    main.getItem() == Items.STONE_SWORD ||
                    main.getItem() == Items.IRON_SWORD ||
                    main.getItem() == Items.GOLDEN_SWORD ||
                    main.getItem() == Items.DIAMOND_SWORD ||
                    main.getItem() == Items.NETHERITE_SWORD)) {
                resetState();
                return;
            }

            float cooldown = player.getAttackCooldownProgress(0.5F);
            if (cooldown < 0.86f) {
                hasAttackedThisCooldown = false;
            }

            boolean canAttack = true;

            if (currentTarget != null && currentTarget instanceof PlayerEntity) {
                boolean inDescent = !player.isOnGround() && player.getVelocity().y < -0.08;
                boolean onGround = player.isOnGround();

                // --- Fast first attack for new target if on ground or descending ---
                if (lastTarget != currentTarget) {
                    if (inDescent || onGround) {
                        if (!awaitingFirstAttack) {
                            long reactionDelay = nextHumanLikeFirstAttackDelay(26, 55);
                            firstAttackScheduledTime = now + reactionDelay;
                            firstAttackClient = client;
                            firstAttackTarget = currentTarget;
                            awaitingFirstAttack = true;
                            lastTarget = currentTarget;
                            return;
                        }
                    }
                }

                // --- After first attack, use normal delays per state ---
                if (inDescent && !awaitingFirstAttack) {
                    if (cooldown < 0.86f) {
                        hasAttackedThisCooldown = false;
                        return;
                    }
                    if (hasAttackedThisCooldown) return;
                    if (!canAttack) return;

                    long delay;
                    boolean targetIsEating = ((PlayerEntity) currentTarget).isUsingItem();
                    if (targetIsEating) {
                        delay = nextHumanLikeDelay(390, 520, false, false, true, 0);
                    } else {
                        delay = nextHumanLikeDelay(314, 520, false, false, false, 0);
                    }
                    scheduleJitteredAttack(client, delay);
                    lastAirDelay = delay;
                    lastAttackDelay = delay;
                    nextAllowedAirAttack = now + delay;
                } else if (onGround && !awaitingFirstAttack) {
                    if (cooldown < 0.86f) {
                        hasAttackedThisCooldown = false;
                        return;
                    }
                    if (hasAttackedThisCooldown) return;
                    if (!canAttack) return;

                    long delay;
                    if (inRecentlyHitDelayWindow) {
                        delay = nextHumanLikeDelay(580, 650, true, false, false, 0);
                    } else {
                        delay = nextHumanLikeDelay(520, 579, false, false, false, 0);
                    }
                    scheduleJitteredAttack(client, delay);
                    lastGroundDelay = delay;
                    lastAttackDelay = delay;
                    nextAllowedGroundAttack = now + delay;
                }
            }
            lastTarget = currentTarget;
        });
    }

    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }

    private long nextHumanLikeDelay(int min, int max, boolean recentlyHit, boolean postEat, boolean eating, int comboCount) {
        clicksSinceKChange++;
        if (clicksSinceKChange >= 5 + random.nextInt(6)) {
            currentK = 0.7 + random.nextDouble() * (1.6 - 0.7);
            clicksSinceKChange = 0;
        }
        double baseLambda = (min + max) / 2.0;
        long minutes = (System.currentTimeMillis() - sessionStartTime) / 60000;
        double drift = (random.nextDouble() - 0.5) * 20 * minutes;
        double lambda = Math.max(30, baseLambda + drift);

        double delay;
        if (random.nextDouble() < 0.15) {
            delay = sampleGMMHumanRT();
        } else {
            double u = random.nextDouble();
            delay = lambda * Math.pow(-Math.log(1 - u), 1.0 / currentK);
        }

        double slowAlpha = 0.2, fastAlpha = 0.8;
        prevSlowAR = slowAlpha * delay + (1 - slowAlpha) * prevSlowAR;
        prevFastAR = fastAlpha * delay + (1 - fastAlpha) * prevFastAR;
        delay = 0.5 * prevSlowAR + 0.5 * prevFastAR;

        delay = Math.max(min, Math.min(max, delay));
        return (long) Math.round(delay);
    }

    private long nextHumanLikeFirstAttackDelay(int min, int max) {
        clicksSinceKChange++;
        if (clicksSinceKChange >= 5 + random.nextInt(6)) {
            currentK = 0.7 + random.nextDouble() * (1.6 - 0.7);
            clicksSinceKChange = 0;
        }
        double baseLambda = (min + max) / 2.0;
        long minutes = (System.currentTimeMillis() - sessionStartTime) / 60000;
        double drift = (random.nextDouble() - 0.5) * 4 * minutes; // ±2ms/minute
        double lambda = Math.max(5, baseLambda + drift);

        double delay;
        if (random.nextDouble() < 0.15) {
            delay = sampleGMMFirstAttack();
        } else {
            double u = random.nextDouble();
            delay = lambda * Math.pow(-Math.log(1 - u), 1.0 / currentK);
        }

        double slowAlpha = 0.2, fastAlpha = 0.8;
        prevSlowAR = slowAlpha * delay + (1 - slowAlpha) * prevSlowAR;
        prevFastAR = fastAlpha * delay + (1 - fastAlpha) * prevFastAR;
        delay = 0.5 * prevSlowAR + 0.5 * prevFastAR;

        delay = Math.max(min, Math.min(max, delay));
        return (long) Math.round(delay);
    }

    private double sampleGMMFirstAttack() {
        double[] means = {30, 36, 42};
        double[] stds = {2, 3, 5};
        double[] weights = {0.45, 0.45, 0.10};
        double r = random.nextDouble();
        int which = 0;
        if (r < weights[0]) which = 0;
        else if (r < weights[0] + weights[1]) which = 1;
        else which = 2;
        return means[which] + stds[which] * random.nextGaussian();
    }

    private double sampleGMMHumanRT() {
        double r = random.nextDouble();
        int which = 0;
        if (r < GMM_WEIGHTS[0]) which = 0;
        else if (r < GMM_WEIGHTS[0] + GMM_WEIGHTS[1]) which = 1;
        else which = 2;
        return GMM_MEANS[which] + GMM_STDS[which] * random.nextGaussian();
    }

    private void scheduleJitteredAttack(MinecraftClient client, long intendedDelay) {
        int tickJitter = -2 + random.nextInt(5);
        int msJitter = random.nextInt(18);
        long jitter = tickJitter * 50L + msJitter;
        long now = System.currentTimeMillis();
        jitterScheduledAttackTime = now + intendedDelay + jitter;
        jitterScheduledAttackClient = client;
        pendingJitterAttack = true;
    }

    private void resetState() {
        wasEatingOrUsing = false;
        postEatDelayActive = false;
        finishedEatOrUseTime = 0L;
        lastTarget = null;
        enemyRecentlyHitMe = false;
        lastEnemyAttackTime = 0L;
        inRecentlyHitDelayWindow = false;
        recentlyHitWindowStart = 0L;
        nextAllowedGroundAttack = 0L;
        nextAllowedAirAttack = 0L;
        nextAllowedPostEatAttack = 0L;
        lastGroundDelay = 540;
        lastAirDelay = 400;
        lastAttackDelay = 0L;
        hasAttackedThisCooldown = false;
        currentK = 1.1;
        clicksSinceKChange = 0;
        prevSlowAR = 500;
        prevFastAR = 500;
        sessionStartTime = System.currentTimeMillis();
        pendingJitterAttack = false;
        jitterScheduledAttackTime = 0L;
        jitterScheduledAttackClient = null;
        awaitingFirstAttack = false;
        firstAttackScheduledTime = 0L;
        firstAttackClient = null;
        firstAttackTarget = null;
    }
}