package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;
import java.util.Arrays;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;
    private static final Random random = new Random();

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating/use tracking
    private boolean wasEatingOrUsing = false;
    private long finishedEatOrUseTime = 0L;
    private boolean postEatDelayActive = false;

    // Track target transitions for "first see" logic
    private Entity lastTarget = null;

    // --- NEW FIELDS FOR REACTION DELAY ---
    private long targetAcquiredTime = 0L;
    private long targetReactionDelay = 0L;      // in milliseconds
    private boolean reactionPending = false;

    // Track if the enemy has recently hit the player
    private boolean enemyRecentlyHitMe = false;
    private long lastEnemyAttackTime = 0L;
    private static final long ENEMY_ATTACK_MEMORY_MS = 1200;
    // --- For custom "recently hit me" ground delay ---
    private boolean inRecentlyHitDelayWindow = false;
    private long recentlyHitWindowStart = 0L;
    private static final long RECENTLY_HIT_WINDOW_MS = 700L;

    // Attack timers for ground and air delays, and post-eat/use delay
    private long nextAllowedGroundAttack = 0L;
    private long nextAllowedAirAttack = 0L;
    private long nextAllowedPostEatAttack = 0L;

    // --- Human-like randomization state ---
    private long lastGroundDelay = 0L;
    private long lastAirDelay = 0L;

    // --- For cooldown %
    private long lastAttackDelay = 0L;

    // --- Aim jitter state ---
    private float lastSentYaw = Float.NaN;
    private float lastSentPitch = Float.NaN;
    private int jitterTickCounter = 0;
    private int jitterNonIdenticalTicks = 0;
    private static final int BASE_JITTER_WINDOW = 45;
    private int jitterWindow = BASE_JITTER_WINDOW + random.nextInt(8) - 4; // 41–49

    // --- Angle/attack anti-GrimAC logic ---
    private int smallJitterStreak = 0;
    private int maxSmallJitterStreak = 3 + random.nextInt(4); // 3–6
    private static final int BASE_MAX_SMALL_STREAK = 4;

    // --- AimModulo360 enforce-variance logic ---
    // PATCH: wider, more aggressive window randomization, forced flicks, and microflicks
    private static final int BASE_WINDOW_SIZE = 45;
    private int windowSize = 35 + random.nextInt(26); // 35–60 (wider)
    private float[] deltaYawWindow = new float[60]; // longer buffer for window randomization
    private float[] deltaPitchWindow = new float[60];
    private int windowIndex = 0;
    private boolean forceBigFlickNextTick = false;

    // --- Reaction time logic for tracking
    private float lastYaw = Float.NaN;
    private float lastPitch = Float.NaN;
    private boolean lastHadTarget = false;
    private int nearTargetCount = 0;

    // --- New: Only attack once per cooldown window ---
    private boolean hasAttackedThisCooldown = false;

    // --- Reaction tracking for air attacks ---
    private long airTargetAcquiredTime = 0L;
    private long airTargetReactionDelay = 0L;
    private boolean airReactionPending = false;

    // --- Snap interpolation fields ---
    private boolean snapInterpolating = false;
    private float snapStartYaw = 0f, snapStartPitch = 0f;
    private float snapEndYaw = 0f, snapEndPitch = 0f;
    private long snapStartTime = 0L;
    private long snapDuration = 0L;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                wasEatingOrUsing = false;
                postEatDelayActive = false;
                finishedEatOrUseTime = 0L;
                lastTarget = null;
                reactionPending = false;
                airReactionPending = false;
                enemyRecentlyHitMe = false;
                lastEnemyAttackTime = 0L;
                inRecentlyHitDelayWindow = false;
                recentlyHitWindowStart = 0L;
                nextAllowedGroundAttack = 0L;
                nextAllowedAirAttack = 0L;
                nextAllowedPostEatAttack = 0L;
                lastGroundDelay = 0L;
                lastAirDelay = 0L;
                lastAttackDelay = 0L;
                lastSentYaw = Float.NaN;
                lastSentPitch = Float.NaN;
                jitterTickCounter = 0;
                jitterNonIdenticalTicks = 0;
                smallJitterStreak = 0;
                maxSmallJitterStreak = 3 + random.nextInt(4);
                jitterWindow = BASE_JITTER_WINDOW + random.nextInt(8) - 4;
                for (int i = 0; i < deltaYawWindow.length; i++) {
                    deltaYawWindow[i] = 0f;
                    deltaPitchWindow[i] = 0f;
                }
                windowIndex = 0;
                windowSize = 35 + random.nextInt(26);
                forceBigFlickNextTick = false;
                lastYaw = Float.NaN;
                lastPitch = Float.NaN;
                lastHadTarget = false;
                nearTargetCount = 0;
                hasAttackedThisCooldown = false;
                snapInterpolating = false;
                return;
            }

            ClientPlayerEntity player = client.player;

            // === Use Minecraft's built-in crosshairTarget for triggerbot ===
            Entity currentTarget = null;
            if (client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                EntityHitResult entityHit = (EntityHitResult) client.crosshairTarget;
                Entity entity = entityHit.getEntity();
                if (entity instanceof PlayerEntity) {
                    currentTarget = entity;
                }
            }

            // === Snap interpolation logic: If in interpolation, override aim until done ===
            if (snapInterpolating) {
                long now = System.currentTimeMillis();
                float progress = Math.min(1f, (float)(now - snapStartTime) / (float)Math.max(1, snapDuration));
                float interpYaw = lerpYaw(snapStartYaw, snapEndYaw, progress);
                float interpPitch = lerp(snapStartPitch, snapEndPitch, progress);
                player.setYaw(interpYaw);
                player.setPitch(interpPitch);

                // Only allow attack after interpolation is nearly complete
                if (progress >= 0.97f) {
                    snapInterpolating = false;
                }
            }

            // Save old yaw/pitch before jitter (for Δ computation)
            float prevYaw = player.getYaw();
            float prevPitch = player.getPitch();

            // --- PATCH: Apply aim jitter with humanized streaks and window sizes ---
            applyAimJitter(player);

            float newYaw = player.getYaw();
            float newPitch = player.getPitch();

            // Track Δyaw, Δpitch in ring buffer
            float deltaYaw = Math.abs(((newYaw - prevYaw + 540) % 360) - 180);
            float deltaPitch = Math.abs(((newPitch - prevPitch + 540) % 360) - 180);

            deltaYawWindow[windowIndex] = deltaYaw;
            deltaPitchWindow[windowIndex] = deltaPitch;
            windowIndex = (windowIndex + 1) % windowSize;

            // PATCH: More aggressive window randomization, forced flicks, and microflicks
            int smallYaw = 0, smallPitch = 0;
            for (int i = 0; i < windowSize; i++) {
                if (deltaYawWindow[i] < 0.02f) smallYaw++;
                if (deltaPitchWindow[i] < 0.02f) smallPitch++;
            }
            // If too many small deltas, force a flick (and reset window/buffer with some chance)
            if ((smallYaw >= windowSize - 5 || smallPitch >= windowSize - 5)) {
                if (random.nextDouble() < 0.2) {
                    forceBigFlickNextTick = true;
                    // Also reroll windowSize and zero buffer
                    windowSize = 35 + random.nextInt(26);
                    Arrays.fill(deltaYawWindow, 0f);
                    Arrays.fill(deltaPitchWindow, 0f);
                    windowIndex = 0;
                } else {
                    forceBigFlickNextTick = true;
                }
            }

            // Randomly reset the window and size more frequently
            if (random.nextDouble() < 0.01) { // 1% chance each tick
                Arrays.fill(deltaYawWindow, 0f);
                Arrays.fill(deltaPitchWindow, 0f);
                windowIndex = 0;
                windowSize = 35 + random.nextInt(26); // 35–60
            }

            // PATCH: Occasionally insert a micro-flick if buffer is too quiet
            int verySmallYaw = 0, verySmallPitch = 0;
            for (int i = 0; i < windowSize; i++) {
                if (deltaYawWindow[i] < 0.02f) verySmallYaw++;
                if (deltaPitchWindow[i] < 0.02f) verySmallPitch++;
            }
            if ((verySmallYaw > windowSize - 10 || verySmallPitch > windowSize - 10) && random.nextDouble() < 0.02) {
                // Insert micro-flick next tick
                forceBigFlickNextTick = true;
            }

            // Track if the enemy hit me: detect recent damage taken
            if (player.hurtTime > 0) {
                enemyRecentlyHitMe = true;
                lastEnemyAttackTime = System.currentTimeMillis();
                inRecentlyHitDelayWindow = true;
                recentlyHitWindowStart = System.currentTimeMillis();
            } else {
                // Only keep "recently hit" window for 700ms after last hit, then switch back to "otherwise"
                if (inRecentlyHitDelayWindow && System.currentTimeMillis() - recentlyHitWindowStart > RECENTLY_HIT_WINDOW_MS) {
                    inRecentlyHitDelayWindow = false;
                }
                // Also, if general "recently hit" expires (for other purposes)
                if (enemyRecentlyHitMe && System.currentTimeMillis() - lastEnemyAttackTime > ENEMY_ATTACK_MEMORY_MS) {
                    enemyRecentlyHitMe = false;
                }
            }

            // Don't do anything while eating or using an item in either hand (self!)
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }

            // If just finished eating/using, start the delay (self!)
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = System.currentTimeMillis();
                nextAllowedPostEatAttack = finishedEatOrUseTime + nextHumanDelay(70, 80);
                return;
            }

            // If in post-eat/use delay, skip until timer expires
            if (postEatDelayActive) {
                long now = System.currentTimeMillis();
                if (now < nextAllowedPostEatAttack) {
                    return;
                } else {
                    postEatDelayActive = false;
                }
            }

            // Don't attack if not holding a sword
            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                lastTarget = null;
                reactionPending = false;
                airReactionPending = false;
                lastYaw = player.getYaw();
                lastPitch = player.getPitch();
                lastHadTarget = false;
                nearTargetCount = 0;
                hasAttackedThisCooldown = false;
                inRecentlyHitDelayWindow = false;
                recentlyHitWindowStart = 0L;
                snapInterpolating = false;
                return;
            }

            // --- Reaction time logic based on snap/tracking ---
            float currentYaw = player.getYaw();
            float currentPitch = player.getPitch();
            boolean justAcquiredTarget = (currentTarget != null && currentTarget != lastTarget);
            float yawDelta = Float.isNaN(lastYaw) ? 0f : computeAngularDelta(lastYaw, currentYaw);
            float pitchDelta = Float.isNaN(lastPitch) ? 0f : computeAngularDelta(lastPitch, currentPitch);
            boolean farSnap = (justAcquiredTarget && (Math.abs(yawDelta) > 10f || Math.abs(pitchDelta) > 10f));
            boolean nearTracking = false;

            if (currentTarget != null && lastHadTarget) {
                if (Math.abs(yawDelta) < 3f && Math.abs(pitchDelta) < 3f) {
                    nearTargetCount++;
                    if (nearTargetCount >= 3) {
                        nearTracking = true;
                    }
                } else {
                    nearTargetCount = 0;
                }
            } else {
                nearTargetCount = 0;
            }

            // --- Updated snap reaction delays and snap interpolation ---
            if (justAcquiredTarget) {
                targetAcquiredTime = System.currentTimeMillis();
                airTargetAcquiredTime = targetAcquiredTime;
                // Pick new target snap destination
                snapStartYaw = lastYaw;
                snapStartPitch = lastPitch;
                snapEndYaw = currentYaw;
                snapEndPitch = currentPitch;
                snapStartTime = targetAcquiredTime;
                if (farSnap) {
                    double rand = random.nextDouble();
                    if (rand < 0.9) {
                        targetReactionDelay = nextHumanDelay(60, 70);
                        airTargetReactionDelay = targetReactionDelay;
                    } else {
                        targetReactionDelay = nextHumanDelay(71, 80);
                        airTargetReactionDelay = targetReactionDelay;
                    }
                } else {
                    double rand = random.nextDouble();
                    if (rand < 0.01) {
                        targetReactionDelay = nextHumanDelay(20, 30);
                        airTargetReactionDelay = targetReactionDelay;
                    } else if (rand < 0.02) {
                        targetReactionDelay = nextHumanDelay(55, 70);
                        airTargetReactionDelay = targetReactionDelay;
                    } else {
                        targetReactionDelay = nextHumanDelay(30, 55);
                        airTargetReactionDelay = targetReactionDelay;
                    }
                }
                snapDuration = targetReactionDelay;
                snapInterpolating = true;
                reactionPending = true;
                airReactionPending = true;
                // Prevent immediate attack after new target
                nextAllowedGroundAttack = targetAcquiredTime + targetReactionDelay;
                nextAllowedAirAttack = airTargetAcquiredTime + airTargetReactionDelay;
            }
            lastTarget = currentTarget;
            lastYaw = currentYaw;
            lastPitch = currentPitch;
            lastHadTarget = (currentTarget != null);

            // --- Attack logic: only one attack per cooldown window ---
            float cooldown = player.getAttackCooldownProgress(0.5F);

            // Only allow one attack per cooldown window
            if (cooldown < 0.86f) {
                hasAttackedThisCooldown = false;
            }

            // Only allow attack if not in snap interpolation, or interpolation finished
            boolean canAttack = !snapInterpolating;

            if (currentTarget != null && !player.isOnGround() && player.getVelocity().y < -0.08) {
                long now = System.currentTimeMillis();
                if (cooldown < 0.86f) return;
                if (hasAttackedThisCooldown) return;
                if (!canAttack) return;

                // --- Snap-based air reaction delay ---
                if (airReactionPending) {
                    if (now < airTargetAcquiredTime + airTargetReactionDelay) {
                        return;
                    } else {
                        airReactionPending = false;
                    }
                }

                double cooldownPercent = 0.86 + (random.nextDouble() * 0.14);
                long minCooldown = (long)((lastAttackDelay > 0 ? lastAttackDelay : 100) * cooldownPercent);
                if (now - lastAttackTime < minCooldown) {
                    return;
                }
                if (now >= nextAllowedAirAttack) {
                    long jumpDelay = nextCustomJumpDelay(currentTarget);
                    lastAirDelay = jumpDelay;
                    lastAttackDelay = jumpDelay;
                    nextAllowedAirAttack = now + jumpDelay;
                    applyAttackAimJitter(player);
                    performDoAttack(client);
                    lastAttackTime = now;
                    hasAttackedThisCooldown = true;
                }
            } else if (currentTarget != null && player.isOnGround()) {
                long now = System.currentTimeMillis();
                if (cooldown < 0.86f) return;
                if (hasAttackedThisCooldown) return;
                if (!canAttack) return;

                if (reactionPending) {
                    if (now < targetAcquiredTime + targetReactionDelay) {
                        return;
                    } else {
                        reactionPending = false;
                    }
                }
                long groundDelay;
                if (inRecentlyHitDelayWindow) {
                    groundDelay = nextCustomGroundDelay(true);
                } else {
                    groundDelay = nextCustomGroundDelay(false);
                }
                lastGroundDelay = groundDelay;
                lastAttackDelay = groundDelay;
                nextAllowedGroundAttack = now + groundDelay;
                applyAttackAimJitter(player);
                performDoAttack(client);
                lastAttackTime = now;
                hasAttackedThisCooldown = true;
            }
        });
    }

    // --- Utility lerp helpers for snap interpolation ---
    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
    private float lerpYaw(float a, float b, float t) {
        float delta = ((b - a + 540f) % 360f) - 180f;
        return a + delta * t;
    }

    // --- All your remaining helper methods unchanged below ---

    /**
     * Mixed distribution: 60% log-normal, 30% uniform, 10% bi-modal
     */
    private long mixedDelay(long previousDelay, int min, int max) {
        double typeRoll = random.nextDouble();
        if (typeRoll < 0.6) {
            // Log-normal
            double logMin = Math.log(Math.max(min, 1));
            double logMax = Math.log(Math.max(max, min + 1));
            double mu = (logMin + logMax) / 2.0;
            double sigma = (logMax - logMin) / 3.0;
            long delay = (long) Math.exp(mu + sigma * random.nextGaussian());
            if (previousDelay > 0) {
                delay = (long) (0.7 * delay + 0.3 * previousDelay);
            }
            delay += random.nextInt(11) - 5;
            return Math.max(min, Math.min(max, delay));
        } else if (typeRoll < 0.9) {
            // Uniform
            return min + random.nextInt(max - min + 1);
        } else {
            // Bi-modal: lower band and upper band, avoid the center
            int mid = (min + max) / 2;
            int range = (max - min) / 10;
            if (random.nextBoolean()) {
                int upper = mid - range;
                return min + random.nextInt(Math.max(1, upper - min + 1));
            } else {
                int lower = mid + range;
                return lower + random.nextInt(Math.max(1, max - lower + 1));
            }
        }
    }

    /**
     * Custom ground delay logic using mixed randomization.
     */
    private long nextCustomGroundDelay(boolean recentlyHit) {
        int roll = random.nextInt(100);
        if (recentlyHit) {
            if (roll < 90) {
                return mixedDelay(lastGroundDelay, 580, 630);
            } else if (roll < 95) {
                return mixedDelay(lastGroundDelay, 635, 650);
            } else {
                return mixedDelay(lastGroundDelay, 550, 579);
            }
        } else {
            if (roll < 90) {
                return mixedDelay(lastGroundDelay, 550, 579);
            } else if (roll < 95) {
                return mixedDelay(lastGroundDelay, 520, 549);
            } else {
                return mixedDelay(lastGroundDelay, 635, 650);
            }
        }
    }

    /**
     * Custom jump/air delay logic using mixed randomization.
     */
    private long nextCustomJumpDelay(Entity target) {
        boolean targetIsEating = false;
        if (target instanceof PlayerEntity) {
            targetIsEating = ((PlayerEntity)target).isUsingItem();
        }

        int roll = random.nextInt(100);
        if (targetIsEating) {
            if (roll < 60) {
                return mixedDelay(lastAirDelay, 390, 450);
            } else {
                return mixedDelay(lastAirDelay, 451, 520);
            }
        } else {
            if (roll < 70) {
                return mixedDelay(lastAirDelay, 341, 360);
            } else if (roll < 90) {
                return mixedDelay(lastAirDelay, 314, 319);
            } else if (roll < 95) {
                return mixedDelay(lastAirDelay, 361, 420);
            } else {
                return mixedDelay(lastAirDelay, 421, 480);
            }
        }
    }

    /**
     * Apply humanized jitter logic with random streaks, window size, and flicks.
     * Now uses a broader and more human-like randomization for microjitter to evade Vulcan AimModulo360/AimO.
     */
    private void applyAimJitter(ClientPlayerEntity player) {
        float baseYaw = player.getYaw();
        float basePitch = player.getPitch();

        float appliedJitterYaw, appliedJitterPitch;
        if (smallJitterStreak >= maxSmallJitterStreak || forceBigFlickNextTick) {
            // Flick size and probability randomized
            float flickBase = (random.nextFloat() * 0.4f + 0.1f);
            float flickSize = flickBase * (random.nextBoolean() ? 1f : -1f);
            if (random.nextDouble() < 0.15) {
                flickSize *= 2.0f; // Occasionally do a “mega” flick
            }
            appliedJitterYaw = flickSize;
            appliedJitterPitch = flickSize * (random.nextBoolean() ? 1f : -1f);
            smallJitterStreak = 0;
            forceBigFlickNextTick = false;
            maxSmallJitterStreak = 2 + random.nextInt(7); // PATCH: reroll for next streak between 2–8
        } else {
            // HUMANIZED MICROJITTER (ANTI-VULCAN)
            // Most ticks: about 0.015–0.045°, sometimes up to 0.08°, rarely up to 0.12°, sometimes below 0.02°
            float baseJitter = (float) Math.abs(random.nextGaussian() * 0.015 + 0.025f); // mean 0.025°, stddev 0.015°
            if (random.nextDouble() < 0.10) baseJitter += (random.nextFloat() * 0.04f); // 10% chance, add up to 0.04°
            if (random.nextDouble() < 0.01) baseJitter += (random.nextFloat() * 0.07f); // 1% chance, add up to 0.07°
            appliedJitterYaw = baseJitter * (random.nextBoolean() ? 1f : -1f);
            appliedJitterPitch = baseJitter * (random.nextBoolean() ? 1f : -1f);

            // Human: sometimes even in the "micro" phase, a few ticks in every window are >0.02°
            // This will ensure you do not have long runs of <0.02°
            float maxDelta = Math.max(Math.abs(appliedJitterYaw), Math.abs(appliedJitterPitch));
            if (maxDelta < 0.02f && random.nextDouble() < 0.25) {
                // 25% of the time, boost it to at least 0.022–0.035°
                float boost = 0.022f + random.nextFloat() * 0.013f;
                if (Math.abs(appliedJitterYaw) > Math.abs(appliedJitterPitch)) {
                    appliedJitterYaw = Math.copySign(boost, appliedJitterYaw);
                } else {
                    appliedJitterPitch = Math.copySign(boost, appliedJitterPitch);
                }
            }

            // Track small streak for "flick" logic
            float curMaxDelta = Math.max(Math.abs(appliedJitterYaw), Math.abs(appliedJitterPitch));
            if (curMaxDelta < 0.02f) {
                smallJitterStreak++;
            } else {
                smallJitterStreak = 0;
            }
        }

        // PATCH: Occasionally insert a micro-flick even if not at streak (if buffer is quiet)
        if (!forceBigFlickNextTick) {
            if (random.nextDouble() < 0.02) {
                appliedJitterYaw += (random.nextBoolean() ? 1 : -1) * (random.nextFloat() * 0.09f + 0.03f);
                appliedJitterPitch += (random.nextBoolean() ? 1 : -1) * (random.nextFloat() * 0.09f + 0.03f);
            }
        }

        float newYaw = baseYaw + appliedJitterYaw;
        float newPitch = Math.max(-90f, Math.min(90f, basePitch + appliedJitterPitch));
        player.setYaw(newYaw);
        player.setPitch(newPitch);

        // Optionally, always apply safe jitter for vanilla packets
        applySafeAimJitter(player);
    }

    /**
     * Compute the minimal angular difference mod 360.
     */
    private float computeAngularDelta(float prev, float curr) {
        float delta = ((curr - prev + 540f) % 360f) - 180f;
        return delta;
    }

    /**
     * Applies safe aim jitter to the player's rotation.
     */
    private void applySafeAimJitter(ClientPlayerEntity player) {
        float baseYaw = player.getYaw();
        float basePitch = player.getPitch();

        float jitterYaw = (random.nextFloat() * 0.01f + 0.005f) * (random.nextBoolean() ? 1f : -1f);
        float jitterPitch = (random.nextFloat() * 0.01f + 0.005f) * (random.nextBoolean() ? 1f : -1f);

        float newYaw = baseYaw + jitterYaw;
        float newPitch = basePitch + jitterPitch;

        if (Float.compare(newYaw, lastSentYaw) == 0) {
            newYaw += (random.nextFloat() - 0.5f) * 0.001f + 0.0001f;
        }
        if (Float.compare(newPitch, lastSentPitch) == 0) {
            newPitch += (random.nextFloat() - 0.5f) * 0.001f + 0.0001f;
        }

        newPitch = Math.max(-90f, Math.min(90f, newPitch));

        jitterTickCounter++;
        if (Math.abs(newYaw - lastSentYaw) > 0.00009f || Math.abs(newPitch - lastSentPitch) > 0.00009f) {
            jitterNonIdenticalTicks++;
        }

        if (jitterTickCounter >= jitterWindow) {
            if (jitterNonIdenticalTicks < 20) {
                jitterNonIdenticalTicks = 0;
                jitterTickCounter = 0;
            } else {
                jitterNonIdenticalTicks = 0;
                jitterTickCounter = 0;
            }
            jitterWindow = BASE_JITTER_WINDOW + random.nextInt(8) - 4;
        }

        lastSentYaw = newYaw;
        lastSentPitch = newPitch;

        player.setYaw(newYaw);
        player.setPitch(newPitch);
    }

    /**
     * Applies a larger random aim deviation to the player's rotation before attacking, to evade GrimAC hit-angle checks.
     */
    private void applyAttackAimJitter(ClientPlayerEntity player) {
        float baseYaw = player.getYaw();
        float basePitch = player.getPitch();

        float jitterRange = random.nextFloat() < 0.08f ? (random.nextFloat() * 0.8f + 1.2f) : (random.nextFloat() * 1.0f + 0.2f);
        float jitterYaw = jitterRange * (random.nextBoolean() ? 1f : -1f);
        float jitterPitch = jitterRange * (random.nextBoolean() ? 1f : -1f);

        player.setYaw(baseYaw + jitterYaw);
        player.setPitch(Math.max(-90f, Math.min(90f, basePitch + jitterPitch)));
    }

    /**
     * "Humanized" log-normal delay using randomized curve each call. (Used for non-ground, post-eat, etc.)
     */
    private long nextHumanDelay(int min, int max) {
        double logMin = Math.log(Math.max(min, 1));
        double logMax = Math.log(max);
        double muBase = (logMin + logMax) / 2.0;
        double sigmaBase = (logMax - logMin) / 6.0;

        double mu = muBase + (random.nextDouble() - 0.5) * 0.20;
        double sigma = sigmaBase * (0.85 + random.nextDouble() * 0.4);

        if (random.nextDouble() < 0.05) {
            return min + random.nextInt((max - min) + 1);
        }
        if (random.nextDouble() < 0.05) {
            long a = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
            long b = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
            long sample = (a + b) / 2;
            return Math.max(min, Math.min(max, sample));
        }

        long result = Math.round(Math.exp(mu + sigma * random.nextGaussian()));
        return Math.max(min, Math.min(max, result));
    }

    /**
     * Calls MinecraftClient.doAttack() directly for the triggerbot attack.
     */
    private void performDoAttack(MinecraftClient client) {
        client.doAttack();
    }

    @Deprecated
    private long getHumanizedJumpDelay(Entity target) {
        // Deprecated, replaced by nextCustomJumpDelay
        return nextCustomJumpDelay(target);
    }
}