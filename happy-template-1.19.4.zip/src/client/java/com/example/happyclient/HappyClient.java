package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;

public class HappyClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}