package com.example.triggerbot;

public class TriggerBotMod {
    public static final String MOD_ID = "triggerbotmod";
}