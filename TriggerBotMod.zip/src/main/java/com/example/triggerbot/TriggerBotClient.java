package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class TriggerBotClient implements ClientModInitializer {
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static long lastAttackTime = 0;
    private static final Random random = new Random();

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.triggerbot.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_V,
            "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                client.player.sendMessage(
                    net.minecraft.text.Text.literal("TriggerBot: " + (enabled ? "Enabled" : "Disabled")),
                    false
                );
            }

            if (!enabled || client.crosshairTarget == null || client.player == null || client.world == null)
                return;

            if (client.crosshairTarget.getType() == net.minecraft.util.hit.HitResult.Type.ENTITY &&
                client.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult entityHitResult &&
                entityHitResult.getEntity() instanceof PlayerEntity target &&
                target != client.player &&
                client.player.getMainHandStack().getItem() instanceof SwordItem) {

                long now = System.currentTimeMillis();
                long delay = 500 + random.nextInt(151); // 500-650ms
                if (now - lastAttackTime >= delay) {
                    lastAttackTime = now;

                    double distance = client.player.squaredDistanceTo(target);
                    boolean shouldMiss = random.nextInt(100) < 4; // 4% chance to miss
                    boolean missByDistance = shouldMiss && (distance >= 9.61 && distance <= 10.89); // 3.1-3.3 blocks
                    boolean missByAim = shouldMiss && !missByDistance && random.nextBoolean();

                    if (missByDistance || missByAim) {
                        client.player.swingHand(Hand.MAIN_HAND); // Bluff swing
                    } else {
                        client.interactionManager.attackEntity(client.player, target);
                        client.player.swingHand(Hand.MAIN_HAND);
                    }
                }
            }
        });
    }
}